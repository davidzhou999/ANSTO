#!/usr/bin/env python
"""
MONAI benchmark helper for 3D neutron tomography segmentation.

Sub-commands:

1) TIFF stack -> NIfTI blocks (for training)
   tiff_to_blocks:
     - Reads a reconstructed TIFF stack, e.g. data/recon_full/recon_z*.tif
     - Splits along Z into K 3D blocks (approx equal depth)
     - Saves NIfTI volumes into imagesTr

2) Generate K-fold splits:
   generate_folds:
     - Reads image NIfTIs in imagesTr and matching labels in labelsTr
     - Writes folds/fold1.json ... folds/foldK.json

3) Train 3D UNet / UNETR:
   train:
     - Uses a fold JSON, trains model, saves best.pt

4) Inference:
   infer:
     - Sliding-window inference over images in a fold

5) Eval:
   eval:
     - Computes Dice / IoU metrics vs labels and writes CSV

Typical workflow for your tooth dataset
---------------------------------------

# 0) Activate env
conda activate monai-bench

# 1) Convert TIFF stack -> 5 NIfTI blocks (imagesTr)
python monai_benchmark_suite.py tiff_to_blocks \
  --images_dir data/recon_full \
  --out_images_dir data/nii/imagesTr \
  --k 5 \
  --prefix tooth \
  --pattern "recon_z*.tif" \
  --spacing 1 1 1

# (You manually create labels: data/nii/labelsTr/tooth_*.nii.gz)

# 2) Generate 5 folds
python monai_benchmark_suite.py generate_folds \
  --images_dir data/nii/imagesTr \
  --labels_dir data/nii/labelsTr \
  --out_dir folds_tooth3d --k 5

# 3) Train 3D UNet on fold1
python monai_benchmark_suite.py train \
  --fold_json folds_tooth3d/fold1.json \
  --spatial_dims 3 --model unet \
  --roi 128 128 128 --batch 2 --epochs 200 --amp \
  --out_dir runs/tooth_3dunet_fold1 --num_classes 2

# 4) Inference
python monai_benchmark_suite.py infer \
  --fold_json folds_tooth3d/fold1.json \
  --ckpt runs/tooth_3dunet_fold1/best.pt \
  --roi 128 128 128 --overlap 0.5 --amp \
  --out_dir preds/tooth_3dunet_fold1

# 5) Eval
python monai_benchmark_suite.py eval \
  --fold_json folds_tooth3d/fold1.json \
  --preds preds/tooth_3dunet_fold1 \
  --metrics dice iou \
  --csv results/tooth_3dunet_fold1.csv
"""

from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
from typing import List, Dict, Tuple

import numpy as np
import nibabel as nib
import tifffile as tiff
import pandas as pd
from sklearn.model_selection import KFold

import torch
from torch.utils.data import DataLoader

from monai.data import CacheDataset, Dataset, decollate_batch
from monai.transforms import (
    Compose,
    LoadImaged,
    EnsureChannelFirstd,
    Spacingd,
    Orientationd,
    ScaleIntensityRanged,
    RandCropByPosNegLabeld,
    RandFlipd,
    RandAffined,
    EnsureTyped,
    AsDiscrete,
    Invertd,
)
from monai.networks.nets import UNet, UNETR
from monai.networks.utils import one_hot
from monai.losses import DiceCELoss
from monai.metrics import DiceMetric
from monai.inferers import sliding_window_inference
from monai.utils import set_determinism
from tqdm import tqdm


# -------------------------
# Utility helpers
# -------------------------


def natural_key(s: str):
    out = []
    num = ""
    for ch in s:
        if ch.isdigit():
            num += ch
        else:
            if num:
                out.append(int(num))
                num = ""
            out.append(s.lower())
    if num:
        out.append(int(num))
    return out


def load_tiff_stack(files: List[Path]) -> np.ndarray:
    """Load 2D TIFFs into 3D volume (z, y, x)."""
    arrs = [tiff.imread(str(f)) for f in sorted(files, key=lambda p: p.name)]
    vol = np.stack(arrs, axis=0)  # (z, y, x)
    return vol


def save_nifti(vol: np.ndarray, out_path: Path, spacing: Tuple[float, float, float]):
    """Save 3D volume (z,y,x) as NIfTI."""
    # MONAI expects (C, Z, Y, X), but we store single-channel here.
    # We'll load with EnsureChannelFirst later.
    # For NIfTI, we store (Z, Y, X); spacing order: (dz, dy, dx)
    dz, dy, dx = spacing
    affine = np.diag([dx, dy, dz, 1.0]).astype(np.float32)
    img = nib.Nifti1Image(vol.astype(np.float32), affine)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    nib.save(img, str(out_path))


# -------------------------
# Command: tiff_to_blocks
# -------------------------


def cmd_tiff_to_blocks(args):
    src_dir = Path(args.images_dir)
    out_dir = Path(args.out_images_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    files = sorted(src_dir.glob(args.pattern), key=lambda p: p.name)
    if not files:
        raise SystemExit(f"No TIFFs found in {src_dir} with pattern {args.pattern}")

    print(f"[tiff_to_blocks] Found {len(files)} slices. Loading stack...")
    vol = load_tiff_stack(files)  # (Z, Y, X)
    nz, ny, nx = vol.shape
    print(f"[tiff_to_blocks] Volume shape: (Z={nz}, Y={ny}, X={nx})")

    k = args.k
    block_depth = int(np.ceil(nz / k))
    print(f"[tiff_to_blocks] Splitting into {k} blocks; block_depth ~ {block_depth}")

    spacing = tuple(float(s) for s in args.spacing)

    for i in range(k):
        z_start = i * block_depth
        z_end = min((i + 1) * block_depth, nz)
        if z_start >= z_end:
            print(f"[tiff_to_blocks] Block {i} is empty, skipping")
            continue
        sub = vol[z_start:z_end]  # (z, y, x)
        fname = f"{args.prefix}_{i:02d}.nii.gz"
        out_path = out_dir / fname
        print(f"[tiff_to_blocks] Block {i}: z[{z_start}:{z_end}] -> {out_path}")
        save_nifti(sub, out_path, spacing=spacing)

    print("[tiff_to_blocks] Done.")


# -------------------------
# Command: generate_folds
# -------------------------


def cmd_generate_folds(args):
    img_dir = Path(args.images_dir)
    lbl_dir = Path(args.labels_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    img_files = sorted([p for p in img_dir.glob(args.pattern)], key=lambda p: p.name)
    if not img_files:
        raise SystemExit(f"No images found in {img_dir} with pattern {args.pattern}")

    all_pairs = []
    for img in img_files:
        lbl = lbl_dir / img.name
        if not lbl.exists():
            raise SystemExit(f"Missing label for image {img.name}: expected {lbl}")
        all_pairs.append((str(img), str(lbl)))

    n = len(all_pairs)
    k = args.k
    print(f"[generate_folds] Found {n} image/label pairs. Generating {k} folds...")

    indices = np.arange(n)
    kf = KFold(n_splits=k, shuffle=True, random_state=42)

    for fold_idx, (train_idx, val_idx) in enumerate(kf.split(indices), start=1):
        fold = {
            "train_images": [all_pairs[i][0] for i in train_idx],
            "train_labels": [all_pairs[i][1] for i in train_idx],
            "val_images": [all_pairs[i][0] for i in val_idx],
            "val_labels": [all_pairs[i][1] for i in val_idx],
        }
        out_path = out_dir / f"fold{fold_idx}.json"
        print(f"[generate_folds] Writing {out_path}")
        with open(out_path, "w") as f:
            json.dump(fold, f, indent=2)

    print("[generate_folds] Done.")


# -------------------------
# Model builder
# -------------------------


def build_model(model_name: str, spatial_dims: int, in_channels: int, out_channels: int):
    if spatial_dims != 3:
        raise ValueError("This script currently supports spatial_dims=3 only.")

    if model_name.lower() == "unet":
        net = UNet(
            spatial_dims=3,
            in_channels=in_channels,
            out_channels=out_channels,
            channels=(32, 64, 128, 256, 512),
            strides=(2, 2, 2, 2),
            num_res_units=2,
        )
    elif model_name.lower() == "unetr":
        net = UNETR(
            in_channels=in_channels,
            out_channels=out_channels,
            img_size=(args_global_roi[0], args_global_roi[1], args_global_roi[2]),
            feature_size=16,
            hidden_size=256,
            mlp_dim=512,
            num_heads=8,
            pos_embed="perceptron",
            norm_name="instance",
            res_block=True,
            dropout_rate=0.0,
        )
    else:
        raise ValueError(f"Unknown model: {model_name}")
    return net


# -------------------------
# Command: train
# -------------------------

args_global_roi = None  # used by build_model for UNETR img_size


def load_fold_json(path: str) -> Dict:
    with open(path, "r") as f:
        return json.load(f)


def get_transforms_train_val(
    roi_size: Tuple[int, int, int],
    num_classes: int,
    spacing: Tuple[float, float, float] | None = None,
):
    if spacing is None:
        spacing = (1.0, 1.0, 1.0)

    train_transforms = Compose(
        [
            LoadImaged(keys=["image", "label"]),
            EnsureChannelFirstd(keys=["image", "label"]),
            Spacingd(
                keys=["image", "label"],
                pixdim=spacing,
                mode=("bilinear", "nearest"),
            ),
            Orientationd(keys=["image", "label"], axcodes="RAS"),
            ScaleIntensityRanged(
                keys=["image"],
                a_min=0.0,
                a_max=1.0,
                b_min=0.0,
                b_max=1.0,
                clip=True,
            ),
            RandCropByPosNegLabeld(
                keys=["image", "label"],
                label_key="label",
                spatial_size=roi_size,
                pos=1,
                neg=1,
                num_samples=2,
                image_key="image",
                image_threshold=0.0,
            ),
            RandFlipd(keys=["image", "label"], prob=0.5, spatial_axis=0),
            RandFlipd(keys=["image", "label"], prob=0.5, spatial_axis=1),
            RandFlipd(keys=["image", "label"], prob=0.5, spatial_axis=2),
            RandAffined(
                keys=["image", "label"],
                rotate_range=(0.1, 0.1, 0.1),
                scale_range=(0.1, 0.1, 0.1),
                mode=("bilinear", "nearest"),
                prob=0.3,
            ),
            EnsureTyped(keys=["image", "label"]),
        ]
    )

    val_transforms = Compose(
        [
            LoadImaged(keys=["image", "label"]),
            EnsureChannelFirstd(keys=["image", "label"]),
            Spacingd(
                keys=["image", "label"],
                pixdim=spacing,
                mode=("bilinear", "nearest"),
            ),
            Orientationd(keys=["image", "label"], axcodes="RAS"),
            ScaleIntensityRanged(
                keys=["image"],
                a_min=0.0,
                a_max=1.0,
                b_min=0.0,
                b_max=1.0,
                clip=True,
            ),
            EnsureTyped(keys=["image", "label"]),
        ]
    )

    return train_transforms, val_transforms


def cmd_train(args):
    global args_global_roi
    set_determinism(seed=42)

    fold = load_fold_json(args.fold_json)
    roi_size = tuple(int(x) for x in args.roi)
    args_global_roi = roi_size

    train_files = [
        {"image": img, "label": lbl}
        for img, lbl in zip(fold["train_images"], fold["train_labels"])
    ]
    val_files = [
        {"image": img, "label": lbl}
        for img, lbl in zip(fold["val_images"], fold["val_labels"])
    ]

    spacing = tuple(float(s) for s in args.spacing)

    train_transforms, val_transforms = get_transforms_train_val(
        roi_size=roi_size,
        num_classes=args.num_classes,
        spacing=spacing,
    )

    print(f"[train] #train={len(train_files)} #val={len(val_files)}")
    print(f"[train] roi_size={roi_size}, spacing={spacing}")

    train_ds = CacheDataset(
        data=train_files, transform=train_transforms, cache_rate=0.5, num_workers=args.workers
    )
    val_ds = CacheDataset(
        data=val_files, transform=val_transforms, cache_rate=0.0, num_workers=args.workers
    )

    train_loader = DataLoader(
        train_ds, batch_size=args.batch, shuffle=True, num_workers=args.workers
    )
    val_loader = DataLoader(
        val_ds, batch_size=1, shuffle=False, num_workers=args.workers
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[train] Using device: {device}")

    model = build_model(
        model_name=args.model,
        spatial_dims=args.spatial_dims,
        in_channels=1,
        out_channels=args.num_classes,
    ).to(device)

    loss_fn = DiceCELoss(
        to_onehot_y=True,
        softmax=True,
        squared_pred=True,
        batch=True,
    )
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-5)
    dice_metric = DiceMetric(include_background=False, reduction="mean")

    scaler = torch.cuda.amp.GradScaler(enabled=args.amp and device.type == "cuda")

    best_dice = -1.0
    best_path = Path(args.out_dir) / "best.pt"
    Path(args.out_dir).mkdir(parents=True, exist_ok=True)

    for epoch in range(1, args.epochs + 1):
        print(f"\n[train] Epoch {epoch}/{args.epochs}")
        model.train()
        epoch_loss = 0.0

        for batch_data in tqdm(train_loader, desc="Train"):
            images = batch_data["image"].to(device)
            labels = batch_data["label"].to(device)

            optimizer.zero_grad()
            with torch.cuda.amp.autocast(enabled=args.amp and device.type == "cuda"):
                logits = model(images)
                loss = loss_fn(logits, labels)
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            epoch_loss += loss.item()

        epoch_loss /= max(1, len(train_loader))
        print(f"[train] Mean training loss: {epoch_loss:.4f}")

        # Validation
        model.eval()
        dice_metric.reset()
        with torch.no_grad():
            for val_data in tqdm(val_loader, desc="Val"):
                val_images = val_data["image"].to(device)
                val_labels = val_data["label"].to(device)

                with torch.cuda.amp.autocast(enabled=args.amp and device.type == "cuda"):
                    val_logits = model(val_images)

                # one-hot + dice
                val_labels_oh = one_hot(val_labels, num_classes=args.num_classes)
                val_probs = torch.softmax(val_logits, dim=1)
                dice_metric(val_probs, val_labels_oh)

        mean_dice = dice_metric.aggregate().item()
        dice_metric.reset()
        print(f"[train] Mean validation Dice: {mean_dice:.4f}")

        # Save best
        if mean_dice > best_dice:
            best_dice = mean_dice
            torch.save(
                {
                    "epoch": epoch,
                    "model_state": model.state_dict(),
                    "optimizer_state": optimizer.state_dict(),
                    "mean_dice": best_dice,
                    "roi_size": roi_size,
                    "num_classes": args.num_classes,
                },
                best_path,
            )
            print(f"[train] New best Dice {best_dice:.4f}, saved to {best_path}")

    print(f"[train] Training done. Best Dice = {best_dice:.4f}")


# -------------------------
# Command: infer
# -------------------------


def cmd_infer(args):
    fold = load_fold_json(args.fold_json)
    img_files = fold["val_images"]  # or train_images if you want

    roi_size = tuple(int(x) for x in args.roi)
    spacing = tuple(float(s) for s in args.spacing)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[infer] Using device: {device}")

    ckpt = torch.load(args.ckpt, map_location=device)
    num_classes = ckpt.get("num_classes", args.num_classes)
    model = build_model(
        model_name=args.model,
        spatial_dims=args.spatial_dims,
        in_channels=1,
        out_channels=num_classes,
    )
    model.load_state_dict(ckpt["model_state"])
    model.to(device)
    model.eval()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # transforms: only deterministic
    infer_transforms = Compose(
        [
            LoadImaged(keys=["image"]),
            EnsureChannelFirstd(keys=["image"]),
            Spacingd(keys=["image"], pixdim=spacing, mode=("bilinear",)),
            Orientationd(keys=["image"], axcodes="RAS"),
            ScaleIntensityRanged(
                keys=["image"],
                a_min=0.0,
                a_max=1.0,
                b_min=0.0,
                b_max=1.0,
                clip=True,
            ),
            EnsureTyped(keys=["image"]),
        ]
    )

    data = [{"image": img} for img in img_files]
    ds = Dataset(data=data, transform=infer_transforms)
    loader = DataLoader(ds, batch_size=1, shuffle=False, num_workers=args.workers)

    with torch.no_grad():
        for b, batch_data in enumerate(tqdm(loader, desc="Infer")):
            img_meta = batch_data["image_meta_dict"]
            img = batch_data["image"].to(device)
            fname = Path(img_meta["filename_or_obj"][0]).name
            print(f"[infer] {b}: {fname}")

            with torch.cuda.amp.autocast(enabled=args.amp and device.type == "cuda"):
                logits = sliding_window_inference(
                    img,
                    roi_size=roi_size,
                    sw_batch_size=1,
                    predictor=model,
                    overlap=args.overlap,
                )
            probs = torch.softmax(logits, dim=1)
            pred = torch.argmax(probs, dim=1, keepdim=True)  # (B,1,Z,Y,X)

            # Save as NIfTI
            pred_np = pred.cpu().numpy().astype(np.uint8)[0, 0]  # (Z,Y,X)
            # reuse spacing from args; orientation has been RAS
            dz, dy, dx = spacing
            affine = np.diag([dx, dy, dz, 1.0]).astype(np.float32)
            out_nii = nib.Nifti1Image(pred_np, affine)
            out_path = out_dir / fname.replace(".nii.gz", "_pred.nii.gz")
            nib.save(out_nii, str(out_path))
            print(f"[infer] Saved {out_path}")

    print("[infer] Done.")


# -------------------------
# Command: eval
# -------------------------


def cmd_eval(args):
    fold = load_fold_json(args.fold_json)
    lbl_files = fold["val_labels"]
    preds_dir = Path(args.preds)
    metrics = [m.lower() for m in args.metrics]
    rows = []

    for lbl_path in lbl_files:
        lbl_name = Path(lbl_path).name
        pred_name = lbl_name.replace(".nii.gz", "_pred.nii.gz")
        pred_path = preds_dir / pred_name
        if not pred_path.exists():
            print(f"[eval] WARNING: missing prediction for {lbl_name}")
            continue

        gt = nib.load(lbl_path).get_fdata().astype(np.int32)
        pr = nib.load(str(pred_path)).get_fdata().astype(np.int32)

        if gt.shape != pr.shape:
            print(f"[eval] WARNING: shape mismatch {lbl_name}: gt={gt.shape}, pred={pr.shape}")
            continue

        row = {"case": lbl_name}

        # Simple Dice and IoU over foreground (labels > 0)
        gt_fg = gt > 0
        pr_fg = pr > 0

        inter = np.logical_and(gt_fg, pr_fg).sum()
        union = np.logical_or(gt_fg, pr_fg).sum()
        gt_sum = gt_fg.sum()
        pr_sum = pr_fg.sum()

        if "dice" in metrics:
            dice = 2.0 * inter / (gt_sum + pr_sum + 1e-8)
            row["dice"] = dice

        if "iou" in metrics:
            iou = inter / (union + 1e-8)
            row["iou"] = iou

        rows.append(row)

    df = pd.DataFrame(rows)
    out_csv = Path(args.csv)
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_csv, index=False)
    print(f"[eval] Wrote metrics to {out_csv}")
    print(df.describe())


# -------------------------
# Main CLI
# -------------------------


def main():
    parser = argparse.ArgumentParser(description="MONAI 3D benchmark suite")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # tiff_to_blocks
    p_t2b = subparsers.add_parser("tiff_to_blocks", help="Convert TIFF stack to NIfTI blocks")
    p_t2b.add_argument("--images_dir", required=True)
    p_t2b.add_argument("--out_images_dir", required=True)
    p_t2b.add_argument("--k", type=int, required=True, help="Number of blocks")
    p_t2b.add_argument("--prefix", default="vol")
    p_t2b.add_argument("--pattern", default="*.tif*")
    p_t2b.add_argument(
        "--spacing", nargs=3, default=[1.0, 1.0, 1.0],
        help="Voxel spacing (dz dy dx), default 1 1 1",
    )
    p_t2b.set_defaults(func=cmd_tiff_to_blocks)

    # generate_folds
    p_gf = subparsers.add_parser("generate_folds", help="Generate K-fold JSON splits")
    p_gf.add_argument("--images_dir", required=True)
    p_gf.add_argument("--labels_dir", required=True)
    p_gf.add_argument("--out_dir", required=True)
    p_gf.add_argument("--k", type=int, required=True)
    p_gf.add_argument("--pattern", default="*.nii.gz")
    p_gf.set_defaults(func=cmd_generate_folds)

    # train
    p_tr = subparsers.add_parser("train", help="Train 3D UNet/UNETR")
    p_tr.add_argument("--fold_json", required=True)
    p_tr.add_argument("--spatial_dims", type=int, default=3)
    p_tr.add_argument("--model", choices=["unet", "unetr"], default="unet")
    p_tr.add_argument("--roi", nargs=3, type=int, required=True)
    p_tr.add_argument("--batch", type=int, default=2)
    p_tr.add_argument("--epochs", type=int, default=200)
    p_tr.add_argument("--lr", type=float, default=1e-4)
    p_tr.add_argument("--amp", action="store_true")
    p_tr.add_argument("--out_dir", required=True)
    p_tr.add_argument("--num_classes", type=int, required=True)
    p_tr.add_argument(
        "--spacing", nargs=3, default=[1.0, 1.0, 1.0],
        help="Target spacing (dz dy dx)",
    )
    p_tr.add_argument("--workers", type=int, default=4)
    p_tr.set_defaults(func=cmd_train)

    # infer
    p_inf = subparsers.add_parser("infer", help="Sliding-window inference")
    p_inf.add_argument("--fold_json", required=True)
    p_inf.add_argument("--ckpt", required=True)
    p_inf.add_argument("--spatial_dims", type=int, default=3)
    p_inf.add_argument("--model", choices=["unet", "unetr"], default="unet")
    p_inf.add_argument("--roi", nargs=3, type=int, required=True)
    p_inf.add_argument("--overlap", type=float, default=0.5)
    p_inf.add_argument("--amp", action="store_true")
    p_inf.add_argument("--out_dir", required=True)
    p_inf.add_argument("--num_classes", type=int, default=2)
    p_inf.add_argument(
        "--spacing", nargs=3, default=[1.0, 1.0, 1.0],
        help="Target spacing (dz dy dx)",
    )
    p_inf.add_argument("--workers", type=int, default=4)
    p_inf.set_defaults(func=cmd_infer)

    # eval
    p_ev = subparsers.add_parser("eval", help="Evaluate predictions vs. labels")
    p_ev.add_argument("--fold_json", required=True)
    p_ev.add_argument("--preds", required=True)
    p_ev.add_argument("--metrics", nargs="+", default=["dice", "iou"])
    p_ev.add_argument("--csv", required=True)
    p_ev.set_defaults(func=cmd_eval)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()

