
import os, argparse, numpy as np, tifffile as tiff, torch
from models.resunet_het import ResUNetHet
from utils.vst import anscombe_forward, anscombe_inverse

def read_stack_mean(folder):
    files = sorted([os.path.join(folder, f) for f in os.listdir(folder) if f.lower().endswith(('.tif','.tiff'))])
    if len(files)==0: raise FileNotFoundError(f"No TIFFs in {folder}")
    acc = None
    for fp in files:
        img = tiff.imread(fp).astype(np.float32)
        if img.ndim==3: img = img[...,0]
        if acc is None: acc = np.zeros_like(img, dtype=np.float64)
        acc += img
    return (acc / len(files)).astype(np.float32)

@torch.no_grad()
def tile_infer_norm01(img01, model, tile=768, overlap=64, alpha=1.0, sigma=0.0, amp=True, device='cuda'):
    H, W = img01.shape
    step = tile - overlap
    out_mu = np.zeros_like(img01, dtype=np.float32)
    out_s  = np.zeros_like(img01, dtype=np.float32)
    wsum   = np.zeros_like(img01, dtype=np.float32)
    wy = np.hanning(tile).astype(np.float32); wx = np.hanning(tile).astype(np.float32)
    win = np.outer(wy, wx)
    for y in range(0, H, step):
        for x in range(0, W, step):
            ys = min(y+tile, H); xs = min(x+tile, W)
            y0 = max(0, ys - tile); x0 = max(0, xs - tile)
            patch = img01[y0:ys, x0:xs]
            ph, pw = patch.shape
            pad = ((0, tile-ph), (0, tile-pw)); patch = np.pad(patch, pad, mode='edge')
            ten = torch.from_numpy(patch).unsqueeze(0).unsqueeze(0).to(device)
            ten = anscombe_forward(ten, alpha=alpha, sigma=sigma)
            with torch.cuda.amp.autocast(enabled=amp):
                mu, logv = model(ten)
            mu = anscombe_inverse(mu, alpha=alpha, sigma=sigma).squeeze().float().cpu().numpy()
            s  = (logv.exp().sqrt()).squeeze().float().cpu().numpy()
            mu = mu[:ph,:pw]; s = s[:ph,:pw]; w = win[:ph,:pw]
            out_mu[y0:y0+ph, x0:x0+pw] += mu*w
            out_s [y0:y0+ph, x0:x0+pw] += s*w
            wsum  [y0:y0+ph, x0:x0+pw] += w
    out_mu /= (wsum + 1e-8); out_s /= (wsum + 1e-8)
    return out_mu, out_s

def main(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    os.makedirs(args.output_dir, exist_ok=True)
    dark = read_stack_mean(args.dark_dir); flat = read_stack_mean(args.open_dir)
    ckpt = torch.load(args.checkpoint, map_location=device)
    model = ResUNetHet(in_ch=1, base=args.base, depth=args.depth, blind_spot=True).to(device)
    model.load_state_dict(ckpt['model'], strict=True)
    if 'ema' in ckpt and isinstance(ckpt['ema'], dict):
        for n, p in model.named_parameters():
            if n in ckpt['ema']: p.data.copy_(ckpt['ema'][n])
    model.eval()
    files = [f for f in sorted(os.listdir(args.input_dir)) if f.lower().endswith(('.tif','.tiff'))]
    print(f"Found {len(files)} projections"); eps = 1e-6
    for name in files:
        raw = tiff.imread(os.path.join(args.input_dir, name)).astype(np.float32)
        if raw.ndim==3: raw = raw[...,0]
        denom = flat - dark; denom[denom==0] = eps
        norm = (raw - dark) / denom
        norm = np.clip(norm, eps, 10.0).astype(np.float32)
        pmin = np.percentile(norm, 0.5); pmax = np.percentile(norm, 99.5)
        img01 = np.clip((norm - pmin) / (pmax - pmin + 1e-8), 0.0, 1.0).astype(np.float32)
        mu, sigma = tile_infer_norm01(img01, model, tile=args.tile, overlap=args.overlap,
                                      alpha=args.alpha, sigma=args.sigma, amp=args.amp, device=device)
        denorm = mu * (pmax - pmin) + pmin
        if args.save_log or args.only_log:
            logp = -np.log(np.clip(denorm, eps, 10.0)).astype(np.float32)
            if not args.only_log:
                tiff.imwrite(os.path.join(args.output_dir, name.replace('.tif','_den.tif').replace('.tiff','_den.tiff')),
                             (np.clip(denorm,0,1)*65535).astype(np.uint16))
            tiff.imwrite(os.path.join(args.output_dir, name.replace('.tif','_log.tif').replace('.tiff','_log.tiff')),
                         (logp*1000).astype(np.uint16))
        else:
            tiff.imwrite(os.path.join(args.output_dir, name.replace('.tif','_den.tif').replace('.tiff','_den.tiff')),
                         (np.clip(denorm,0,1)*65535).astype(np.uint16))
        if args.save_sigma:
            s16 = (sigma / (sigma.max()+1e-8) * 65535).astype(np.uint16)
            tiff.imwrite(os.path.join(args.output_dir, name.replace('.tif','_sigma.tif').replace('.tiff','_sigma.tiff')), s16)

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--checkpoint', type=str, required=True)
    ap.add_argument('--input_dir', type=str, required=True, help='raw projections')
    ap.add_argument('--dark_dir',  type=str, required=True, help='5-100 dark frames')
    ap.add_argument('--open_dir',  type=str, required=True, help='5-100 open beam frames')
    ap.add_argument('--output_dir', type=str, required=True)
    ap.add_argument('--tile', type=int, default=768)
    ap.add_argument('--overlap', type=int, default=64)
    ap.add_argument('--alpha', type=float, default=1.0)
    ap.add_argument('--sigma', type=float, default=0.0)
    ap.add_argument('--amp', action='store_true')
    ap.add_argument('--base', type=int, default=64)
    ap.add_argument('--depth', type=int, default=4)
    ap.add_argument('--save_sigma', action='store_true')
    ap.add_argument('--save_log', action='store_true')
    ap.add_argument('--only_log', action='store_true')
    args = ap.parse_args(); main(args)
