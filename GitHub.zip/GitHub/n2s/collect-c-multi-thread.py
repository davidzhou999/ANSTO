#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
TIFF Keyframe Extraction Script (Threaded, Overwrite-Safe)
==========================================================

Objective
---------
Recursively search a given ROOT folder (e.g. "\\\\zfstor6\\dingo\\proposal"), find
subfolders named "scan" (case-insensitive) that contain >100 TIFF images directly inside,
select 11 key images by position, rename them using a root-relative path scheme,
and copy them to Desktop\\david using multi-threaded I/O with overwrite protection.

Key Features
------------
- Finds 'scan' folders with >100 .tif/.tiff files (non-recursive in that folder)
- Picks first, last, and ceil(10%..90%) indices (total 11)
- New names: "<subpath_between_ROOT_and_scan_joined_by__><0..10>.tif(f)"
- Copies to ~/Desktop/david (created if missing)
- Thread-safe uniqueness: appends "_dupN" before extension if needed
- Multi-threaded copying (configurable workers), clean logging, dry-run mode

Usage
-----
  python pick_scan_keyframes.py "\\\\zfstor6\\dingo\\proposal"
  python pick_scan_keyframes.py "\\\\zfstor6\\dingo\\proposal" --dest "C:\\Users\\YourName\\Desktop\\david" --workers 8
  python pick_scan_keyframes.py "\\\\zfstor6\\dingo\\proposal" --dry-run
"""

import os
import re
import math
import shutil
import argparse
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

# Regex: last run of digits before .tif/.tiff
import sys
NUM_RE = re.compile(r'(\d+)(?=\.(?:tif|tiff)$)', re.IGNORECASE)


def numeric_key(p: Path):
    """Return a numeric sort key based on digits before the extension, else name."""
    m = NUM_RE.search(p.name)
    if m:
        try:
            return (0, int(m.group(1)))
        except ValueError:
            pass
    return (1, p.name.lower())


def pick_indices(n: int):
    """Return indices for first, 10%,...,90%, last (ceil rule), de-duplicated."""
    idxs = [0]
    for k in range(1, 10):  # 10% … 90%
        idx = math.ceil(k * 0.1 * n)
        idx = min(max(idx, 0), n - 1)
        idxs.append(idx)
    idxs.append(n - 1)
    cleaned, seen = [], set()
    for i in idxs:
        if i not in seen:
            cleaned.append(i)
            seen.add(i)
    return cleaned


def find_scan_dirs(root: Path):
    """Yield directories named 'scan' (case-insensitive)."""
    for dirpath, dirnames, filenames in os.walk(root):
        if Path(dirpath).name.lower() == "scan":
            yield Path(dirpath)


def list_tiffs(scan_dir: Path):
    """List .tif/.tiff files directly under scan_dir."""
    return [scan_dir / f for f in os.listdir(scan_dir)
            if (scan_dir / f).is_file() and f.lower().endswith(('.tif', '.tiff'))]


def ensure_dest_folder(dest: Path):
    dest.mkdir(parents=True, exist_ok=True)
    return dest


def build_unique_name_reserver(dest_root: Path):
    """
    Create a thread-safe unique-name reserver using a set + lock.
    Ensures no two threads produce the same destination name.
    """
    lock = threading.Lock()
    reserved = set(f.name for f in dest_root.iterdir() if f.is_file())

    def reserve(dst_name: str) -> str:
        """
        Given a desired filename, return a unique filename (possibly with _dupN).
        Thread-safe across workers.
        """
        base, ext = os.path.splitext(dst_name)
        with lock:
            if dst_name not in reserved:
                reserved.add(dst_name)
                return dst_name
            # Find next available _dupN
            n = 1
            while True:
                candidate = f"{base}_dup{n}{ext}"
                if candidate not in reserved:
                    reserved.add(candidate)
                    return candidate
                n += 1

    return reserve


def rel_base_name(root: Path, scan_dir: Path) -> str:
    """Return root-relative subpath (excluding 'scan'), joined by underscores."""
    parent = scan_dir.parent
    try:
        rel = parent.relative_to(root)
        parts = [p for p in rel.parts if p not in (".", "")]
    except ValueError:
        parts = [p for p in parent.parts if p not in (".", "")]
    return "_".join(parts) if parts else "scan"


def copy_one(src: Path, dest_root: Path, base: str, order: int, dry_run: bool,
             reserve_unique_name, log_lock: threading.Lock):
    """
    Worker: reserve a unique destination name, then copy (unless dry-run).
    Returns (src_name, final_dst_name, status, error_message_or_None)
    """
    ext = src.suffix.lower()
    desired = f"{base}{order}{ext}"
    final_name = reserve_unique_name(desired)
    dst = dest_root / final_name

    if dry_run:
        with log_lock:
            print(f"  [DRY] {src.name}  ->  {final_name}")
        return (src.name, final_name, "DRY", None)

    try:
        shutil.copy2(src, dst)
        with log_lock:
            print(f"  [OK ] {src.name}  ->  {final_name}")
        return (src.name, final_name, "OK", None)
    except Exception as e:
        with log_lock:
            print(f"  [ERR] {src.name}  ->  {final_name} :: {e}")
        return (src.name, final_name, "ERR", str(e))


def main():
    parser = argparse.ArgumentParser(
        description="Pick 11 key TIFF frames from 'scan' folders and copy/rename them safely to Desktop/david (threaded)."
    )
    parser.add_argument("root", help="Root folder to search (e.g. \\\\zfstor6\\dingo\\proposal)")
    parser.add_argument("--dest", default=str(Path.home() / "Desktop" / "david"),
                        help="Destination folder (default: ~/Desktop/david)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Simulate only; do not copy files.")
    parser.add_argument("--workers", type=int, default=max(2, (os.cpu_count() or 4)),
                        help="Number of copy worker threads (default: CPU count, min 2).")
    args = parser.parse_args()

    root = Path(args.root)
    dest_root = ensure_dest_folder(Path(args.dest))

    if not root.exists():
        print(f"[ERROR] Root path does not exist: {root}")
        sys.exit(1)

    workers = max(2, args.workers or 2)
    total_copied = 0
    log_lock = threading.Lock()
    reserve_unique_name = build_unique_name_reserver(dest_root)

    # Collect copy jobs across all qualifying scan folders
    jobs = []  # list of (src, base, order)
    for scan_dir in find_scan_dirs(root):
        files = list_tiffs(scan_dir)
        if len(files) <= 100:
            print(f"[SKIP] {scan_dir} has {len(files)} TIFFs (need >100).")
            continue

        files.sort(key=numeric_key)
        n = len(files)
        idxs = pick_indices(n)
        base = rel_base_name(root, scan_dir)

        print(f"\n[INFO] Processing: {scan_dir}")
        print(f"       TIFF count: {n}, selected indices: {idxs}")
        print(f"       New filename base: {base}")

        for order, idx in enumerate(idxs):
            src = files[idx]
            jobs.append((src, base, order))

    if not jobs:
        print("\n[INFO] No files to copy.")
        print(f"Destination: {dest_root}")
        return

    print(f"\n[INFO] Starting threaded copy with {workers} workers "
          f"({'DRY RUN' if args.dry_run else 'COPY MODE'})...")
    # ThreadPool for copy jobs
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futures = []
        for (src, base, order) in jobs:
            futures.append(
                ex.submit(copy_one, src, dest_root, base, order, args.dry_run,
                          reserve_unique_name, log_lock)
            )
        # Ensure all complete
        for f in as_completed(futures):
            src_name, final_dst_name, status, err = f.result()
            if status == "OK":
                total_copied += 1

    print(f"\n[DONE] Total files {'planned' if args.dry_run else 'copied'}: {total_copied if not args.dry_run else len(jobs)}")
    print(f"       Destination: {dest_root}")
    if args.dry_run and total_copied:
        # In dry-run we don't increment total_copied; just a friendly note.
        pass


if __name__ == "__main__":
    main()
