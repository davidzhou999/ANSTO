import os
import re
import math
import shutil
from pathlib import Path


def find_scan_folders_with_many_tiff(root_folder, min_files=100):
    """
    在指定根文件夹中查找包含至少min_files个.tiff或.tif文件的scan文件夹
    """
    scan_folders = []

    for root, dirs, files in os.walk(root_folder):
        # 检查当前文件夹名是否为scan
        if os.path.basename(root).lower() == "scan":
            # 统计.tiff和.tif文件
            tiff_files = [f for f in files if f.lower().endswith(('.tiff', '.tif'))]

            if len(tiff_files) >= min_files:
                scan_folders.append((root, tiff_files))
                print(f"找到符合条件的scan文件夹: {root}, 包含 {len(tiff_files)} 个图像文件")

    return scan_folders


def extract_number(filename):
    """
    从文件名中提取数字部分
    """
    # 匹配文件名末尾的数字
    match = re.search(r'(\d+)\.(tiff|tif)$', filename, re.IGNORECASE)
    if match:
        return int(match.group(1))
    return None


def select_sample_images(tiff_files, percentages=[0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]):
    """
    选择指定百分比的图像文件
    """
    # 按数字顺序排序文件
    numbered_files = []
    for f in tiff_files:
        num = extract_number(f)
        if num is not None:
            numbered_files.append((num, f))

    if not numbered_files:
        return []

    numbered_files.sort(key=lambda x: x[0])

    selected_files = []
    total = len(numbered_files)

    for p in percentages:
        if p == 0:
            # 第一个文件
            selected_files.append(numbered_files[0][1])
        elif p == 100:
            # 最后一个文件
            selected_files.append(numbered_files[-1][1])
        else:
            # 计算百分比位置（向上取整）
            index = math.ceil(p / 100 * total) - 1
            index = max(0, min(index, total - 1))  # 确保索引在有效范围内
            selected_files.append(numbered_files[index][1])

    return selected_files


def get_folder_name_prefix(scan_folder_path, root_folder):
    """
    根据scan文件夹路径生成文件夹名前缀
    例如: \\zfstor6\dingo\proposal\abc\def\hij\scan -> abc_def_hij
    """
    # 获取相对于根文件夹的路径
    relative_path = os.path.relpath(os.path.dirname(scan_folder_path), root_folder)

    # 如果相对路径是当前目录，使用根文件夹的最后一部分
    if relative_path == ".":
        folder_prefix = os.path.basename(root_folder.rstrip(os.sep))
    else:
        # 将路径分隔符替换为下划线
        folder_prefix = relative_path.replace(os.sep, "_")

    return folder_prefix


def copy_images_with_new_names(scan_folder_path, selected_files, output_folder, root_folder):
    """
    复制选中的图像到输出文件夹，使用新文件名
    """
    # 获取文件夹名前缀
    folder_prefix = get_folder_name_prefix(scan_folder_path, root_folder)

    # 创建输出文件夹
    os.makedirs(output_folder, exist_ok=True)

    copied_files = []

    for i, filename in enumerate(selected_files):
        # 源文件路径
        src_path = os.path.join(scan_folder_path, filename)

        # 获取原文件的扩展名
        _, ext = os.path.splitext(filename)

        # 新文件名：文件夹前缀 + 序号 (0-10)
        new_filename = f"{folder_prefix}{i}{ext}"
        dst_path = os.path.join(output_folder, new_filename)

        # 复制文件
        shutil.copy2(src_path, dst_path)
        copied_files.append((src_path, dst_path))
        print(f"已复制: {filename} -> {new_filename}")

    return copied_files


def main():
    # 配置参数
    root_folder = r"\\zfstor6\dingo\proposal"  # 搜索的根文件夹
    output_folder = os.path.join(os.path.expanduser("~"), "Desktop", "david")  # 输出文件夹

    print("开始搜索符合条件的scan文件夹...")

    # 1. 查找符合条件的scan文件夹
    scan_folders = find_scan_folders_with_many_tiff(root_folder, min_files=100)

    if not scan_folders:
        print("未找到符合条件的scan文件夹")
        return

    print(f"\n共找到 {len(scan_folders)} 个符合条件的scan文件夹")

    # 2. 对每个符合条件的scan文件夹进行处理
    for scan_folder_path, tiff_files in scan_folders:
        print(f"\n处理文件夹: {scan_folder_path}")

        # 选择样本图像
        selected_files = select_sample_images(tiff_files)

        if not selected_files:
            print("无法选择样本图像，跳过此文件夹")
            continue

        print(f"选中的图像: {selected_files}")

        # 复制图像到目标文件夹
        copied_files = copy_images_with_new_names(scan_folder_path, selected_files, output_folder, root_folder)

        print(f"已完成文件夹 {scan_folder_path} 的处理")


if __name__ == "__main__":
    main()