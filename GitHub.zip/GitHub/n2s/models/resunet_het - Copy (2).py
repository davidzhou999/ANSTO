# =============================
# models/resunet_het.py
# =============================
import torch
import torch.nn as nn
import torch.nn.functional as F

class ConvGN(nn.Module):
    def __init__(self, in_ch, out_ch, k=3, g=8):
        super().__init__()
        p = k // 2
        self.conv = nn.Conv2d(in_ch, out_ch, k, padding=p, bias=False)
        self.gn   = nn.GroupNorm(num_groups=min(g, out_ch), num_channels=out_ch)
        self.act  = nn.SiLU(inplace=True)
    def forward(self, x):
        x = self.conv(x)
        x = self.gn(x)
        return self.act(x)

class ResBlock(nn.Module):
    def __init__(self, ch):
        super().__init__()
        self.c1 = ConvGN(ch, ch)
        self.c2 = ConvGN(ch, ch)
    def forward(self, x):
        return x + self.c2(self.c1(x))

class DownBlock(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.pool = nn.MaxPool2d(2)
        self.conv = ConvGN(in_ch, out_ch)
        self.res  = ResBlock(out_ch)
    def forward(self, x):
        x = self.pool(x)
        x = self.conv(x)
        return self.res(x)

class UpBlock(nn.Module):
    def __init__(self, in_ch, skip_ch, out_ch):
        super().__init__()
        self.up   = nn.ConvTranspose2d(in_ch, out_ch, kernel_size=2, stride=2)
        self.fuse = ConvGN(out_ch + skip_ch, out_ch)
        self.res  = ResBlock(out_ch)
    def forward(self, x, skip):
        x = self.up(x)
        if x.shape[-2] != skip.shape[-2] or x.shape[-1] != skip.shape[-1]:
            x = F.interpolate(x, size=skip.shape[-2:], mode='bilinear', align_corners=False)
        x = torch.cat([skip, x], dim=1)
        x = self.fuse(x)
        return self.res(x)

class ResUNetHet(nn.Module):
    def __init__(self, in_ch=1, base=64, depth=4, blind_spot=False):
        super().__init__()
        assert depth >= 1
        self.blind_spot = blind_spot

        self.stem = ConvGN(in_ch, base)
        self.stem_res = ResBlock(base)

        enc_chs = [base * (2 ** i) for i in range(1, depth)]
        bottleneck_ch = base * (2 ** depth)

        self.downs = nn.ModuleList()
        in_c = base
        for c in enc_chs:
            self.downs.append(DownBlock(in_c, c))
            in_c = c

        self.bottleneck = DownBlock(in_c, bottleneck_ch)

        self.ups = nn.ModuleList()
        dec_in = bottleneck_ch
        for skip_c in reversed(enc_chs):
            self.ups.append(UpBlock(dec_in, skip_c, skip_c))
            dec_in = skip_c
        self.up_last = UpBlock(dec_in, base, base)

        self.head = nn.Conv2d(base, 2, kernel_size=1)

    def forward(self, x):
        x0 = self.stem_res(self.stem(x))
        skips = [x0]
        x_ = x0
        for down in self.downs:
            x_ = down(x_)
            skips.append(x_)
        x_ = self.bottleneck(x_)
        for up, skip in zip(self.ups, reversed(skips[1:])):
            x_ = up(x_, skip)
        x_ = self.up_last(x_, skips[0])
        out = self.head(x_)
        mu, logv = torch.chunk(out, 2, dim=1)
        logv = torch.clamp(logv, min=-7.0, max=5.0)
        return mu, logv

class ResUNetHetero(ResUNetHet):
    """Alias for back-compat with older scripts."""
    pass

__all__ = ["ConvGN", "ResBlock", "DownBlock", "UpBlock", "ResUNetHet", "ResUNetHetero"]
