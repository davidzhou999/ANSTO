
import torch
import torch.nn as nn
import torch.nn.functional as F

class ConvBlock(nn.Module):
    def __init__(self, in_ch, out_ch, k=3, s=1, p=1, groups=8, blind_spot=False, shift=(0,0)):
        super().__init__()
        self.blind_spot = blind_spot
        self.shift = shift
        self.pad = nn.ReflectionPad2d(p)
        self.conv = nn.Conv2d(in_ch, out_ch, k, s, padding=0)
        self.gn = nn.GroupNorm(num_groups=min(groups, out_ch), num_channels=out_ch)
        self.act = nn.SiLU(inplace=True)

    def forward(self, x):
        if self.blind_spot and (self.shift != (0,0)):
            x = torch.roll(x, shifts=self.shift, dims=(-2, -1))
        x = self.pad(x); x = self.conv(x); x = self.gn(x)
        return self.act(x)

class ResBlock(nn.Module):
    def __init__(self, ch, blind_spot=False, shift=(0,0)):
        super().__init__()
        self.c1 = ConvBlock(ch, ch, blind_spot=blind_spot, shift=shift)
        self.c2 = ConvBlock(ch, ch, blind_spot=blind_spot, shift=(0,0))
    def forward(self, x): return x + self.c2(self.c1(x))

class Down(nn.Module):
    def __init__(self, in_ch, out_ch, blind_spot=False, shift=(0,0)):
        super().__init__()
        self.pool = nn.AvgPool2d(2)
        self.conv = ConvBlock(in_ch, out_ch, blind_spot=blind_spot, shift=shift)
        self.res = ResBlock(out_ch, blind_spot=blind_spot, shift=shift)
    def forward(self, x):
        x = self.pool(x); x = self.conv(x); return self.res(x)

class Up(nn.Module):
    def __init__(self, in_ch, out_ch, blind_spot=False, shift=(0,0)):
        super().__init__()
        self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False)
        self.conv = ConvBlock(in_ch, out_ch, blind_spot=blind_spot, shift=shift)
        self.res = ResBlock(out_ch, blind_spot=blind_spot, shift=shift)
    def forward(self, x, skip):
        x = self.up(x)
        dh = skip.size(-2) - x.size(-2)
        dw = skip.size(-1) - x.size(-1)
        if dh != 0 or dw != 0: x = F.pad(x, (0, dw, 0, dh))
        x = torch.cat([skip, x], dim=1); x = self.conv(x); return self.res(x)

class ResUNetHet(nn.Module):
    """Outputs 2 channels: [mu, logvar] for heteroscedastic Gaussian NLL."""
    def __init__(self, in_ch=1, base=64, depth=4, blind_spot=True):
        super().__init__()
        self.depth = depth
        self.inc = ConvBlock(in_ch, base)
        shifts = [(0,1), (1,0), (-1,0), (0,-1)] if blind_spot else [(0,0)]
        self.downs = nn.ModuleList()
        ch = base
        for d in range(depth):
            self.downs.append(Down(ch, ch*2, blind_spot=blind_spot, shift=shifts[d % len(shifts)])); ch *= 2
        self.bottleneck = ResBlock(ch, blind_spot=blind_spot, shift=shifts[(depth) % len(shifts)])
        self.ups = nn.ModuleList()
        for d in range(depth):
            self.ups.append(Up(ch, ch//2, blind_spot=blind_spot, shift=shifts[d % len(shifts)])); ch //= 2
        self.outc = nn.Conv2d(ch, 2, 1)  # mu, logvar

    def forward(self, x):
        x1 = self.inc(x); skips = [x1]; x_ = x1
        for down in self.downs: x_ = down(x_); skips.append(x_)
        x_ = self.bottleneck(x_)
        for i, up in enumerate(self.ups[::-1]): x_ = up(x_, skips[-(i+2)])
        out = self.outc(x_)
        mu, logvar = out[:, :1], out[:, 1:2]
        return mu, logvar
