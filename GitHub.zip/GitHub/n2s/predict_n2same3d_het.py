
import os, argparse, numpy as np, nibabel as nib, torch
from models.resunet3d import ResUNet3DHet

@torch.no_grad()
def tile3d(vol, model, tile=128, overlap=16, amp=True, device='cuda'):
    D,H,W = vol.shape
    step = tile - overlap
    out_mu = np.zeros_like(vol, dtype=np.float32)
    out_s  = np.zeros_like(vol, dtype=np.float32)
    wsum   = np.zeros_like(vol, dtype=np.float32)
    wz = np.hanning(tile).astype(np.float32); wy = np.hanning(tile).astype(np.float32); wx = np.hanning(tile).astype(np.float32)
    win = np.einsum('i,j,k->ijk', wz, wy, wx)
    for z in range(0, D, step):
        for y in range(0, H, step):
            for x in range(0, W, step):
                zs = min(z+tile, D); ys = min(y+tile, H); xs = min(x+tile, W)
                z0 = max(0, zs - tile); y0 = max(0, ys - tile); x0 = max(0, xs - tile)
                patch = vol[z0:zs, y0:ys, x0:xs]
                pd, ph, pw = patch.shape
                pad = ((0, tile-pd), (0, tile-ph), (0, tile-pw))
                patch = np.pad(patch, pad, mode='edge')
                ten = torch.from_numpy(patch).unsqueeze(0).unsqueeze(0).to(device)
                with torch.cuda.amp.autocast(enabled=amp):
                    mu, logv = model(ten)
                mu = mu.squeeze().float().cpu().numpy(); s  = (logv.exp().sqrt()).squeeze().float().cpu().numpy()
                mu = mu[:pd,:ph,:pw]; s = s[:pd,:ph,:pw]; w = win[:pd,:ph,:pw]
                out_mu[z0:z0+pd, y0:y0+ph, x0:x0+pw] += mu*w
                out_s [z0:z0+pd, y0:y0+ph, x0:x0+pw] += s*w
                wsum  [z0:z0+pd, y0:y0+ph, x0:x0+pw] += w
    out_mu /= (wsum + 1e-8); out_s /= (wsum + 1e-8)
    return out_mu, out_s

def main(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    ckpt = torch.load(args.checkpoint, map_location=device)
    model = ResUNet3DHet(in_ch=1, base=args.base, depth=args.depth).to(device)
    model.load_state_dict(ckpt['model'], strict=True)
    if 'ema' in ckpt and isinstance(ckpt['ema'], dict):
        for n, p in model.named_parameters():
            if n in ckpt['ema']: p.data.copy_(ckpt['ema'][n])
    model.eval()
    os.makedirs(args.output_dir, exist_ok=True)
    files = [os.path.join(args.input_dir, f) for f in os.listdir(args.input_dir) if f.lower().endswith(('.nii','.nii.gz'))]
    files = sorted(files); print(f"Found {len(files)} volumes")
    for fp in files:
        vol = nib.load(fp).get_fdata().astype(np.float32)
        pmin = np.percentile(vol, 0.5); pmax = np.percentile(vol, 99.5)
        v = np.clip((vol - pmin) / (pmax - pmin + 1e-8), 0.0, 1.0)
        mu, s = tile3d(v, model, tile=args.tile, overlap=args.overlap, amp=args.amp, device=device)
        base = os.path.splitext(os.path.basename(fp))[0].replace('.nii','')
        nib.save(nib.Nifti1Image(mu.astype(np.float32), affine=np.eye(4)), os.path.join(args.output_dir, base + "_den.nii.gz"))
        np.savez_compressed(os.path.join(args.output_dir, base + "_sigma.npz"), sigma=s.astype(np.float32))
        print("Saved", base)

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--checkpoint', type=str, required=True)
    ap.add_argument('--input_dir', type=str, required=True)
    ap.add_argument('--output_dir', type=str, required=True)
    ap.add_argument('--tile', type=int, default=128)
    ap.add_argument('--overlap', type=int, default=16)
    ap.add_argument('--amp', action='store_true')
    ap.add_argument('--base', type=int, default=32)
    ap.add_argument('--depth', type=int, default=4)
    args = ap.parse_args(); main(args)
