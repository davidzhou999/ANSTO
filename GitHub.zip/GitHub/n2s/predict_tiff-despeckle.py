#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Predict (denoise) TIFF images with N2Same-heteroscedastic UNet.

Highlights:
  - Output suffix via --suffix (default "_den").
  - Symmetric hybrid speckle mask (bright & dark) built in normalized space:
      residual-MAD (vs. net output), hi/lo percentiles, and global Z-score.
  - Gentle multiscale median inpainting + optional dilation.
  - Cosine (Hann^2) overlap blending to eliminate tile-grid seams.
  - Optional global percentile normalization for folder-stable brightness.
  - Optional affine brightness match to noisy on unmasked pixels.
  - Mixed precision + inference_mode for speed.
"""

import os, math, argparse
import numpy as np
import tifffile as tiff
from tqdm import tqdm

import torch
import torch.nn.functional as F
from scipy.ndimage import median_filter, label, binary_opening, binary_dilation

torch.backends.cudnn.benchmark = True
torch.set_float32_matmul_precision('high')

# --- Model import ---
try:
    from models.resunet_het import ResUNetHetero
except Exception:
    from models.resunet_het import ResUNetHet as ResUNetHetero


# ------------------------ Utilities ------------------------

def percentiles(img, lo=0.5, hi=99.5):
    p = np.percentile(img, [lo, hi])
    p0, p1 = float(p[0]), float(p[1])
    if not np.isfinite(p0) or not np.isfinite(p1) or p1 <= p0:
        p0 = float(np.min(img))
        p1 = float(max(np.max(img), p0 + 1.0))
    return p0, p1

def normalize(img, p0, p1):
    x = (img.astype(np.float32) - p0) / max(p1 - p0, 1e-6)
    return np.clip(x, 0.0, 1.0)

def inverse_norm(y01, p0, p1):
    return y01 * (p1 - p0) + p0

def mad(x):
    med = np.median(x)
    return np.median(np.abs(x - med)) + 1e-6

def robust_affine_match(src, dst, mask=None, sample_px=200_000):
    """Fit a*dst + b ≈ src using LS on (unmasked) pixels."""
    h, w = src.shape
    if mask is None:
        idx = np.random.choice(h * w, size=min(sample_px, h * w), replace=False)
    else:
        keep = (~mask.astype(bool)).reshape(-1)
        ids = np.flatnonzero(keep)
        if ids.size == 0:
            return 1.0, 0.0
        idx = np.random.choice(ids, size=min(sample_px, ids.size), replace=False)
    xs = src.reshape(-1)[idx]
    ys = dst.reshape(-1)[idx]
    Y = np.vstack([ys, np.ones_like(ys)]).T
    sol, *_ = np.linalg.lstsq(Y, xs, rcond=None)
    a, b = float(sol[0]), float(sol[1])
    if not np.isfinite(a) or abs(a) < 1e-6: a = 1.0
    if not np.isfinite(b): b = 0.0
    return a, b

def hybrid_speckle_mask_norm(noisy01, den01,
                             hi_pctl=99.95, lo_pctl=0.05,
                             z_tau_hi=6.0, z_tau_lo=6.0,
                             res_tau_hi=3.0, res_tau_lo=3.0,
                             connect=True, max_blob=600):
    """
    Build mask in *normalized* space (0..1).
    Union of:
      - residual spikes: r01 = noisy01 - den01 (both tails via MAD)
      - extreme high/low percentiles on noisy01
      - global Z-score outliers on noisy01
    """
    noisy01 = noisy01.astype(np.float32)
    den01   = den01.astype(np.float32)

    r  = noisy01 - den01
    s  = mad(r)
    m_res_hi = r > (+res_tau_hi * s)
    m_res_lo = r < (-res_tau_lo * s)

    hp = np.percentile(noisy01, hi_pctl)
    lp = np.percentile(noisy01, lo_pctl)
    m_hi = noisy01 > hp
    m_lo = noisy01 < lp

    mu   = float(np.mean(noisy01))
    sigma= float(np.std(noisy01)) + 1e-6
    z    = (noisy01 - mu) / sigma
    m_zh = z > +z_tau_hi
    m_zl = z < -z_tau_lo

    mask = (m_res_hi | m_res_lo | m_hi | m_lo | m_zh | m_zl)

    if connect:
        mask = binary_opening(mask, structure=np.ones((3, 3), bool))

    if max_blob and max_blob > 0:
        lab, n = label(mask)
        for i in range(1, n + 1):
            idx = (lab == i)
            if idx.sum() > max_blob:
                mask[idx] = False

    return mask.astype(np.uint8)

def dilate_mask(mask, iters=1):
    if iters <= 0: return mask
    return binary_dilation(mask.astype(bool), structure=np.ones((3,3), bool),
                           iterations=iters).astype(np.uint8)

def despeckle_inpaint_multiscale(den, mask, ks=(5, 9)):
    out = den.copy()
    m = mask.astype(bool)
    for k in ks:
        med = median_filter(out, size=k)
        out[m] = med[m]
    return out

def percentiles_uint16_write(arr, p0=None, p1=None):
    if p0 is None or p1 is None or not np.isfinite(p0) or p1 <= p0:
        p0, p1 = percentiles(arr, 0.5, 99.5)
    x = np.clip((arr - p0) / max(p1 - p0, 1e-6), 0, 1)
    return (x * 65535.0 + 0.5).astype(np.uint16), p0, p1


# ---------- Tiling (seamless) ----------

def tilize(x01, tile, overlap):
    """Split [H,W] float32 [0..1] into tiles with reflect padding."""
    h, w = x01.shape
    pad = overlap
    xpad = np.pad(x01, ((pad, pad), (pad, pad)), mode='reflect')
    H, W = xpad.shape

    stride = tile - 2 * overlap
    ny = math.ceil((h - 2 * overlap) / stride)
    nx = math.ceil((w - 2 * overlap) / stride)

    tiles, coords = [], []
    for iy in range(ny):
        for ix in range(nx):
            y0 = iy * stride
            x0 = ix * stride
            y1 = y0 + tile
            x1 = x0 + tile
            if y1 > H:
                y0 = H - tile; y1 = H
            if x1 > W:
                x0 = W - tile; x1 = W
            slab = xpad[y0:y1, x0:x1]
            tiles.append(slab); coords.append((y0, y1, x0, x1))
    return tiles, coords, (h, w), pad

def untilize(tiles_out, coords, full_hw, pad, overlap, blend_power=2.0):
    Hpad = full_hw[0] + 2 * pad
    Wpad = full_hw[1] + 2 * pad
    acc = np.zeros((Hpad, Wpad), np.float32)
    wgt = np.zeros((Hpad, Wpad), np.float32)

    th, tw = tiles_out[0].shape
    oy = ox = overlap

    # Hann window ^ power (reduces seams)
    wy = np.ones(th, np.float32); wx = np.ones(tw, np.float32)
    if oy > 0:
        ramp = 0.5 - 0.5*np.cos(np.linspace(0, np.pi, oy))
        ramp = ramp**blend_power
        wy[:oy] *= ramp; wy[-oy:] *= ramp[::-1]
    if ox > 0:
        ramp = 0.5 - 0.5*np.cos(np.linspace(0, np.pi, ox))
        ramp = ramp**blend_power
        wx[:ox] *= ramp; wx[-ox:] *= ramp[::-1]
    mask = np.outer(wy, wx)

    for out, (y0, y1, x0, x1) in zip(tiles_out, coords):
        acc[y0:y1, x0:x1] += out * mask
        wgt[y0:y1, x0:x1] += mask

    xpad = acc / np.maximum(wgt, 1e-6)
    return xpad[pad:pad + full_hw[0], pad:pad + full_hw[1]]

@torch.inference_mode()
def denoise_2d(net, img01, tile, overlap, device, use_autocast):
    tiles, coords, full_hw, pad = tilize(img01, tile, overlap)
    outs = []
    for slab in tiles:
        t = torch.from_numpy(slab[None, None]).to(device, non_blocking=True)
        if use_autocast:
            with torch.amp.autocast('cuda'):
                out = net(t)
        else:
            out = net(t)
        mu = out[0] if isinstance(out, (tuple, list)) else out
        mu = mu.squeeze().detach().float().cpu().numpy()
        # tiny DC alignment to reduce faint darkening from normalization drift
        mu += float(np.mean(slab) - np.mean(mu))
        outs.append(mu)
    return untilize(outs, coords, full_hw, pad, overlap, blend_power=2.0)


# ------------------------ Main ------------------------

def build_net(device):
    try:
        net = ResUNetHetero(in_ch=1, base=64).to(device)
    except TypeError:
        try:
            net = ResUNetHetero(in_ch=1, ch=64).to(device)
        except TypeError:
            net = ResUNetHetero(1).to(device)
    net.eval()
    return net

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ckpt', required=True)
    ap.add_argument('--inp', required=True)
    ap.add_argument('--out_dir', required=True)
    ap.add_argument('--tile', type=int, default=1024)
    ap.add_argument('--overlap', type=int, default=128)

    # Normalization
    ap.add_argument('--norm', choices=['percentile'], default='percentile')
    ap.add_argument('--norm_pctl', type=float, nargs=2, default=[0.5, 99.5])
    ap.add_argument('--global_norm', action='store_true')
    ap.add_argument('--global_take', type=int, default=64)

    # Mixed-precision
    ap.add_argument('--autocast', action='store_true')

    # Despeckle (symmetric) in normalized space
    ap.add_argument('--despeckle', action='store_true')
    ap.add_argument('--desp_ksize', type=int, default=9)
    ap.add_argument('--desp_tau', type=float, default=3.0, help='Residual MAD threshold for BOTH tails.')
    ap.add_argument('--hi_pctl', type=float, default=99.95)
    ap.add_argument('--lo_pctl', type=float, default=0.05)
    ap.add_argument('--z_tau_hi', type=float, default=6.0)
    ap.add_argument('--z_tau_lo', type=float, default=6.0)
    ap.add_argument('--desp_max_blob', type=int, default=600, help='0 = no blob size limit')
    ap.add_argument('--desp_dilate', type=int, default=1, help='mask dilation iterations')
    ap.add_argument('--desp_source', choices=['denoised', 'noisy'], default='denoised')

    # Brightness match (affine)
    ap.add_argument('--brightness_match', action='store_true')

    # Output
    ap.add_argument('--out_dtype', choices=['original','uint16','float32'], default='uint16')
    ap.add_argument('--suffix', type=str, default='_den', help='appended before extension for outputs')
    ap.add_argument('--save_debug', action='store_true')
    ap.add_argument('--print_stats', action='store_true')

    args = ap.parse_args()

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"[INFO] device: {device.type}, AMP={'on' if args.autocast else 'off'}")

    # Collect paths
    if os.path.isdir(args.inp):
        exts = ('.tif', '.tiff')
        paths = sorted([os.path.join(args.inp, f) for f in os.listdir(args.inp) if f.lower().endswith(exts)])
    else:
        paths = [args.inp]
    print(f"[INFO] images: {len(paths)}")
    os.makedirs(args.out_dir, exist_ok=True)

    # Build & load model
    net = build_net(device)
    sd = torch.load(args.ckpt, map_location=device)
    state = sd.get('model', sd)
    missing, unexpected = net.load_state_dict(state, strict=False)
    if missing or unexpected:
        print(f"[WARN] state_dict mismatch. missing={len(missing)} unexpected={len(unexpected)}")

    # Global p0/p1 (optional)
    global_p0p1 = None
    if args.global_norm and len(paths) > 1:
        take = min(args.global_take, len(paths))
        idxs = np.random.choice(len(paths), size=take, replace=False)
        p0s, p1s = [], []
        for i in idxs:
            im = tiff.imread(paths[i])
            p0, p1 = percentiles(im, *args.norm_pctl)
            p0s.append(p0); p1s.append(p1)
        global_p0p1 = (float(np.median(p0s)), float(np.median(p1s)))
        print(f"[INFO] global p0={global_p0p1[0]:.3f} p1={global_p0p1[1]:.3f}")

    # Predict
    for fp in tqdm(paths, desc="Predict"):
        noisy = tiff.imread(fp)
        if noisy.ndim != 2:
            raise ValueError(f"Expected 2D grayscale TIFF, got shape {noisy.shape} for {fp}")
        orig_dtype = noisy.dtype

        # Normalize
        p0, p1 = global_p0p1 if global_p0p1 else percentiles(noisy, *args.norm_pctl)
        noisy01 = normalize(noisy, p0, p1)

        # Denoise (01 space)
        den01 = denoise_2d(net, noisy01, args.tile, args.overlap, device, args.autocast)

        # Mask + inpaint
        mask = None
        if args.despeckle:
            src_for_mask = den01 if args.desp_source == 'denoised' else noisy01
            mask = hybrid_speckle_mask_norm(
                noisy01=src_for_mask, den01=den01,
                hi_pctl=args.hi_pctl, lo_pctl=args.lo_pctl,
                z_tau_hi=args.z_tau_hi, z_tau_lo=args.z_tau_lo,
                res_tau_hi=args.desp_tau, res_tau_lo=args.desp_tau,
                connect=True, max_blob=args.desp_max_blob
            )
            if args.desp_dilate > 0:
                mask = dilate_mask(mask, iters=args.desp_dilate)
            # two-pass median is gentler than a single huge kernel
            den01 = despeckle_inpaint_multiscale(den01, mask, ks=(5, 9))
            den01 = despeckle_inpaint_multiscale(den01, mask, ks=(7,))

        # Restore to original scale
        den = inverse_norm(den01, p0, p1).astype(np.float32)

        # Optional brightness match to noisy (ignoring masked px)
        if args.brightness_match:
            a, b = robust_affine_match(noisy.astype(np.float32), den, mask=mask)
            den = a * den + b
        else:
            a = b = None

        if args.print_stats:
            msum = int(mask.sum()) if mask is not None else 0
            print(f"[STATS] {os.path.basename(fp)} p0={p0:.2f} p1={p1:.2f} "
                  f"den[min,max]=[{float(den.min()):.2f},{float(den.max()):.2f}] "
                  f"a,b={'n/a' if a is None else f'{a:.3f},{b:.3f}'} mask_px={msum}")

        # Save (with suffix)
        stem = os.path.splitext(os.path.basename(fp))[0]
        outfp = os.path.join(args.out_dir, f"{stem}{args.suffix}.tif")
        if args.out_dtype == 'uint16':
            out_u16, _, _ = percentiles_uint16_write(den, p0, p1)
            tiff.imwrite(outfp, out_u16, dtype=np.uint16)
        elif args.out_dtype == 'float32':
            tiff.imwrite(outfp, den.astype(np.float32), dtype=np.float32)
        else:  # original
            if np.issubdtype(orig_dtype, np.floating):
                tiff.imwrite(outfp, den.astype(np.float32), dtype=np.float32)
            else:
                out_u16, _, _ = percentiles_uint16_write(den, p0, p1)
                tiff.imwrite(outfp, out_u16, dtype=np.uint16)

        # Debug exports
        if args.save_debug:
            dbg = os.path.join(args.out_dir, "_debug"); os.makedirs(dbg, exist_ok=True)
            tiff.imwrite(os.path.join(dbg, f"{stem}_noisy01.tif"),
                         (noisy01 * 65535).astype(np.uint16), dtype=np.uint16)
            tiff.imwrite(os.path.join(dbg, f"{stem}_den01.tif"),
                         (np.clip(den01, 0, 1) * 65535).astype(np.uint16), dtype=np.uint16)
            if mask is not None:
                tiff.imwrite(os.path.join(dbg, f"{stem}_mask.tif"),
                             (mask * 255).astype(np.uint8), dtype=np.uint8)

if __name__ == "__main__":
    main()

