# predict_tiff.py
import os, argparse, numpy as np, torch, tifffile as tiff
from models.resunet_het import ResUNetHetero
@torch.no_grad()
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--inp", required=True, help="folder of .tif/.tiff")
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--tile", type=int, default=896)
    ap.add_argument("--overlap", type=int, default=96)
    ap.add_argument("--autocast", action="store_true")
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    net = ResUNetHetero(in_ch=1).to(dev).eval()
    sd = torch.load(args.ckpt, map_location=dev)
    net.load_state_dict(sd["model"] if "model" in sd else sd)

    def norm01(x):
        x = x.astype(np.float32)
        mn, mx = float(x.min()), float(x.max())
        return (x - mn) / max(mx - mn, 1e-6)

    files = [f for f in sorted(os.listdir(args.inp)) if f.lower().endswith((".tif",".tiff"))]
    amp_ctx = (torch.amp.autocast("cuda") if args.autocast and dev=="cuda" else torch.no_grad())
    for fn in files:
        img = tiff.imread(os.path.join(args.inp, fn))
        base_dtype = img.dtype
        img = norm01(img)
        H, W = img.shape
        T, O = args.tile, args.overlap
        out = np.zeros_like(img, dtype=np.float32)
        wsum = np.zeros_like(img, dtype=np.float32)

        ys = list(range(0, max(1, H - T + 1), T - O)) or [0]
        xs = list(range(0, max(1, W - T + 1), T - O)) or [0]
        if ys[-1] + T < H: ys.append(H - T)
        if xs[-1] + T < W: xs.append(W - T)

        with amp_ctx:
            for y in ys:
                for x in xs:
                    patch = img[y:y+T, x:x+T]
                    if patch.shape != (T, T):
                        pad = np.zeros((T, T), np.float32)
                        pad[:patch.shape[0], :patch.shape[1]] = patch
                        patch = pad
                    ten = torch.from_numpy(patch)[None,None].to(dev)
                    mu, _ = net(ten)
                    den = mu[0,0].clamp(0,1).detach().cpu().numpy()
                    den = den[:min(T,H-y), :min(T,W-x)]
                    out[y:y+den.shape[0], x:x+den.shape[1]] += den
                    wsum[y:y+den.shape[0], x:x+den.shape[1]] += 1.0

        out = out / np.maximum(wsum, 1e-6)
        if base_dtype == np.uint16:
            out = (out * 65535.0 + 0.5).astype(np.uint16)
        elif base_dtype == np.uint8:
            out = (out * 255.0 + 0.5).astype(np.uint8)
        else:
            out = out.astype(np.float32)
        tiff.imwrite(os.path.join(args.out_dir, fn), out, compression=None)

if __name__ == "__main__":
    main()

