import os, glob, math, numpy as np, torch, tifffile as tiff
from torchvision.utils import save_image
from models.resunet_het import ResUNetHetero

ckpt_path = "data/n2same_het_pretrained.pt"      # BEST
roots     = ["data/test_data"]                   # same as training
outdir    = "runs/eval_quick"; os.makedirs(outdir, exist_ok=True)

device = "cuda" if torch.cuda.is_available() else "cpu"
net = ResUNetHetero(in_ch=1, base=64).to(device).eval()
sd = torch.load(ckpt_path, map_location=device)
net.load_state_dict(sd["model"] if isinstance(sd, dict) and "model" in sd else sd)

def to01(x):
    x = x.astype(np.float32)
    if x.max() == x.min(): return np.zeros_like(x, dtype=np.float32)
    return (x - x.min())/(x.max()-x.min())

def center_crop(img, size=1024):
    h,w = img.shape
    ch = min(size, h); cw = min(size, w)
    y0 = (h - ch)//2; x0 = (w - cw)//2
    return img[y0:y0+ch, x0:x0+cw]

def psnr(a,b, eps=1e-10):
    mse = float(np.mean((a-b)**2))
    return 20.0*np.log10(1.0) - 10.0*np.log10(max(mse, eps))

def ssim_simple(a,b, eps=1e-6):
    # simple luminance/contrast-structure proxy (not full SSIM; good enough for a quick check)
    mu_a, mu_b = a.mean(), b.mean()
    sa, sb = a.std(), b.std()
    num = (2*mu_a*mu_b + 0.01)*(2*sa*sb + 0.03)
    den = (mu_a**2 + mu_b**2 + 0.01)*((sa**2) + (sb**2) + 0.03)
    return float(num/(den+eps))

torch.set_grad_enabled(False)
psnrs, ssims = [], []
paths = []
for r in roots:
    paths += sorted(glob.glob(os.path.join(r, "**", "*.tif*"), recursive=True))

paths = paths[:16]  # quick pass
for i, fp in enumerate(paths, 1):
    img = tiff.imread(fp)
    if img.ndim == 3:  # handle (H,W,C) by taking a single channel
        img = img[...,0]
    img = to01(img)
    img = center_crop(img, 1024)

    x = torch.from_numpy(img)[None,None].to(device)
    with torch.cuda.amp.autocast():
        mu, logv = net(x)      # model returns (mean, logvar)
        den = mu.clamp(0,1)    # predicted clean

    a = img
    b = den.squeeze().detach().float().cpu().numpy()
    psnrs.append(psnr(a,b)); ssims.append(ssim_simple(a,b))

    save_image(den.cpu(), os.path.join(outdir, f"den_{i:03d}.png"))
    if i%4==0: print(f"[{i:02d}] PSNR={psnrs[-1]:.2f}dB  SSIM~{ssims[-1]:.4f}  {os.path.basename(fp)}")

print("----")
print(f"AVG over {len(psnrs)} samples:  PSNR={np.mean(psnrs):.2f} dB   SSIM~{np.mean(ssims):.4f}")
print(f"Samples saved to: {outdir}")


