
import os, re, argparse, numpy as np, tifffile as tiff

def load_stack(folder, use_log_suffix=True, max_proj=None, downsample=1):
    files = sorted([f for f in os.listdir(folder) if f.lower().endswith(('.tif','.tiff'))])
    if use_log_suffix:
        files = [f for f in files if f.lower().endswith('_log.tif') or f.lower().endswith('_log.tiff')]
        if len(files)==0:
            raise FileNotFoundError("No *_log.tif[f] files found in input_dir.")
    if max_proj is not None:
        # sub-sample uniformly
        idx = np.linspace(0, len(files)-1, max_proj, dtype=int)
        files = [files[i] for i in idx]
    paths = [os.path.join(folder, f) for f in files]
    arr = [tiff.imread(p).astype(np.float32) / 1000.0 for p in paths]
    V = np.stack(arr, axis=0)  # [angles, H, W]
    if downsample > 1:
        V = V[:, ::downsample, ::downsample]
    return V, files

def parse_angles_from_filenames(files, angle_regex, scale=1.0, offset=0.0):
    rx = re.compile(angle_regex)
    ang = []
    for fn in files:
        m = rx.search(fn)
        if not m:
            raise ValueError(f"Angle regex '{angle_regex}' did not match filename: {fn}")
        a = float(m.group(1)) * scale + offset
        ang.append(a)
    return np.deg2rad(np.array(ang, dtype=np.float32))

def focus_measure(vol):
    # Tenengrad-like: sum of squared gradient magnitude on central slices
    import scipy.ndimage as ndi
    mid = vol.shape[0]//2
    sl = vol[mid]
    gx = ndi.sobel(sl, axis=1)
    gy = ndi.sobel(sl, axis=0)
    fm = np.mean(gx*gx + gy*gy)
    return float(fm)

def main(args):
    import tomopy
    data, names = load_stack(args.input_dir, use_log_suffix=not args.use_raw, max_proj=args.max_proj, downsample=args.downsample)
    if args.theta_mode == 'linspace':
        theta = np.linspace(np.deg2rad(args.theta_start_deg), np.deg2rad(args.theta_end_deg), data.shape[0], endpoint=True)
    elif args.theta_mode == 'file':
        with open(args.angles_file, 'r') as f:
            arr = [float(x.strip()) for x in f if x.strip()!='']
        assert len(arr) == data.shape[0]; theta = np.deg2rad(np.array(arr, dtype=np.float32))
    else:
        theta = parse_angles_from_filenames(names, args.angle_regex, args.angle_scale, args.angle_offset)

    if args.use_raw:
        eps = 1e-6
        data = -np.log(np.clip(data, eps, 10.0))

    centers = np.linspace(args.center_min, args.center_max, args.center_steps)
    scores = []
    for cen in centers:
        rec = tomopy.recon(data, theta, center=float(cen), algorithm='gridrec', filter_name='hann')
        rec = np.nan_to_num(rec, nan=0.0, posinf=0.0, neginf=0.0)
        scores.append(focus_measure(rec))
        print(f"center={cen:.3f} score={scores[-1]:.6f}")
    best_idx = int(np.argmax(scores))
    print(f"Best center = {centers[best_idx]:.3f} (score={scores[best_idx]:.6f})")

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--input_dir', type=str, required=True)
    ap.add_argument('--theta_mode', choices=['linspace','file','filename'], default='linspace')
    ap.add_argument('--theta_start_deg', type=float, default=0.0)
    ap.add_argument('--theta_end_deg', type=float, default=180.0)
    ap.add_argument('--angles_file', type=str)
    ap.add_argument('--angle_regex', type=str, default=r'(\\d+(?:\\.\\d+)?)')
    ap.add_argument('--angle_scale', type=float, default=1.0)
    ap.add_argument('--angle_offset', type=float, default=0.0)
    ap.add_argument('--use_raw', action='store_true')
    ap.add_argument('--max_proj', type=int, default=360, help='number of projections to subsample for quick sweep')
    ap.add_argument('--downsample', type=int, default=4, help='spatial downsample factor to speed up')
    ap.add_argument('--center_min', type=float, required=True)
    ap.add_argument('--center_max', type=float, required=True)
    ap.add_argument('--center_steps', type=int, default=21)
    args = ap.parse_args(); main(args)
