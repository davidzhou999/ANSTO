
import os, argparse, time, torch
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from models.resunet3d import ResUNet3DHet
from utils.niiio import NiftiLazyDataset
from utils.metrics_ext import HeteroscedasticNLL, CharbonnierLoss, gsure_vst, cnr_auto, ring_index
from utils.ema import EMA

def random_mask_3d(b, d, h, w, ratio=0.02, device='cpu'):
    m = torch.zeros((b,1,d,h,w), device=device)
    num = int(d*h*w*ratio)
    idx = torch.randint(0, d*h*w, (b, num), device=device)
    m = m.view(b,1,-1); m.scatter_(2, idx.unsqueeze(1), 1.0)
    return m.view(b,1,d,h,w)

def train(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    writer = SummaryWriter(args.log_dir)
    train_ds = NiftiLazyDataset(args.train_dir, patch=args.patch, repeat=args.iters_per_epoch)
    val_ds   = NiftiLazyDataset(args.val_dir,   patch=args.patch, repeat=max(64, args.batch*4))
    train_loader = DataLoader(train_ds, batch_size=args.batch, shuffle=False, num_workers=args.workers, pin_memory=True, drop_last=True)
    val_loader   = DataLoader(val_ds,   batch_size=args.batch, shuffle=False, num_workers=args.workers, pin_memory=True, drop_last=True)
    net = ResUNet3DHet(in_ch=1, base=args.base, depth=args.depth).to(device)
    opt = torch.optim.AdamW(net.parameters(), lr=args.lr, weight_decay=args.wd)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.epochs)
    scaler = torch.cuda.amp.GradScaler(enabled=args.amp)
    ema = EMA(net, decay=args.ema)
    nll = HeteroscedasticNLL(); stab = CharbonnierLoss(epsilon=args.eps)
    best_val = 1e9; global_step = 0
    for epoch in range(1, args.epochs+1):
        net.train(); t0 = time.time()
        for it, batch in enumerate(train_loader):
            batch = batch.to(device)
            B,_,D,H,W = batch.shape
            M1 = random_mask_3d(B,D,H,W, ratio=args.mask_ratio, device=device)
            M2 = random_mask_3d(B,D,H,W, ratio=args.mask_ratio, device=device)
            with torch.cuda.amp.autocast(enabled=args.amp):
                mu1, logv1 = net(batch * (1.0 - M1))
                mu2, logv2 = net(batch * (1.0 - M2))
                loss = 0.5*nll(mu1, logv1, batch, mask=M1) + 0.5*nll(mu2, logv2, batch, mask=M2)
                loss = loss + args.stab_w * (0.5*stab(mu1, batch, mask=M1) + 0.5*stab(mu2, batch, mask=M2))
            opt.zero_grad(set_to_none=True); scaler.scale(loss).backward(); scaler.step(opt); scaler.update(); ema.update(net)
            writer.add_scalar('train/loss_total', loss.item(), global_step); global_step += 1
        net.eval(); ema.apply_shadow(net)
        with torch.no_grad():
            vloss = 0.0
            for vb, batch in enumerate(val_loader):
                batch = batch.to(device)
                B,_,D,H,W = batch.shape
                M = random_mask_3d(B,D,H,W, ratio=args.mask_ratio, device=device)
                mu, logv = net(batch * (1.0 - M))
                l = nll(mu, logv, batch, mask=M)
                vloss += l.item()
            vloss /= max(1, vb+1); writer.add_scalar('val/loss_masked_nll', vloss, epoch)
            vb0 = next(iter(val_loader)).to(device)
            class _Wrap(torch.nn.Module):
                def __init__(self, net): super().__init__(); self.net = net
                def forward(self, inp): mu, _ = self.net(inp); return mu
            g = gsure_vst(_Wrap(net), vb0, sigma2=1.0, amp=args.amp); writer.add_scalar('val/gsure_proxy', g.item(), epoch)
            mu0, _ = net(vb0); mid = mu0.shape[-3]//2
            cnr, thr = cnr_auto(mu0[0,0,mid].detach().cpu()); writer.add_scalar('val/cnr_auto_mid', cnr, epoch)
            ri = ring_index(mu0[0,0,mid].detach().cpu()); writer.add_scalar('val/ring_index_mid', ri, epoch)
            if vloss < best_val:
                best_val = vloss; os.makedirs(os.path.dirname(args.save_path), exist_ok=True)
                torch.save({'model': net.state_dict(), 'ema': ema.shadow, 'args': vars(args)}, args.save_path)
        ema.restore(net); sched.step()
        print(f"Epoch {epoch:03d} | time {(time.time()-t0):.1f}s | val_nll {vloss:.6f} | best {best_val:.6f}")
    writer.close()

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--train_dir', type=str, required=True)
    ap.add_argument('--val_dir',   type=str, required=True)
    ap.add_argument('--save_path', type=str, default='data/n2same3d_het_best.pt')
    ap.add_argument('--log_dir',   type=str, default='logs')
    ap.add_argument('--patch', type=int, default=128)
    ap.add_argument('--batch', type=int, default=1)
    ap.add_argument('--workers', type=int, default=4)
    ap.add_argument('--iters_per_epoch', type=int, default=512)
    ap.add_argument('--epochs', type=int, default=100)
    ap.add_argument('--base', type=int, default=32)
    ap.add_argument('--depth', type=int, default=4)
    ap.add_argument('--lr', type=float, default=1e-3)
    ap.add_argument('--wd', type=float, default=1e-4)
    ap.add_argument('--amp', action='store_true')
    ap.add_argument('--ema', type=float, default=0.999)
    ap.add_argument('--mask_ratio', type=float, default=0.02)
    ap.add_argument('--eps', type=float, default=1e-3)
    ap.add_argument('--stab_w', type=float, default=0.05)
    args = ap.parse_args(); train(args)
