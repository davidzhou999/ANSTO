#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os, time, math, argparse, random, gc, traceback
from pathlib import Path

import numpy as np
import tifffile as tiff
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torch.cuda.amp import GradScaler
from contextlib import nullcontext
from datetime import timedelta

try:
    from tqdm import tqdm
except:
    tqdm = None  # falls back to simple prints

# ---- import your model -------------------------------------------------------
# expects models/resunet_het.py with class ResUNetHet(nn.Module)
from models.resunet_het import ResUNetHet


# ----------------------------- utils -----------------------------------------
def set_seed(seed: int = 1234):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(False)

def vram_gb():
    if torch.cuda.is_available():
        m = torch.cuda.max_memory_allocated() / (1024**3)
        c = torch.cuda.memory_allocated() / (1024**3)
        return f"{c:.2f}GB/{m:.2f}GB"
    return "CPU"

def human_time(sec):
    return str(timedelta(seconds=int(sec)))

def safe_autocast(enabled=True, bf16=False):
    if not enabled:
        return nullcontext()
    if bf16:
        return torch.amp.autocast("cuda", dtype=torch.bfloat16)
    return torch.amp.autocast("cuda")  # fp16 on Ada is also fine; bf16 is safest


# --------------------------- dataset -----------------------------------------
class N2SDataset(Dataset):
    """
    - Walks --roots for .tif/.tiff
    - Optional RAM cache (--io_cache) or memmap fallback
    - Percentile cache per-image (--pctl_cache)
    - Random patch extraction
    """
    def __init__(self, roots, patch=256, max_files=0, io_cache=False, pctl_cache=False):
        self.patch = patch
        self.files = []
        for r in roots:
            r = str(r)
            for root, _, fns in os.walk(r):
                for f in fns:
                    if f.lower().endswith(('.tif', '.tiff')):
                        self.files.append(os.path.join(root, f))
        self.files.sort()
        if max_files and len(self.files) > max_files:
            self.files = self.files[:max_files]

        self.io_cache = io_cache
        self.pctl_cache = pctl_cache
        self._ram = None
        self._pctl = {}  # idx -> (lo, hi)

        if self.io_cache:
            self._ram = []
            for fp in self.files:
                im = tiff.imread(fp)
                im = np.asarray(im, dtype=np.float32)
                self._ram.append(im)

    def __len__(self): return len(self.files)

    def new_epoch(self):
        if self.pctl_cache:
            self._pctl.clear()

    def _get_image(self, idx):
        if self._ram is not None:
            return self._ram[idx]
        # memmap keeps I/O light without full copies
        return np.asarray(tiff.memmap(self.files[idx]), dtype=np.float32)

    def _get_pctl(self, idx, img):
        if self.pctl_cache:
            p = self._pctl.get(idx)
            if p is None:
                lo, hi = np.percentile(img, [1.0, 99.5])
                self._pctl[idx] = (lo, hi)
                return lo, hi
            return p
        else:
            lo, hi = np.percentile(img, [1.0, 99.5])
            return lo, hi

    def __getitem__(self, idx):
        img = self._get_image(idx)
        # support HxW (grayscale)
        if img.ndim == 3 and img.shape[0] in (1,3):
            img = img[0] if img.shape[0] == 1 else np.mean(img, 0)

        H, W = img.shape
        ph = pw = self.patch
        if H < ph or W < pw:
            # center pad if image smaller than patch (rare)
            pad_h = max(0, ph - H); pad_w = max(0, pw - W)
            img = np.pad(img, ((pad_h//2, pad_h - pad_h//2),
                               (pad_w//2, pad_w - pad_w//2)),
                         mode='edge')
            H, W = img.shape

        y = np.random.randint(0, H - ph + 1)
        x = np.random.randint(0, W - pw + 1)
        patch = img[y:y+ph, x:x+pw]
        patch = np.ascontiguousarray(patch, dtype=np.float32)

        lo, hi = self._get_pctl(idx, img)
        if hi > lo:
            patch = (patch - lo) / (hi - lo)
        patch = np.clip(patch, 0.0, 1.0)

        # return 1xHxW
        return torch.from_numpy(patch).unsqueeze(0)


# ----------------------------- losses & masks --------------------------------
def hetero_nll(mu, logv, x, mask=None):
    """Gaussian NLL with learned log-variance."""
    if mask is None:
        mask = torch.ones_like(x)
    inv_var = torch.exp(-logv)
    nll = 0.5 * (logv + (x - mu)**2 * inv_var)
    return (nll * mask).mean()

def make_n2s_mask(x, drop=0.2):
    """Binary mask: 1 means 'observed' (keep), 0 means 'masked' (predict)."""
    if drop <= 0:  # no masking
        return torch.ones_like(x)
    keep = (torch.rand_like(x) > drop).float()
    return keep


# --------------------------------- train -------------------------------------
def train_one_epoch(net, dl, opt, scaler, device, args, epoch):
    net.train()
    running = 0.0
    n = max(1, getattr(args, "iters_per_epoch", 0) or len(dl))

    iterator = dl
    if tqdm is not None:
        iterator = tqdm(dl, total=n, ncols=110, desc=f"Train e{epoch}")

    t0 = time.time()
    it_count = 0
    for it, batch in enumerate(iterator, 1):
        if args.iters_per_epoch and it > args.iters_per_epoch:
            break

        batch = batch.to(device, non_blocking=True)
        M = make_n2s_mask(batch, args.drop)
        target = batch

        with safe_autocast(enabled=args.amp, bf16=args.bf16):
            mu, logv = net(batch * M)
            loss = hetero_nll(mu, logv, target, mask=(1.0 - M))  # predict masked pixels

        opt.zero_grad(set_to_none=True)
        scaler.scale(loss).backward()
        scaler.step(opt)
        scaler.update()

        running += loss.item()
        it_count += 1

        if tqdm is not None:
            iterator.set_postfix({
                "loss": f"{loss.item():.4f}",
                "vram": vram_gb()
            })

    avg = running / max(1, it_count)
    dt = time.time() - t0
    return avg, dt


@torch.no_grad()
def quick_eval(net, dl, device, args, max_batches=3):
    net.eval()
    running = 0.0
    cnt = 0
    for it, batch in enumerate(dl, 1):
        if it > max_batches: break
        batch = batch.to(device, non_blocking=True)
        M = make_n2s_mask(batch, args.drop)
        mu, logv = net(batch * M)
        loss = hetero_nll(mu, logv, batch, mask=(1.0 - M))
        running += loss.item()
        cnt += 1
    return running / max(1, cnt)


def save_ckpt(path, net, opt, scaler, epoch, best, args):
    ckpt = {
        "epoch": epoch,
        "best": best,
        "state_dict": net.state_dict(),
        "opt": opt.state_dict(),
        "scaler": scaler.state_dict(),
        "args": vars(args)
    }
    torch.save(ckpt, path)


# --------------------------------- main --------------------------------------
def main(args):
    set_seed(args.seed)
    torch.backends.cudnn.benchmark = True
    torch.set_num_threads(max(1, args.cpu_threads))

    device = torch.device("cuda" if torch.cuda.is_available() and not args.cpu else "cpu")
    print(f"[INFO] device: {device}, AMP={'on' if args.amp else 'off'}, BF16={'on' if args.bf16 else 'off'}")

    # dataset
    roots = [Path(r) for r in args.roots]
    ds = N2SDataset(
        roots=roots,
        patch=args.patch,
        max_files=args.max_files,
        io_cache=args.io_cache,
        pctl_cache=args.pctl_cache
    )
    if len(ds) == 0:
        raise RuntimeError(f"No TIFFs found under: {roots}")

    # split a tiny eval subset (by index stride)
    idx = np.arange(len(ds))
    ev = idx[:: max(10, len(ds)//20 or 10)]  # ~5-10% quick eval
    tr = np.setdiff1d(idx, ev)
    subset_train = torch.utils.data.Subset(ds, tr.tolist())
    subset_eval  = torch.utils.data.Subset(ds, ev.tolist())

    dl_train = DataLoader(
        subset_train,
        batch_size=args.batch,
        shuffle=True,
        num_workers=args.workers,
        pin_memory=True,
        persistent_workers=False if args.workers == 0 else True,
        drop_last=True
    )
    dl_eval = DataLoader(
        subset_eval,
        batch_size=min(args.batch, 4),
        shuffle=False,
        num_workers=max(0, min(2, args.workers)),
        pin_memory=True
    )

    # model
    net = ResUNetHet()
    net.to(device)

    opt = torch.optim.AdamW(net.parameters(), lr=args.lr, weight_decay=1e-4)
    scaler = GradScaler(enabled=args.amp)

    os.makedirs(Path(args.save_path).parent, exist_ok=True)
    best = float("inf")
    last_ckpt = Path(args.save_path).with_suffix(".last.pt")
    best_ckpt = Path(args.save_path)

    print(f"[INFO] train images: {len(subset_train)} | eval images: {len(subset_eval)}")
    print(f"[INFO] batch={args.batch}, patch={args.patch}, workers={args.workers}")
    print(f"[INFO] saving to: best={best_ckpt.name}, last={last_ckpt.name}")

    for ep in range(1, args.epochs + 1):
        ds.new_epoch()

        try:
            tr_loss, tr_sec = train_one_epoch(net, dl_train, opt, scaler, device, args, ep)
        except torch.cuda.OutOfMemoryError:
            print("\n[WARN] CUDA OOM during train. Trying to clear cache and reduce batch by half...")
            torch.cuda.empty_cache(); gc.collect()
            if args.batch > 1:
                args.batch = max(1, args.batch // 2)
                print(f"[INFO] New batch size: {args.batch}. Restarting epoch {ep}...")
                dl_train = DataLoader(
                    subset_train,
                    batch_size=args.batch,
                    shuffle=True,
                    num_workers=args.workers,
                    pin_memory=True,
                    persistent_workers=False if args.workers == 0 else True,
                    drop_last=True
                )
                tr_loss, tr_sec = train_one_epoch(net, dl_train, opt, scaler, device, args, ep)
            else:
                raise

        ev_loss = quick_eval(net, dl_eval, device, args, max_batches=args.eval_batches)

        # checkpointing
        save_ckpt(last_ckpt, net, opt, scaler, ep, best, args)
        if ev_loss < best:
            best = ev_loss
            save_ckpt(best_ckpt, net, opt, scaler, ep, best, args)

        print(f"[EPOCH {ep:03d}/{args.epochs}] "
              f"train_loss={tr_loss:.4f}  eval_loss={ev_loss:.4f}  "
              f"time={human_time(tr_sec)}  vram={vram_gb()}")

    print("[DONE] Best eval loss:", best)
    print(f"[DONE] Best checkpoint: {best_ckpt}")
    print(f"[DONE] Last checkpoint: {last_ckpt}")


# --------------------------------- CLI ---------------------------------------
def build_argparser():
    ap = argparse.ArgumentParser("N2S (heteroscedastic) trainer with rich progress & caching")
    ap.add_argument("--roots", nargs="+", required=True, help="One or more root folders of TIFFs")
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--iters_per_epoch", type=int, default=0, help="0=iterate full dataloader")
    ap.add_argument("--batch", type=int, default=4)
    ap.add_argument("--patch", type=int, default=256)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--drop", type=float, default=0.2, help="N2S mask drop rate")
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--amp", action="store_true")
    ap.add_argument("--bf16", action="store_true", help="Prefer bfloat16 autocast (Ada/4090 safe)")
    ap.add_argument("--cpu", action="store_true", help="Force CPU")
    ap.add_argument("--pctl_cache", action="store_true")
    ap.add_argument("--io_cache", action="store_true")
    ap.add_argument("--max_files", type=int, default=0)
    ap.add_argument("--eval_batches", type=int, default=3)
    ap.add_argument("--save_path", type=str, default="data/n2same_het_pretrained.pt")
    ap.add_argument("--seed", type=int, default=1234)
    ap.add_argument("--cpu_threads", type=int, default=8)
    return ap


if __name__ == "__main__":
    ap = build_argparser()
    args = ap.parse_args()
    try:
        main(args)
    except Exception as e:
        print("[FATAL]", e)
        traceback.print_exc()
        raise
