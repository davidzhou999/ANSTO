import os, time, math, argparse, random, json, pathlib
from dataclasses import dataclass
from typing import Tuple, Optional, List

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torch.amp import autocast, GradScaler
from tqdm import tqdm

# ===== Optional SSIM via scikit-image =====
_HAVE_SKIMAGE = True
try:
    from skimage.metrics import structural_similarity as ssim_sk
except Exception:
    _HAVE_SKIMAGE = False

# ====== Your model ======
from models.resunet_het import ResUNetHet as ResUNetHetero  # must match your existing trainer

# ========= Utilities =========
def seed_everything(seed=1234):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)

def to_uint16(x: np.ndarray) -> np.ndarray:
    x = np.clip(x, 0.0, 1.0)
    return (x * 65535.0 + 0.5).astype(np.uint16)

def compute_psnr(x: np.ndarray, y: np.ndarray, max_val: float = 1.0) -> float:
    # x, y in [0,1]
    mse = np.mean((x - y) ** 2, dtype=np.float64)
    if mse <= 1e-12:  # identical (or super close)
        return 99.0
    return float(20.0 * math.log10(max_val) - 10.0 * math.log10(mse))

def compute_ssim(x: np.ndarray, y: np.ndarray) -> Optional[float]:
    if not _HAVE_SKIMAGE:
        return None
    # skimage expects 2D float, data_range=1.0
    try:
        val = ssim_sk(x, y, data_range=1.0)
        return float(val)
    except Exception:
        return None

def make_grid(rows: List[np.ndarray]) -> np.ndarray:
    """
    rows: list of np.ndarrays [H, W] in [0,1]
    Stack each row horizontally, then all rows vertically; return uint16 image.
    """
    rows_u16 = [to_uint16(np.concatenate(row_items, axis=1)) for row_items in rows]
    grid_u16 = np.concatenate(rows_u16, axis=0)
    return grid_u16

def save_sample_grid(save_path: str,
                     x: np.ndarray,              # clean or noisy input [H,W] in [0,1]
                     masked_x: Optional[np.ndarray],
                     pred: np.ndarray,           # prediction mu [H,W] in [0,1]
                     target: Optional[np.ndarray] = None):
    # Build rows depending on presence of target & masked_x
    row1 = [x, pred]
    if masked_x is not None: row1.insert(1, masked_x)  # input | masked | pred
    rows = [row1]
    # residuals row
    if target is not None:
        res_pred = np.abs(pred - target)
        rows.append([target, res_pred])
    grid = make_grid(rows)
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    import tifffile as tiff
    tiff.imwrite(save_path, grid)

def format_sec(sec: float) -> str:
    return time.strftime("%H:%M:%S", time.gmtime(sec))

# ========= Datasets (same simple patch sampler as before) =========
# ========= Datasets (memory-safe caching) =========
import pathlib, random, numpy as np, torch
from torch.utils.data import Dataset
from typing import List, Optional, Tuple
from collections import OrderedDict

class PatchDataset(Dataset):
    def __init__(self, roots: List[str], patch: int, iters_per_epoch: Optional[int] = None,
                 io_cache: bool = False, pctl_cache: bool = False,
                 cache_max_gb: float = 4.0, pctl_subsample: int = 8):
        """
        - io_cache: keep some images in RAM (LRU) up to cache_max_gb
        - pctl_cache: store (lo, hi) per file (float pairs)
        - cache_max_gb: hard cap for io_cache
        - pctl_subsample: compute percentiles using arr[::pctl_subsample, ::pctl_subsample]
        """
        self.files = []
        for r in roots:
            for p in pathlib.Path(r).glob("**/*"):
                if p.suffix.lower() in [".tif", ".tiff"]:
                    self.files.append(str(p))
        if len(self.files) == 0:
            raise FileNotFoundError("No .tif/.tiff found under: " + "; ".join(roots))

        self.patch = patch
        self.iters_per_epoch = iters_per_epoch
        self.io_cache = io_cache
        self.pctl_cache = pctl_cache
        self.cache_max_bytes = int(cache_max_gb * (1024**3))
        self.pctl_subsample = max(1, int(pctl_subsample))

        # LRU caches
        self.cache = OrderedDict()      # fp -> np.ndarray (float32)
        self.cache_bytes = 0
        self.norm = {}                  # fp -> (lo, hi)

    def __len__(self):
        return self.iters_per_epoch if self.iters_per_epoch is not None else len(self.files)

    def _evict_if_needed(self, needed_bytes: int):
        while self.cache_bytes + needed_bytes > self.cache_max_bytes and len(self.cache) > 0:
            _, arr = self.cache.popitem(last=False)
            self.cache_bytes -= arr.nbytes

    def _put_cache(self, fp: str, arr: np.ndarray):
        if not self.io_cache:
            return
        needed = arr.nbytes
        if needed > self.cache_max_bytes:
            return
        if fp in self.cache:
            old = self.cache.pop(fp)
            self.cache_bytes -= old.nbytes
        self._evict_if_needed(needed)
        self.cache[fp] = arr
        self.cache_bytes += needed

    def _get_cache(self, fp: str):
        if not self.io_cache:
            return None
        if fp in self.cache:
            arr = self.cache.pop(fp)
            self.cache[fp] = arr
            return arr
        return None

    def _load(self, fp: str) -> np.ndarray:
        hit = self._get_cache(fp)
        if hit is not None:
            return hit
        import tifffile as tiff
        arr = tiff.imread(fp)                      # keep native dtype to reduce memory traffic
        if arr.dtype != np.float32:
            arr = arr.astype(np.float32)           # one-time convert for torch
        self._put_cache(fp, arr)
        return arr

    def _compute_percentiles(self, arr: np.ndarray) -> Tuple[float, float]:
        step = self.pctl_subsample
        samp = arr[::step, ::step]
        lo, hi = np.percentile(samp, [1, 99])
        if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
            lo, hi = float(np.min(arr)), float(np.max(arr))
            if hi <= lo: hi = lo + 1.0
        return float(lo), float(hi)

    def _normalize01(self, arr: np.ndarray, fp: str) -> np.ndarray:
        if self.pctl_cache:
            if fp not in self.norm:
                lo, hi = self._compute_percentiles(arr)
                self.norm[fp] = (lo, hi)
            else:
                lo, hi = self.norm[fp]
        else:
            lo, hi = self._compute_percentiles(arr)
        eps = 1e-8
        out = (arr - lo) / (hi - lo + eps)
        return np.clip(out, 0.0, 1.0)

    def __getitem__(self, idx):
        if self.iters_per_epoch is not None:
            fp = random.choice(self.files)
        else:
            fp = self.files[idx]
        img = self._load(fp)
        img = self._normalize01(img, fp)

        H, W = img.shape[-2], img.shape[-1]
        ph = min(self.patch, H); pw = min(self.patch, W)
        y = random.randint(0, H - ph) if H > ph else 0
        x = random.randint(0, W - pw) if W > pw else 0
        patch = img[y:y+ph, x:x+pw].copy()   # copy avoids negative-stride errors

        return torch.from_numpy(patch).unsqueeze(0)  # [1, H, W]


# ========= Loss (heteroscedastic NLL + ring artifact reg) =========
def hetero_gauss_nll(x, mu, logv):
    # x, mu: [B,1,H,W], logv: [B,1,H,W]
    return 0.5 * (logv + (x - mu) ** 2 / (logv.exp() + 1e-8))

def ring_regularizer(mu, weight=0.0):
    if weight <= 0: return torch.tensor(0.0, device=mu.device, dtype=mu.dtype)
    # simple horizontal+vertical second diff
    loss = 0.0
    loss += (mu[:, :, 1:-1, :] - 0.5 * (mu[:, :, :-2, :] + mu[:, :, 2:, :])).abs().mean()
    loss += (mu[:, :, :, 1:-1] - 0.5 * (mu[:, :, :, :-2] + mu[:, :, :, 2:])).abs().mean()
    return weight * loss

# ========= Train / Eval loops =========
@torch.no_grad()
def evaluate(net, dl, device) -> Tuple[float, float, float]:
    net.eval()
    losses = []
    psnrs = []
    ssims = []
    for batch in dl:
        batch = batch.to(device, non_blocking=True)
        B = batch.size(0)

        # Random binary masks M1 (Noise2Same / blind spot)
        M = (torch.rand_like(batch) < 0.10).float()  # 10% masked
        masked = batch * (1.0 - M)

        with autocast('cuda', enabled=True):
            mu, logv = net(masked)
            loss = hetero_gauss_nll(batch, mu, logv).mean()

        losses.append(loss.detach().float().item())

        # Metrics on CPU in [0,1]
        x = batch.detach().float().clamp(0,1).cpu().numpy()
        y = mu.detach().float().clamp(0,1).cpu().numpy()
        for i in range(B):
            xi = x[i,0]; yi = y[i,0]
            psnrs.append(compute_psnr(yi, xi))
            ssv = compute_ssim(yi, xi)
            if ssv is not None: ssims.append(ssv)

    mean_loss = float(np.mean(losses)) if losses else float('nan')
    mean_psnr = float(np.mean(psnrs)) if psnrs else float('nan')
    mean_ssim = float(np.mean(ssims)) if ssims else float('nan')
    return mean_loss, mean_psnr, mean_ssim

def train_one_epoch(net, dl, opt, scaler, device, args, epoch_idx, sample_saver):
    net.train()
    iterator = tqdm(dl, desc=f"Train e{epoch_idx}", leave=True, dynamic_ncols=True)
    t0 = time.time()
    loss_meter = []

    for it, batch in enumerate(iterator, 1):
        batch = batch.to(device, non_blocking=True)
        M = (torch.rand_like(batch) < 0.10).float()
        masked = batch * (1.0 - M)

        opt.zero_grad(set_to_none=True)
        with autocast('cuda', enabled=args.amp):
            mu, logv = net(masked)
            loss = hetero_gauss_nll(batch, mu, logv).mean()
            loss = loss + ring_regularizer(mu, weight=args.ring_w)

        scaler.scale(loss).backward()
        scaler.step(opt)
        scaler.update()

        loss_f = float(loss.detach().cpu().item())
        loss_meter.append(loss_f)

        # Show instantaneous + running loss, VRAM
        vram_gb = torch.cuda.max_memory_allocated() / (1024**3) if torch.cuda.is_available() else 0.0
        iterator.set_postfix(loss=f"{loss_f:+.4f}", avg=f"{np.mean(loss_meter):+.4f}",
                             vram=f"{vram_gb:.2f}GB")

        # Optional sample saving every N iters
        if args.log_samples_every > 0 and (it % args.log_samples_every == 0):
            try:
                save_path = os.path.join(args.save_samples_dir, f"ep{epoch_idx:03d}_it{it:05d}.tiff")
                x = batch[0,0].detach().float().clamp(0,1).cpu().numpy()
                m = masked[0,0].detach().float().clamp(0,1).cpu().numpy()
                y = mu[0,0].detach().float().clamp(0,1).cpu().numpy()
                save_sample_grid(save_path, x, m, y, target=x)  # using x as “target” proxy for viz
            except Exception as e:
                tqdm.write(f"[WARN] sample save failed: {e}")

    sec = time.time() - t0
    return float(np.mean(loss_meter)), sec

# ========= Main =========
def main(args):
    seed_everything(args.seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"[INFO] device: {device}, AMP={'on' if args.amp else 'off'}, BF16={'on' if args.bf16 else 'off'}")

    # Dataset & Loaders
    roots = [r.strip() for r in args.roots]

    ds_train = PatchDataset(roots, patch = args.patch, iters_per_epoch = args.iters_per_epoch,
                            io_cache = args.io_cache, pctl_cache = args.pctl_cache,
                            cache_max_gb = args.cache_max_gb, pctl_subsample = args.pctl_subsample)

    # Tiny eval set: reuse sampler with fewer iterations for speed
    # ds_eval = PatchDataset(roots, patch=args.patch, iters_per_epoch=max(1, args.eval_iters),
                           #io_cache=args.io_cache, pctl_cache=args.pctl_cache)
    ds_eval = PatchDataset(roots, patch = args.patch, iters_per_epoch = max(1, args.eval_iters),
                            io_cache = False, pctl_cache = args.pctl_cache,  # keep eval lean
                            cache_max_gb = 1.0, pctl_subsample = args.pctl_subsample)

    dl_train = DataLoader(ds_train, batch_size=args.batch, shuffle=True,
                          num_workers=args.workers, pin_memory=True, persistent_workers=False)
    dl_eval  = DataLoader(ds_eval,  batch_size=args.batch, shuffle=False,
                          num_workers=0, pin_memory=True, persistent_workers=False)

    print(f"[INFO] train images: {len(ds_train.files)} | eval images: {len(ds_eval.files)}")
    print(f"[INFO] batch={args.batch}, patch={args.patch}, workers={args.workers}")
    os.makedirs(os.path.dirname(args.save_path), exist_ok=True)

    # Model / Opt
    net = ResUNetHetero(in_ch=1, base=args.base)
    net.to(device)
    opt = optim.AdamW(net.parameters(), lr=args.lr, weight_decay=1e-4)
    scaler = GradScaler('cuda', enabled=args.amp)

    best_eval = None
    best_path = args.save_path
    last_path = os.path.splitext(args.save_path)[0] + ".last.pt"
    print(f"[INFO] saving to: best={os.path.basename(best_path)}, last={os.path.basename(last_path)}")

    # Sample dir
    if args.log_samples_every > 0:
        os.makedirs(args.save_samples_dir, exist_ok=True)

    # Train
    for ep in range(1, args.epochs + 1):
        tr_loss, tr_sec = train_one_epoch(net, dl_train, opt, scaler, device, args, ep, args.save_samples_dir)

        # Eval
        eval_loss, eval_psnr, eval_ssim = evaluate(net, dl_eval, device)

        # Save last
        ckpt = {
            "epoch": ep, "model": net.state_dict(), "opt": opt.state_dict(),
            "scaler": scaler.state_dict(), "args": vars(args),
            "metrics": {"train_loss": tr_loss, "eval_loss": eval_loss,
                        "eval_psnr": eval_psnr, "eval_ssim": eval_ssim}
        }
        torch.save(ckpt, last_path)

        # Best by eval_loss (more negative is better for our NLL); you can flip if you prefer PSNR
        is_best = best_eval is None or (eval_loss < best_eval)
        if is_best:
            best_eval = eval_loss
            torch.save(ckpt, best_path)

        vram_gb = torch.cuda.max_memory_allocated() / (1024**3) if torch.cuda.is_available() else 0.0
        print(f"[EPOCH {ep:03d}/{args.epochs}] "
              f"train_loss={tr_loss:+.4f}  eval_loss={eval_loss:+.4f}  "
              f"PSNR={eval_psnr:.2f}dB  SSIM={(eval_ssim if not math.isnan(eval_ssim) else float('nan')):.4f}  "
              f"time={format_sec(tr_sec)}  vram={vram_gb:.2f}GB/{torch.cuda.get_device_properties(0).total_memory/(1024**3):.2f}GB")

    print(f"[DONE] Best eval loss: {best_eval}")
    print(f"[DONE] Best checkpoint: {best_path}")
    print(f"[DONE] Last checkpoint: {last_path}")

if __name__ == "__main__":
    import torch.multiprocessing as mp

    try:
        mp.set_start_method("spawn", force=True)
    except RuntimeError:
        pass

    ap = argparse.ArgumentParser()
    ap.add_argument("--roots", nargs="+", required=True, help="one or more folders with images")
    ap.add_argument("--epochs", type=int, default=1)
    ap.add_argument("--iters_per_epoch", type=int, default=200)
    ap.add_argument("--eval_iters", type=int, default=20)
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--patch", type=int, default=256)
    ap.add_argument("--workers", type=int, default=0)
    ap.add_argument("--base", type=int, default=64, help="base channels for UNet")
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--ring_w", type=float, default=0.0)
    ap.add_argument("--amp", action="store_true")
    ap.add_argument("--bf16", action="store_true")
    ap.add_argument("--pctl_cache", action="store_true", help="cache 1/99 percentiles")
    ap.add_argument("--io_cache", action="store_true", help="cache full images in RAM")
    ap.add_argument("--save_path", type=str, default="data/n2same_het_pretrained_metrics.pt")
    ap.add_argument("--cache_max_gb", type=float, default=4.0, help="cap for io_cache (GB)")
    ap.add_argument("--pctl_subsample", type=int, default=8, help="percentile subsample stride")

    # New: sample logging & metrics UI
    ap.add_argument("--log_samples_every", type=int, default=50, help="save a grid every N iters (0=off)")
    ap.add_argument("--save_samples_dir", type=str, default="samples")
    ap.add_argument("--seed", type=int, default=1234)
    args = ap.parse_args()

    # dtype preference
    if args.bf16 and torch.cuda.is_available():
        torch.set_float32_matmul_precision("high")  # safe to enable for Ada / Hopper

    main(args)
