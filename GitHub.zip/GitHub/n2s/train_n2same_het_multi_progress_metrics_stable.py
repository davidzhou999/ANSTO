import os
# Safer CUDA defaults on Windows
os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "max_split_size_mb:64")
os.environ.setdefault("CUDA_MODULE_LOADING", "LAZY")

import time, math, glob, random, argparse
from pathlib import Path
import numpy as np
from tqdm import tqdm

import torch
from torch.utils.data import Dataset, DataLoader
from torch.optim import AdamW
from torch.amp import autocast, GradScaler
import tifffile as tiff

from models.resunet_het import ResUNetHetero

torch.backends.cudnn.benchmark = True

# ------------------------
# Model factory (base=64 to match your existing checkpoints)
# ------------------------
def build_net(device):
    # Your checkpoints were trained with base=64; keep it to avoid size mismatch.
    net = ResUNetHetero(in_ch=1, base=64).to(device)
    return net

# ------------------------
# IO / dataset helpers
# ------------------------
def list_images(roots):
    files = []
    if isinstance(roots, (str, Path)):
        roots = [roots]
    for r in roots:
        r = str(r)
        files += glob.glob(os.path.join(r, "**", "*.tif"), recursive=True)
        files += glob.glob(os.path.join(r, "**", "*.tiff"), recursive=True)
    return sorted(set(files))

def random_crop(arr, patch):
    patch = int(patch)
    if arr.ndim == 3:
        h, w = int(arr.shape[-2]), int(arr.shape[-1])
    else:
        h, w = int(arr.shape[0]), int(arr.shape[1])
    if h < patch or w < patch:
        ph = max(0, patch - h)
        pw = max(0, patch - w)
        if arr.ndim == 3:
            arr = np.pad(arr, ((0, 0), (0, ph), (0, pw)), mode='reflect')
        else:
            arr = np.pad(arr, ((0, ph), (0, pw)), mode='reflect')
        h, w = (arr.shape[-2], arr.shape[-1]) if arr.ndim == 3 else arr.shape
    y = random.randint(0, h - patch); x = random.randint(0, w - patch)
    crop = arr[..., y:y + patch, x:x + patch] if arr.ndim == 3 else arr[y:y + patch, x:x + patch]
    return np.ascontiguousarray(crop)

# ------------------------
# Loss & metrics (metrics on CPU to avoid CUDA eval hiccups)
# ------------------------
def hetero_gauss_nll(x, mu, logv, eps=1e-6):
    v = torch.exp(logv).clamp_min(eps)
    return 0.5 * (math.log(2 * math.pi) + logv + (x - mu) ** 2 / v)

def psnr_cpu(x, y, eps=1e-8):
    mse = torch.mean((x - y) ** 2).clamp_min(eps)
    return 10.0 * torch.log10(1.0 / mse)

def ssim_simple_cpu(x, y, C1=0.01 ** 2, C2=0.03 ** 2):
    mu_x = torch.mean(x); mu_y = torch.mean(y)
    sigma_x = torch.mean((x - mu_x) ** 2)
    sigma_y = torch.mean((y - mu_y) ** 2)
    sigma_xy = torch.mean((x - mu_x) * (y - mu_y))
    num = (2 * mu_x * mu_y + C1) * (2 * sigma_xy + C2)
    den = (mu_x ** 2 + mu_y ** 2 + C1) * (sigma_x + sigma_y + C2)
    return num / (den + 1e-8)

class PatchDataset(Dataset):
    def __init__(self, roots, patch=256, iters_per_epoch=1000,
                 eval_mode=False, io_cache=False, pctl_cache=False,
                 pctl_subsample=8, cache_max_gb=64):
        self.files = list_images(roots)
        if len(self.files) == 0:
            raise RuntimeError(f"No .tif/.tiff found under: {roots}")
        self.patch = int(patch)
        self.eval_mode = bool(eval_mode)
        self.iters = int(iters_per_epoch)

        self._io_cache, self._pctl = {}, {}
        self.io_cache = bool(io_cache)
        self.pctl_cache = bool(pctl_cache)
        self.pctl_subsample = max(1, int(pctl_subsample))
        self.cache_max_bytes = int(cache_max_gb * (1024 ** 3))

        if self.pctl_cache or self.io_cache:
            self._warmup_cache()

    def _warmup_cache(self):
        random.seed(0); np.random.seed(0)
        mem = 0
        for fp in self.files[::self.pctl_subsample]:
            arr = tiff.imread(fp)
            arr = np.ascontiguousarray(arr).astype(np.float32)
            lo, hi = np.percentile(arr, 0.5), np.percentile(arr, 99.5)
            self._pctl[fp] = (float(lo), float(hi))
            if self.io_cache and mem < self.cache_max_bytes:
                rng = hi - lo
                a = ((arr - lo) / rng) if rng > 1e-6 else (arr - lo)
                a = np.clip(a, 0.0, 1.0).astype(np.float32, copy=False)
                self._io_cache[fp] = a
                mem += a.nbytes
            if mem >= self.cache_max_bytes:
                break

    def __len__(self):
        return self.iters if not self.eval_mode else len(self.files)

    def __getitem__(self, idx):
        fp = self.files[idx] if self.eval_mode else random.choice(self.files)

        if fp in self._io_cache:
            arr = self._io_cache[fp]
        else:
            arr = tiff.imread(fp)
            arr = np.ascontiguousarray(arr).astype(np.float32)
            if fp in self._pctl:
                lo, hi = self._pctl[fp]
            else:
                lo, hi = np.percentile(arr, 0.5), np.percentile(arr, 99.5)
            rng = hi - lo
            if rng > 1e-6:
                arr = (arr - lo) / rng
            arr = np.clip(arr, 0.0, 1.0)

        if not self.eval_mode:
            arr = random_crop(arr, self.patch)
            if random.random() < 0.5:
                arr = (arr[..., :, ::-1] if arr.ndim == 3 else arr[:, ::-1]).copy()
            if random.random() < 0.5:
                arr = (arr[..., ::-1, :] if arr.ndim == 3 else arr[::-1, :]).copy()
        else:
            if arr.ndim == 3:
                h, w = arr.shape[-2], arr.shape[-1]
                ph = min(self.patch, h); pw = min(self.patch, w)
                y0 = (h - ph) // 2; x0 = (w - pw) // 2
                arr = np.ascontiguousarray(arr[..., y0:y0 + ph, x0:x0 + pw])
            else:
                h, w = arr.shape
                ph = min(self.patch, h); pw = min(self.patch, w)
                y0 = (h - ph) // 2; x0 = (w - pw) // 2
                arr = np.ascontiguousarray(arr[y0:y0 + ph, x0:x0 + pw])

        if arr.ndim == 3:
            ten = torch.from_numpy(arr[0]).unsqueeze(0)
        else:
            ten = torch.from_numpy(arr).unsqueeze(0)
        return ten

# ------------------------
# Train / Eval
# ------------------------
def train_one_epoch(net, dl, opt, scaler, device, args, epoch_idx):
    net.train()
    t0 = time.time()
    losses = []
    iterator = tqdm(dl, total=len(dl), leave=False, desc=f"Train e{epoch_idx}")
    for _, batch in enumerate(iterator, 1):
        batch = batch.to(device, non_blocking=True)
        with autocast('cuda', enabled=bool(args.amp)):
            mu, logv = net(batch)
            loss = hetero_gauss_nll(batch, mu, logv).mean()
        scaler.scale(loss).backward()
        scaler.step(opt); scaler.update(); opt.zero_grad(set_to_none=True)
        losses.append(float(loss.detach().cpu().item()))
        avg = float(np.mean(losses[-50:]))
        vram_gb = torch.cuda.max_memory_allocated() / (1024 ** 3) if torch.cuda.is_available() else 0.0
        iterator.set_postfix(avg=f"{avg:+.4f}", loss=f"{losses[-1]:+.4f}", vram=f"{vram_gb:.2f}GB")
    return float(np.mean(losses)), time.time() - t0

@torch.no_grad()
def evaluate(net, dl, device, args):
    net.eval()
    losses, psnrs, ssims = [], [], []
    iters = 0
    for batch in dl:
        batch = batch.to(device, non_blocking=True)
        with autocast('cuda', enabled=bool(args.amp)):
            mu, logv = net(batch)
            loss = hetero_gauss_nll(batch, mu, logv).mean()
        losses.append(float(loss.detach().cpu().item()))
        # compute metrics on CPU to dodge sporadic CUDA eval errors on Windows
        x_cpu = batch.detach().float().cpu()
        y_cpu = mu.detach().float().cpu()
        psnrs.append(float(psnr_cpu(x_cpu, y_cpu).item()))
        ssims.append(float(ssim_simple_cpu(x_cpu, y_cpu).item()))
        iters += 1
        if args.eval_iters and iters >= args.eval_iters:
            break
    return float(np.mean(losses)), float(np.mean(psnrs)), float(np.mean(ssims))

def save_ckpt(path, net, opt, scaler, epoch, metrics):
    payload = {"model": net.state_dict(), "opt": opt.state_dict(),
               "scaler": scaler.state_dict(), "epoch": epoch, "metrics": metrics}
    torch.save(payload, path)

def _cleanup_cuda():
    try:
        torch.cuda.empty_cache()
    except Exception:
        pass

# ------------------------
# Args / main
# ------------------------
def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--roots', nargs='+', required=True)
    ap.add_argument('--epochs', type=int, default=50)
    ap.add_argument('--iters_per_epoch', type=int, default=2000)
    ap.add_argument('--eval_iters', type=int, default=50)
    ap.add_argument('--batch', type=int, default=24)
    ap.add_argument('--patch', type=int, default=384)
    ap.add_argument('--workers', type=int, default=4)
    ap.add_argument('--io_cache', action='store_true')
    ap.add_argument('--pctl_cache', action='store_true')
    ap.add_argument('--pctl_subsample', type=int, default=8)
    ap.add_argument('--cache_max_gb', type=float, default=64.0)
    ap.add_argument('--amp', action='store_true')
    ap.add_argument('--save_samples_dir', type=str, default=None)
    ap.add_argument('--log_samples_every', type=int, default=200)
    ap.add_argument('--save_path', type=str, required=True)
    ap.add_argument('--grad_accum', type=int, default=1)
    ap.add_argument('--pinmem', type=int, default=0)
    ap.add_argument('--resume', type=str, default=None)
    return ap.parse_args()

def main(args):
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"[INFO] device: {device}, AMP={'on' if args.amp else 'off'}")

    ds_train = PatchDataset(args.roots, patch=args.patch, iters_per_epoch=args.iters_per_epoch,
                            eval_mode=False, io_cache=args.io_cache, pctl_cache=args.pctl_cache,
                            pctl_subsample=args.pctl_subsample, cache_max_gb=args.cache_max_gb)
    ds_eval = PatchDataset(args.roots, patch=args.patch, iters_per_epoch=max(1, args.eval_iters),
                           eval_mode=True, io_cache=False, pctl_cache=False)

    print(f"[INFO] train images: {len(ds_train.files)} | eval images: {len(ds_eval.files)}")
    print(f"[INFO] batch={args.batch}, patch={args.patch}, workers={args.workers}")

    dl_train = DataLoader(ds_train, batch_size=args.batch, shuffle=True,
                          num_workers=args.workers, pin_memory=bool(args.pinmem),
                          persistent_workers=False)
    dl_eval = DataLoader(ds_eval, batch_size=args.batch, shuffle=False,
                         num_workers=0, pin_memory=False, persistent_workers=False)

    net = build_net(device)
    opt = AdamW(net.parameters(), lr=1e-4, weight_decay=1e-4)
    scaler = GradScaler('cuda', enabled=bool(args.amp))

    best_path = args.save_path
    last_path = os.path.splitext(args.save_path)[0] + ".last.pt"
    best_eval = None
    start_ep = 1

    if args.resume and os.path.isfile(args.resume):
        ckpt = torch.load(args.resume, map_location=device)
        net.load_state_dict(ckpt["model"])
        try: opt.load_state_dict(ckpt["opt"])
        except: pass
        try: scaler.load_state_dict(ckpt["scaler"])
        except: pass
        m = ckpt.get("metrics", {})
        best_eval = m.get("eval_loss", None)
        start_ep = int(ckpt.get("epoch", 0)) + 1
        print(f"[INFO] resumed from {args.resume} (best_eval={best_eval})")

    print(f"[INFO] saving to: best={os.path.basename(best_path)}, last={os.path.basename(last_path)}")

    for ep in range(start_ep, args.epochs + 1):
        if torch.cuda.is_available():
            torch.cuda.reset_peak_memory_stats()

        tr_loss, tr_sec = train_one_epoch(net, dl_train, opt, scaler, device, args, ep)
        ev_loss, ev_psnr, ev_ssim = evaluate(net, dl_eval, device, args)

        vram_gb = torch.cuda.max_memory_allocated() / (1024 ** 3) if torch.cuda.is_available() else 0.0
        print(f"[EPOCH {ep:03d}/{args.epochs}] "
              f"train_loss={tr_loss:+.4f}  eval_loss={ev_loss:+.4f}  "
              f"PSNR={ev_psnr:.2f}dB  SSIM={ev_ssim:.4f}  "
              f"time={time.strftime('%H:%M:%S', time.gmtime(tr_sec))}  vram={vram_gb:.2f}GB")

        save_ckpt(last_path, net, opt, scaler, ep,
                  {"eval_loss": ev_loss, "psnr": ev_psnr, "ssim": ev_ssim, "epoch": ep})

        if (best_eval is None) or (ev_loss < best_eval):
            best_eval = ev_loss
            save_ckpt(best_path, net, opt, scaler, ep,
                      {"eval_loss": ev_loss, "psnr": ev_psnr, "ssim": ev_ssim, "epoch": ep})
            print(f"[BEST] {os.path.basename(best_path)} (eval_loss={best_eval:+.4f})")

        _cleanup_cuda()

if __name__ == "__main__":
    try:
        import multiprocessing as mp
        if mp.get_start_method(allow_none=True) != "spawn":
            mp.set_start_method("spawn", force=True)
    except RuntimeError:
        pass
    args = parse_args()
    main(args)
