
import torch
import torch.fft as fft
import numpy as np

class CharbonnierLoss(torch.nn.Module):
    def __init__(self, epsilon=1e-3): super().__init__(); self.eps = epsilon
    def forward(self, x, y, mask=None):
        diff = (x - y) if mask is None else (x - y) * mask
        return torch.mean(torch.sqrt(diff*diff + self.eps*self.eps))

class HeteroscedasticNLL(torch.nn.Module):
    def __init__(self): super().__init__()
    def forward(self, mu, logvar, target, mask=None):
        if mask is None: mask = torch.ones_like(mu)
        inv_var = torch.exp(-logvar)
        nll = 0.5 * (logvar + (mu - target)**2 * inv_var)
        return torch.sum(nll * mask) / (mask.sum() + 1e-8)

@torch.no_grad()
def nps_2d(residual):
    r = residual - residual.mean(dim=(-2,-1), keepdim=True)
    F = fft.fftshift(fft.fft2(r, norm='ortho'), dim=(-2,-1))
    P = (F.real**2 + F.imag**2).mean(dim=(0,1))
    return P

def gsure_vst(model, x_noisy, sigma2=1.0, amp=False):
    x = x_noisy.clone().detach().requires_grad_(True)
    if amp:
        autocast_cm = torch.cuda.amp.autocast
    else:
        from contextlib import contextmanager
        @contextmanager
        def autocast_cm(): yield
    with autocast_cm():
        out = model(x)
        yhat = out[0] if isinstance(out, tuple) else out
        resid = yhat - x
        mse_term = torch.mean(resid**2)
        v = torch.randint_like(x, low=0, high=2).float()*2-1
        inner = (yhat * v).sum()
        grad = torch.autograd.grad(inner, x, create_graph=False)[0]
        div = torch.mean(grad)
        gsure = mse_term - sigma2 + 2*sigma2*div
        return gsure.detach()

@torch.no_grad()
def cnr_auto(img):
    x = img.detach().float().cpu().numpy()
    x = x if x.ndim==2 else x[0,0]
    hist, edges = np.histogram(x, bins=256, range=(x.min(), x.max()))
    csum = np.cumsum(hist); w = csum / csum[-1]
    m = np.cumsum(hist * (edges[:-1] + edges[1:]) * 0.5)
    mt = m / csum.clip(min=1)
    sigma_b2 = w*(1-w)*(mt - (m[-1]/csum[-1]))**2
    t_idx = np.argmax(sigma_b2)
    thr = (edges[t_idx] + edges[t_idx+1]) * 0.5
    fg = x[x >= thr]; bg = x[x < thr]
    mu1, mu2 = (fg.mean() if fg.size>0 else 0.0), (bg.mean() if bg.size>0 else 0.0)
    s1, s2 = (fg.std() if fg.size>1 else 1e-8), (bg.std() if bg.size>1 else 1e-8)
    return float(abs(mu1-mu2) / np.sqrt(s1*s1 + s2*s2 + 1e-12)), float(thr)

@torch.no_grad()
def ring_index(img, center=None, radial_bins=256):
    x = img.detach().float().cpu().numpy()
    x = x if x.ndim==2 else x[0,0]
    H, W = x.shape
    cy, cx = (H-1)/2.0, (W-1)/2.0 if center is None else center
    yy, xx = np.indices((H,W))
    r = np.sqrt((yy-cy)**2 + (xx-cx)**2)
    rmax = r.max()
    rb = np.linspace(0, rmax, radial_bins+1)
    ratios = []
    for i in range(radial_bins):
        mask = (r >= rb[i]) & (r < rb[i+1])
        vals = x[mask]
        if vals.size < 32: continue
        mu = vals.mean(); sd = vals.std() + 1e-8
        ratios.append(abs(mu)/sd)
    if len(ratios)==0: return 0.0
    return float(np.mean(ratios))
