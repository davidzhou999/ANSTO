
import os, glob, numpy as np, nibabel as nib, torch
from torch.utils.data import Dataset

class NiftiLazyDataset(Dataset):
    def __init__(self, root_dir, patch=128, repeat=512):
        self.files = sorted(glob.glob(os.path.join(root_dir, '*.nii'))) + \
                     sorted(glob.glob(os.path.join(root_dir, '*.nii.gz')))
        if len(self.files)==0: raise FileNotFoundError(f"No NIfTI files under {root_dir}")
        self.patch = patch; self.repeat = repeat
    def __len__(self): return self.repeat
    def _read(self, path):
        arr = nib.load(path).get_fdata().astype(np.float32)
        pmin = np.percentile(arr, 0.5); pmax = np.percentile(arr, 99.5)
        arr = np.clip((arr - pmin) / (pmax - pmin + 1e-8), 0.0, 1.0)
        return arr
    def __getitem__(self, idx):
        path = np.random.choice(self.files)
        vol = self._read(path)
        D,H,W = vol.shape; ps = self.patch
        z = np.random.randint(0, D-ps+1); y = np.random.randint(0, H-ps+1); x = np.random.randint(0, W-ps+1)
        patch = vol[z:z+ps, y:y+ps, x:x+ps]
        if np.random.rand()<0.5: patch = patch[::-1, :, :]
        if np.random.rand()<0.5: patch = patch[:, ::-1, :]
        if np.random.rand()<0.5: patch = patch[:, :, ::-1]
        return torch.from_numpy(patch).unsqueeze(0)
