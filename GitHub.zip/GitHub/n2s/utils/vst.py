
import torch

def anscombe_forward(x, alpha=1.0, sigma=0.0, eps=1e-8):
    return 2.0 * torch.sqrt(torch.clamp(alpha * x + (3.0/8.0) * (alpha**2) + (sigma**2), min=eps))

def anscombe_inverse(y, alpha=1.0, sigma=0.0):
    z = y / 2.0
    x = z*z - 1.0/8.0
    x = x + (1.0/4.0) * torch.clamp(z**-2, max=1e6) - (11.0/8.0) * torch.clamp(z**-4, max=1e6)
    x = torch.clamp(x - (sigma**2), min=0.0)
    x = x / max(alpha, 1e-8)
    return x
