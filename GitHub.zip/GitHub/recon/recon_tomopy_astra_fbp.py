#!/usr/bin/env python
"""
TomoPy + ASTRA FBP_CUDA reconstruction script for parallel-beam tomography.

Tested with:
- Python 3.10
- tomopy >= 1.14
- astra-toolbox >= 2
- tifffile, nibabel, numpy

Data model (your case):
- N projections (e.g., 1335)
- Each projection is H x W (e.g., 3200 x 6248)
- Projections: 0..180 degrees (parallel beam)
- Stored as 8–16-bit TIFFs (.tif/.tiff)

Typical usage (Windows CMD)

# 1) Quick preview (limited rows) to estimate COR and check quality
python recon_tomopy_astra_fbp.py ^
  --projs_dir data\\scan --pattern "DINGO_*.tif" ^
  --out_dir data\\recon_preview ^
  --preview_rows 1000 1500 ^
  --find_center vo ^
  --median 3 --stripe fw --downsample 1 ^
  --mask 0.98

# 2) Full reconstruction (after you know a good center)
python recon_tomopy_astra_fbp.py ^
  --projs_dir data\\scan --pattern "DINGO_*.tif" ^
  --out_dir data\\recon_full ^
  --center 3124.0 ^
  --median 3 --stripe fw --downsample 1 ^
  --mask 0.98

# 3) Same as (2) but save as a single NIfTI volume
python recon_tomopy_astra_fbp.py ^
  --projs_dir data\\scan --pattern "DINGO_*.tif" ^
  --out_dir data\\recon_full_nii ^
  --center 3124.0 ^
  --median 3 --stripe fw --downsample 1 ^
  --mask 0.98 --save nii --nii_name recon_dingo.nii.gz

Updated TomoPy 3D reconstruction script

Features:
- Supports: --stripe none | fw | ti
- Safe circ_mask (no "out=" keyword)
- No ASTRA backend (TomoPy gridrec only — safe and fast)
- Downsample factor 1/2/4
- Optional preview slab (--preview_rows y0 y1)
- TIFF or NIfTI output
"""

from __future__ import annotations
import argparse
import math
from pathlib import Path
from typing import List, Tuple

import numpy as np
import tifffile as tiff

# Optional NIfTI export
try:
    import nibabel as nib
except Exception:
    nib = None

# TomoPy
try:
    import tomopy
except Exception as e:
    raise SystemExit("TomoPy is required.\nInstall via: conda install -c conda-forge tomopy\n" + str(e))


# --------------------
# Utility
# --------------------

def natural_key(s: str):
    """Simple natural sort key."""
    out = []
    num = ""
    for ch in s:
        if ch.isdigit():
            num += ch
        else:
            if num:
                out.append(int(num)); num = ""
            out.append(ch.lower())
    if num:
        out.append(int(num))
    return out


# --------------------
# Reading
# --------------------

def read_stack(files: List[str], dtype=np.float32) -> np.ndarray:
    arrs = []
    for fp in files:
        arrs.append(tiff.imread(fp))
    data = np.stack(arrs, axis=0).astype(dtype, copy=False)
    return data


def average_stack(files: List[str], dtype=np.float32) -> np.ndarray | None:
    if not files:
        return None
    acc = None
    for fp in files:
        img = tiff.imread(fp).astype(dtype, copy=False)
        if acc is None:
            acc = img.astype(np.float64)
        else:
            acc += img
    acc /= len(files)
    return acc.astype(dtype)


# --------------------
# Angles
# --------------------

def build_theta(n_proj: int,
                start_deg: float | None,
                step_deg: float | None,
                end_deg: float | None):
    if start_deg is None and step_deg is None and end_deg is None:
        return np.linspace(0.0, math.pi, n_proj, endpoint=True).astype(np.float32)
    if start_deg is None:
        start_deg = 0.0
    if step_deg is not None and end_deg is None:
        end_deg = start_deg + (n_proj - 1) * step_deg
    if end_deg is None:
        end_deg = 180.0
    return np.linspace(math.radians(start_deg),
                       math.radians(end_deg),
                       n_proj,
                       endpoint=True).astype(np.float32)


# --------------------
# Downsample
# --------------------

def maybe_downsample(proj: np.ndarray, factor: int) -> np.ndarray:
    if factor <= 1:
        return proj
    n, ny, nx = proj.shape
    sy = (ny // factor) * factor
    sx = (nx // factor) * factor
    proj = proj[:, :sy, :sx]
    proj = proj.reshape(n, sy // factor, factor, sx // factor, factor).mean(axis=(2, 4))
    return proj

def maybe_downsample_2d(img: np.ndarray | None, factor: int) -> np.ndarray | None:
    """Downsample a single 2D image by integer factor using average pooling."""
    if img is None or factor <= 1:
        return img
    ny, nx = img.shape
    sy = (ny // factor) * factor
    sx = (nx // factor) * factor
    img = img[:sy, :sx]
    img = img.reshape(sy // factor, factor, sx // factor, factor).mean(axis=(1, 3))
    return img


# --------------------
# Preprocessing
# --------------------

def preprocess(proj: np.ndarray,
               flat: np.ndarray | None,
               dark: np.ndarray | None,
               median: int,
               stripe: str | None) -> np.ndarray:
    # Flat/dark
    if flat is not None and dark is not None:
        flat_stack = np.repeat(flat[None, ...], proj.shape[0], axis=0)
        dark_stack = np.repeat(dark[None, ...], proj.shape[0], axis=0)
        proj = tomopy.normalize(proj, flat_stack, dark_stack)

    # minus-log
    proj = tomopy.minus_log(proj)

    # median filter
    if median and median > 0:
        proj = tomopy.misc.corr.median_filter(proj, size=median)

    # stripe removal
    if stripe == "fw":
        proj = tomopy.remove_stripe_fw(proj, level=7, wname="db5", sigma=1, pad=True)
    elif stripe == "ti":
        proj = tomopy.remove_stripe_ti(proj, alpha=1.5)
    elif stripe == "none":
        pass

    return proj


# --------------------
# Reconstruction (gridrec)
# --------------------

def reconstruct_gridrec(proj: np.ndarray,
                        theta: np.ndarray,
                        center: float,
                        ncore: int = 0,
                        y0: int | None = None,
                        y1: int | None = None):
    """
    Pure TomoPy gridrec 3D reconstruction.
    proj: (n_proj, ny, nx)
    We optionally reconstruct only a slab [y0:y1] for preview.
    """
    if y0 is not None and y1 is not None:
        proj = proj[:, y0:y1, :]
        print(f"[preview mode] reconstructing Y-slab: [{y0}:{y1}] -> shape {proj.shape}")

    rec = tomopy.recon(
        proj,
        theta,
        center=center,
        algorithm="gridrec",
        filter_name="parzen",
        ncore=ncore
    )
    # TomoPy returns (nz, ny, nx) for parallel-beam gridrec
    return rec


# --------------------
# Mask
# --------------------

def circ_mask_inplace(vol: np.ndarray, ratio: float):
    if ratio <= 0:
        return
    masked = tomopy.circ_mask(vol, axis=0, ratio=ratio, val=0.0)
    vol[...] = masked


# --------------------
# Saving
# --------------------

def save_tiff_stack(vol: np.ndarray, out_dir: Path, prefix="recon_z"):
    out_dir.mkdir(parents=True, exist_ok=True)
    nz = vol.shape[0]
    for i in range(nz):
        tiff.imwrite(
            str(out_dir / f"{prefix}{i:04d}.tif"),
            vol[i].astype(np.float32),
            compression="zlib"
        )


def save_nifti(vol: np.ndarray, out_path: Path,
               spacing: Tuple[float, float, float] = (1,1,1)):
    if nib is None:
        raise RuntimeError("Nibabel not installed.")
    dz, dy, dx = spacing
    affine = np.diag([dx, dy, dz, 1]).astype(np.float32)
    img = nib.Nifti1Image(vol.astype(np.float32), affine)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    nib.save(img, str(out_path))


# --------------------
# Main
# --------------------

def main():
    ap = argparse.ArgumentParser("Updated TomoPy reconstruction")

    ap.add_argument("--projs_dir", required=True)
    ap.add_argument("--pattern", default="*.tif*")
    ap.add_argument("--flats_dir", default=None)
    ap.add_argument("--darks_dir", default=None)
    ap.add_argument("--out_dir", required=True)

    # angles
    ap.add_argument("--theta_start", type=float, default=None)
    ap.add_argument("--theta_step", type=float, default=None)
    ap.add_argument("--theta_end", type=float, default=None)

    # preproc
    ap.add_argument("--downsample", type=int, default=1)
    ap.add_argument("--median", type=int, default=0)
    ap.add_argument("--stripe",
        choices=["none", "fw", "ti"], default="none",
        help="Stripe removal: none | fw | ti"
    )

    # center
    ap.add_argument("--center", type=float, required=True)

    # preview
    ap.add_argument("--preview_rows", type=int, nargs=2, default=None)

    # mask
    ap.add_argument("--mask", type=float, default=0.0)

    # save
    ap.add_argument("--save", choices=["tiff", "nii"], default="tiff")
    ap.add_argument("--nii_name", default="recon.nii.gz")

    args = ap.parse_args()

    # ---------------- read proj ----------------
    proj_files = sorted(
        [str(p) for p in Path(args.projs_dir).glob(args.pattern)],
        key=natural_key
    )
    if not proj_files:
        raise SystemExit("No projections found.")

    print(f"Found {len(proj_files)} projections. Reading...")
    proj = read_stack(proj_files)
    print("Projections:", proj.shape)

    # flats/darks
    flat = dark = None
    if args.flats_dir:
        ffiles = sorted([str(p) for p in Path(args.flats_dir).glob("ob_*")])
        flat = average_stack(ffiles)
        print("Flat:", None if flat is None else flat.shape)

    if args.darks_dir:
        dfiles = sorted([str(p) for p in Path(args.darks_dir).glob("di_*")])
        dark = average_stack(dfiles)
        print("Dark:", None if dark is None else dark.shape)

    # theta
    theta = build_theta(
        proj.shape[0],
        args.theta_start,
        args.theta_step,
        args.theta_end
    )
    print("Theta range:", theta[0], "to", theta[-1])

    # downsample
    if args.downsample > 1:
        proj = maybe_downsample(proj, args.downsample)
        print("After downsample proj:", proj.shape)

        # Downsample flat/dark to match (ny, nx)
        if flat is not None:
            flat = maybe_downsample_2d(flat, args.downsample)
            print("After downsample flat:", flat.shape)
        if dark is not None:
            dark = maybe_downsample_2d(dark, args.downsample)
            print("After downsample dark:", dark.shape)


    # preproc
    print("Preprocessing...")
    proj = preprocess(proj, flat, dark, args.median, args.stripe)

    # reconstruct
    print("Reconstructing...")
    y0, y1 = (args.preview_rows if args.preview_rows else (None, None))
    rec = reconstruct_gridrec(
        proj, theta,
        center=float(args.center),
        y0=y0, y1=y1
    )
    print("Reconstruction shape:", rec.shape)

    # mask
    if args.mask > 0:
        print("Applying circular mask...")
        circ_mask_inplace(rec, args.mask)

    # save
    out_dir = Path(args.out_dir)
    if args.save == "tiff":
        save_tiff_stack(rec, out_dir)
        print(f"Saved TIFF stack to {out_dir}")
    else:
        save_nifti(rec, out_dir / args.nii_name)
        print(f"Saved NIfTI to {out_dir/args.nii_name}")

    print("DONE.")


if __name__ == "__main__":
    main()


