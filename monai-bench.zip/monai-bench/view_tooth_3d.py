import nibabel as nib
import numpy as np
import napari

# 1) Load volume
nii = nib.load("data/recon_full_nii/tooth_recon.nii.gz")
vol = nii.get_fdata().astype(np.float32)  # (Z, Y, X)
affine = nii.affine

# 2) Rough voxel spacing from affine (diagonal)
dz, dy, dx, _ = np.abs(np.diag(affine))

# 3) Open napari viewer
viewer = napari.Viewer()
viewer.add_image(
    vol,
    name="tooth",
    scale=(dz, dy, dx),
    rendering="attenuated_mip",  # try "mip" / "iso"
    blending="additive",
)

napari.run()

