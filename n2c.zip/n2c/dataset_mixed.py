import os
import numpy as np
import torch
from torch.utils.data import Dataset
import imageio.v2 as imageio
import tifffile

def _read_gray_01(path):
    p = path.lower()
    if p.endswith((".tif",".tiff")):
        a = tifffile.imread(path)
        if a.ndim>2: a = a[...,0]
        dt = a.dtype
        a = a.astype(np.float32)
        maxv = np.iinfo(dt).max if np.issubdtype(dt, np.integer) else max(1.0, float(a.max()))
        return (a / maxv).astype(np.float32)
    a = imageio.imread(path)
    if a.ndim == 3:
        if a.shape[2] >= 3:
            a = 0.2989*a[...,0] + 0.5870*a[...,1] + 0.1140*a[...,2]
        else:
            a = a[...,0]
    a = a.astype(np.float32)
    maxv = 255.0 if np.issubdtype(a.dtype, np.integer) else max(1.0, float(a.max()))
    return (a / maxv).astype(np.float32)

def _random_crop_pair(a, b, size):
    H, W = a.shape
    if size is None or (H <= size and W <= size):
        return a, b
    if H < size or W < size:
        y0 = max(0, (H - size)//2)
        x0 = max(0, (W - size)//2)
        return a[y0:y0+size, x0:x0+size], b[y0:y0+size, x0:x0+size]
    import numpy as np
    y0 = np.random.randint(0, H - size + 1)
    x0 = np.random.randint(0, W - size + 1)
    return a[y0:y0+size, x0:x0+size], b[y0:y0+size, x0:x0+size]

class PairedXRDataset(Dataset):
    """
    N2C dataset: requires *_noisy.* and *_clean.* with matching basenames.
    Works with PNG and TIFF (8-bit/16-bit), returns torch.float32 in [0,1], shape [1,H,W].
    """
    def __init__(self, root, crop_size=None, is_train=True):
        super().__init__()
        self.root = root
        self.crop_size = crop_size
        self.is_train = is_train
        exts = (".png",".tif",".tiff")
        files = [f for f in os.listdir(root) if f.lower().endswith(exts)]
        names = {f.lower(): f for f in files}
        pairs = []
        for f in files:
            fl = f.lower()
            if "_noisy" in fl:
                clean_key = fl.replace("_noisy", "_clean")
                if clean_key in names:
                    pairs.append((os.path.join(root, f), os.path.join(root, names[clean_key])))
        if len(pairs) == 0:
            raise RuntimeError(f"No paired images found in {root}. Expect *_noisy.* and *_clean.*")
        self.pairs = pairs

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        noisy_p, clean_p = self.pairs[idx]
        noisy = _read_gray_01(noisy_p)
        clean = _read_gray_01(clean_p)
        if self.is_train:
            noisy, clean = _random_crop_pair(noisy, clean, self.crop_size)
        noisy = torch.from_numpy(noisy).unsqueeze(0)  # [1,H,W]
        clean = torch.from_numpy(clean).unsqueeze(0)
        return noisy, clean
