import os
import numpy as np
from PIL import Image, ImageFilter
import shutil
import cv2
from tqdm import tqdm
import argparse
import sys


def add_neutron_noise(image, noise_std=0.228, blur_radius=0.5):
    """Add neutron-specific noise to an image with balanced intensity (10% of original)"""
    try:
        # Convert to numpy array and normalize to [0,1] floating point
        img_arr = np.array(image).astype(np.float32)
        max_val = 255 if image.mode in ('L', 'P', 'RGB', 'RGBA') else 65535
        img_arr /= max_val  # Normalize to [0,1]
        bit_depth = 8 if max_val == 255 else 16

        # 添加运动模糊
        if blur_radius > 0.05:  # 仅当模糊半径足够大时应用
            # 转换为PIL图像应用模糊
            pil_img = Image.fromarray(
                (img_arr * max_val).clip(0, max_val).astype(np.uint8 if bit_depth == 8 else np.uint16))
            pil_img = pil_img.filter(ImageFilter.GaussianBlur(radius=blur_radius))
            img_arr = np.array(pil_img).astype(np.float32) / max_val

        # 1. Main Gaussian noise (set to 40%) Electronics noise (Gaussian) - signal independent
        #    Includes dark current noise and readout noise
        gaussian_noise = np.random.normal(0, noise_std * 0.4, img_arr.shape)

        # 2. Signal-dependent Poisson noise (set to 30%) Quantum noise (Poisson) - signal dependent
        #    Poisson noise intensity is proportional to signal strength
        poisson_noise = np.random.poisson(img_arr * 500) / 500 - img_arr
        poisson_noise *= 0.3  # Apply 30% intensity

        # 3. Structural noise (fixed pattern) (set to 10%) Create low-frequency spatial patterns (stripes or non-uniform response)
        h, w = img_arr.shape
        xx, yy = np.meshgrid(np.linspace(0, 1, w), np.linspace(0, 1, h))
        # Stripe noise
        stripe_noise = np.sin(xx * 5 * np.pi) * noise_std * 0.3 * 0.1
        # Non-uniform response noise
        response_noise = (np.sin(xx * 0.5) * np.cos(yy * 0.5)) * noise_std * 0.2 * 0.1

        # 4. Scattering noise (set to 10%) (low-frequency background variations)
        scatter_noise = np.random.randn(h, w) * noise_std * 0.2 * 0.1
        scatter_noise = cv2.GaussianBlur(scatter_noise, (151, 151), 30)

        # Combine all noise components
        total_noise = (
                gaussian_noise +
                poisson_noise +
                stripe_noise +
                response_noise +
                scatter_noise
        )

        # Apply regular noise
        noisy_img = img_arr + total_noise

        # 5. Cosmic ray noise (0.05% occurrence) - set to 10% intensity Randomly adds bright spots from high-energy particle impacts
        cosmic_ray_mask = np.random.rand(h, w) < 0.0005

        # FIX: Assign values directly to the mask positions
        if cosmic_ray_mask.any():
            num_rays = cosmic_ray_mask.sum()
            # Use original intensity range but apply 10% factor
            cosmic_intensity = np.random.uniform(0.8, 1.0, num_rays)
            noisy_img[cosmic_ray_mask] += cosmic_intensity * 0.1

        # Clip to [0,1] range to prevent underflow/overflow
        noisy_img = np.clip(noisy_img, 0.0, 1.0)

        # Denormalize and convert to original data type
        noisy_img = (noisy_img * max_val).clip(0, max_val)
        return Image.fromarray(noisy_img.astype(np.uint8 if max_val == 255 else np.uint16))

    except Exception as e:
        raise RuntimeError(f"Error in add_neutron_noise: {str(e)}")


def process_images(source_dir, target_dir, noise_std=0.228, blur_radius=0.5):
    """Process all images in directory with improved noise and motion blur"""
    # Verify source directory exists
    if not os.path.exists(source_dir):
        print(f"Error: Source directory '{source_dir}' does not exist!")
        return

    # Create target directory
    os.makedirs(target_dir, exist_ok=True)
    print(f"Created target directory: {os.path.abspath(target_dir)}")

    valid_exts = ('.png', '.jpg', '.jpeg', '.tif', '.tiff', '.bmp')
    processed_count = 0
    error_count = 0
    skipped_small = 0

    # Get list of image files
    try:
        image_files = [f for f in os.listdir(source_dir)
                       if os.path.splitext(f)[1].lower() in valid_exts]
    except FileNotFoundError:
        print(f"Error accessing source directory: {source_dir}")
        return

    print(f"Found {len(image_files)} images in {source_dir}")

    # Process each image
    for filename in tqdm(image_files, desc="Processing images"):
        filepath = os.path.join(source_dir, filename)
        base, ext = os.path.splitext(filename)

        try:
            # Create clean version path
            clean_path = os.path.join(target_dir, f"{base}_clean{ext}")

            # Skip if already processed
            if os.path.exists(clean_path) and os.path.exists(clean_path.replace("_clean", "_noisy")):
                continue

            # Save clean version
            shutil.copy2(filepath, clean_path)

            # Open and validate image
            img = Image.open(filepath)

            # Skip small images
            min_dim = min(img.size)
            if min_dim < 256:
                skipped_small += 1
                os.remove(clean_path)  # Remove the clean copy we just made
                print(f"\nSkipping small image: {filename} ({img.size[0]}x{img.size[1]})")
                continue

            # Handle different bit depths
            original_mode = img.mode
            if original_mode in ['I;16', 'I', 'F']:
                try:
                    img = img.convert('I;16')
                except:
                    img = img.convert('L')
            else:
                img = img.convert('L')

            # Add improved noise with motion blur
            noisy_img = add_neutron_noise(img, noise_std, blur_radius)

            # Save noisy version
            noisy_path = os.path.join(target_dir, f"{base}_noisy{ext}")
            noisy_img.save(noisy_path)

            processed_count += 1

        except Exception as e:
            error_count += 1
            # Clean up partially created files
            if 'clean_path' in locals() and os.path.exists(clean_path):
                os.remove(clean_path)
            print(f"\nError processing {filename}: {str(e)}")
            # Continue processing other images

    # Print summary
    print(f"\nProcessing summary:")
    print(f"- Total images processed: {processed_count}")
    print(f"- Images skipped (too small): {skipped_small}")
    print(f"- Errors encountered: {error_count}")
    print(f"- Total images in target: {len(image_files) - skipped_small - error_count}")


if __name__ == "__main__":
    # Use the measured average noise level
    MEASURED_NOISE_STD = 0.228

    # Set motion blur radius (0.0 = no blur, 1.0 = moderate blur, 2.0 = strong blur)
    BLUR_RADIUS = 0.5

    # Set your directories
    source_dir = "test1"  # Original images
    target_dir = "test2"  # Target for clean/noisy pairs

    print(f"Source directory: {os.path.abspath(source_dir)}")
    print(f"Target directory: {os.path.abspath(target_dir)}")
    print(f"Noise standard deviation: {MEASURED_NOISE_STD}")
    print(f"Motion blur radius: {BLUR_RADIUS}")
    print(f"NOISE MIX: Gaussian 40%, Poisson 30%, Structural 10%, Scattering 10%")

    print("\nGenerating neutron noise dataset with motion blur...")
    process_images(source_dir, target_dir, noise_std=MEASURED_NOISE_STD, blur_radius=BLUR_RADIUS)
    print("\nDataset generation complete!")
    print(f"Clean and noisy images saved to: {os.path.abspath(target_dir)}")