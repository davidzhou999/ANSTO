﻿import torch
import torch.nn as nn
import torch.nn.functional as F

class DoubleConv(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=True),
            nn.ReLU(inplace=True),
        )
        self._init()

    def _init(self):
        for m in self.net.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, nonlinearity="relu")
                nn.init.zeros_(m.bias)

    def forward(self, x):
        return self.net(x)

class EnhancedUNet(nn.Module):
    """
    4-level U-Net with correct skip pairings:
      up4 ⟺ e4, up3 ⟺ e3, up2 ⟺ e2, up1 ⟺ e1
    """
    def __init__(self, in_channels=1, out_channels=1, features=(64,128,256,512)):
        super().__init__()
        f1, f2, f3, f4 = features

        # Encoder
        self.c1 = DoubleConv(in_channels, f1)
        self.p1 = nn.MaxPool2d(2)
        self.c2 = DoubleConv(f1, f2)
        self.p2 = nn.MaxPool2d(2)
        self.c3 = DoubleConv(f2, f3)
        self.p3 = nn.MaxPool2d(2)
        self.c4 = DoubleConv(f3, f4)
        self.p4 = nn.MaxPool2d(2)

        # Bottleneck
        self.cb = DoubleConv(f4, f4)

        # Decoder
        self.u4  = nn.ConvTranspose2d(f4, f3, 2, 2)              # 1/16 -> 1/8
        self.dc4 = DoubleConv(f3 + f4, f3)                       # cat with e4 (f4)
        self.u3  = nn.ConvTranspose2d(f3, f2, 2, 2)              # 1/8 -> 1/4
        self.dc3 = DoubleConv(f2 + f3, f2)                       # cat with e3 (f3)
        self.u2  = nn.ConvTranspose2d(f2, f1, 2, 2)              # 1/4 -> 1/2
        self.dc2 = DoubleConv(f1 + f2, f1)                       # cat with e2 (f2)
        self.u1  = nn.ConvTranspose2d(f1, f1, 2, 2)              # 1/2 -> 1/1
        self.dc1 = DoubleConv(f1 + f1, f1)                       # cat with e1 (f1)

        # Heads
        self.head = nn.Conv2d(f1, out_channels, 1)
        nn.init.kaiming_normal_(self.head.weight, nonlinearity="linear")
        nn.init.zeros_(self.head.bias)

        # Light residual from early encoder to output
        self.res_conv = nn.Conv2d(f1, out_channels, 1)
        nn.init.kaiming_normal_(self.res_conv.weight, nonlinearity="linear")
        nn.init.zeros_(self.res_conv.bias)

    def forward(self, x):
        # Encode
        e1 = self.c1(x)             # H
        e2 = self.c2(self.p1(e1))   # H/2
        e3 = self.c3(self.p2(e2))   # H/4
        e4 = self.c4(self.p3(e3))   # H/8
        b  = self.cb(self.p4(e4))   # H/16

        # Decode with proper skips
        d4 = self.u4(b)                         # H/8
        d4 = self.dc4(torch.cat([d4, e4], 1))   # concat e4

        d3 = self.u3(d4)                        # H/4
        d3 = self.dc3(torch.cat([d3, e3], 1))   # concat e3

        d2 = self.u2(d3)                        # H/2
        d2 = self.dc2(torch.cat([d2, e2], 1))   # concat e2

        d1 = self.u1(d2)                        # H
        d1 = self.dc1(torch.cat([d1, e1], 1))   # concat e1

        main = self.head(d1)
        res  = self.res_conv(e1)
        out  = main + res
        return torch.sigmoid(out)
