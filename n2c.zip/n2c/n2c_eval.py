#!/usr/bin/env python
# n2c_eval.py  (patched: per-image CSV, top-N best/worst, error-maps, fp32 metrics)
import os, csv, math, argparse, glob, shutil
import numpy as np
from tqdm import tqdm

import torch
import torch.nn.functional as F

# AMP (PyTorch 2.x / 1.x compatibility)
try:
    from torch.amp import autocast, GradScaler  # PyTorch ≥2.0
except ImportError:
    from torch.cuda.amp import autocast, GradScaler  # PyTorch 1.x

import imageio.v2 as imageio
import tifffile

from model import EnhancedUNet
from dataset_mixed import PairedXRDataset  # uses your *_noisy ↔ *_clean pairing

# ---------------- IO helpers ----------------
def _read_any01(path):
    p = path.lower()
    if p.endswith((".tif",".tiff")):
        a = tifffile.imread(path)
        if a.ndim>2: a = a[...,0]
        dt = a.dtype
        a = a.astype(np.float32)
        maxv = np.iinfo(dt).max if np.issubdtype(dt, np.integer) else max(1.0, float(a.max()))
        return a/maxv, dt, maxv
    a = imageio.imread(path)
    if a.ndim==3 and a.shape[2]>=3:
        a = 0.2989*a[...,0] + 0.5870*a[...,1] + 0.1140*a[...,2]
    elif a.ndim==3:
        a = a[...,0]
    dt = a.dtype
    a = a.astype(np.float32)
    maxv = np.iinfo(dt).max if np.issubdtype(dt, np.integer) else max(1.0, float(a.max()))
    return a/maxv, dt, maxv

def _write_like(path_out, arr01, orig_dtype, maxv):
    arr01 = np.clip(arr01, 0, 1)
    ext = os.path.splitext(path_out)[1].lower()
    if ext in (".tif",".tiff"):
        if np.issubdtype(orig_dtype, np.integer) and np.iinfo(orig_dtype).bits == 16:
            out = (arr01*65535.0 + 0.5).astype(np.uint16)
        else:
            out = (arr01*255.0 + 0.5).astype(np.uint8)
        tifffile.imwrite(path_out, out)
    else:
        out = (arr01*255.0 + 0.5).astype(np.uint8)
        imageio.imwrite(path_out, out)

@torch.no_grad()
def denoise_tiled(model, img01, tile=768, overlap=48, device="cuda"):
    model.eval()
    H, W = img01.shape
    step = tile - overlap
    out = np.zeros_like(img01, dtype=np.float32)
    weight = np.zeros_like(img01, dtype=np.float32)
    for y in range(0, H, step):
        y0 = min(max(0, y), max(0, H - tile)); y1 = min(H, y0 + tile)
        for x in range(0, W, step):
            x0 = min(max(0, x), max(0, W - tile)); x1 = min(W, x0 + tile)
            patch = img01[y0:y1, x0:x1][None, None, ...]
            patch_t = torch.from_numpy(patch).to(device=device, dtype=torch.float32)
            with autocast(device_type="cuda", enabled=True):
                pred = model(patch_t)
            pred = pred.detach().float().cpu().numpy()[0,0]
            out[y0:y1, x0:x1] += pred
            weight[y0:y1, x0:x1] += 1.0
    weight[weight==0] = 1.0
    return out/weight

# ---------- Metrics ----------
def psnr_from_mse(mse):
    mse = max(1e-12, float(mse))
    return 20*math.log10(1.0) - 10*math.log10(mse)

def compute_metrics(pred, tgt):
    """
    pred,tgt : tensors in [0,1], shape [1,1,H,W]
    returns: psnr, ssim, mae, mse
    """
    with torch.no_grad():
        # compute metrics in fp32 (robust against AMP dtypes)
        pred = pred.detach().float().clamp(0, 1)
        tgt  = tgt.detach().float().clamp(0, 1)
        mse  = torch.mean((pred - tgt)**2).item()
        mae  = torch.mean(torch.abs(pred - tgt)).item()
        psnr = psnr_from_mse(mse)
        with autocast(device_type="cuda", enabled=False):
            ssim = ssim_torch(pred, tgt)
    return psnr, ssim, mae, mse

def ssim_torch(x, y, window=11, C1=0.01**2, C2=0.03**2):
    # x,y in [0,1], NCHW
    ch = x.shape[1]
    g = torch.tensor([math.exp(-(i-window//2)**2/(2*1.5**2)) for i in range(window)],
                     dtype=x.dtype, device=x.device)
    g = (g / g.sum()).unsqueeze(1)
    w = (g @ g.t()).unsqueeze(0).unsqueeze(0)  # 1x1xhxw
    w = w.expand(ch, 1, window, window).contiguous()
    mu1 = F.conv2d(x, w, padding=window//2, groups=ch)
    mu2 = F.conv2d(y, w, padding=window//2, groups=ch)
    mu1_sq, mu2_sq, mu1_mu2 = mu1**2, mu2**2, mu1*mu2
    sigma1_sq = F.conv2d(x*x, w, padding=window//2, groups=ch) - mu1_sq
    sigma2_sq = F.conv2d(y*y, w, padding=window//2, groups=ch) - mu2_sq
    sigma12  = F.conv2d(x*y, w, padding=window//2, groups=ch) - mu1_mu2
    ssim = ((2*mu1_mu2 + C1)*(2*sigma12 + C2))/((mu1_sq + mu2_sq + C1)*(sigma1_sq + sigma2_sq + C2))
    return ssim.mean().item()

# --------- filename helpers (robust to dataset variations) ----------
def _extract_name(ds, idx):
    """
    Try to recover a sensible base name for the pair at index idx.
    Falls back to 'val_{idx:04d}' if not available.
    """
    # Common patterns: ds.pairs -> [(noisy_path, clean_path), ...]
    for attr in ["pairs", "file_pairs", "items", "samples"]:
        if hasattr(ds, attr):
            try:
                item = getattr(ds, attr)[idx]
                # item may be tuple or dict
                if isinstance(item, (list, tuple)) and len(item) >= 1:
                    noisy_path = item[0]
                elif isinstance(item, dict):
                    noisy_path = item.get("noisy", None) or item.get("noisy_path", None)
                else:
                    noisy_path = None
                if noisy_path:
                    base = os.path.splitext(os.path.basename(str(noisy_path)))[0]
                    # strip common suffixes
                    for suf in ["_noisy", "-noisy", ".noisy"]:
                        if base.endswith(suf):
                            base = base[: -len(suf)]
                    return base
            except Exception:
                pass
    # Other pattern: per-split arrays
    for attr in ["noisy_paths", "noisy_files", "inputs"]:
        if hasattr(ds, attr):
            try:
                noisy_path = getattr(ds, attr)[idx]
                base = os.path.splitext(os.path.basename(str(noisy_path)))[0]
                for suf in ["_noisy", "-noisy", ".noisy"]:
                    if base.endswith(suf):
                        base = base[: -len(suf)]
                return base
            except Exception:
                pass
    return f"val_{idx:04d}"

# ---------- Validation + ranking ----------
def _save_errmap(pred01, clean01, out_path):
    # grayscale absolute error; robust scale with 99.5th percentile
    err = np.abs(pred01 - clean01)
    vmax = np.percentile(err, 99.5) if err.size > 0 else 1.0
    vmax = max(vmax, 1e-6)
    em = np.clip(err / vmax, 0, 1)
    imageio.imwrite(out_path, (em*255.0 + 0.5).astype(np.uint8))

def eval_pairs(model, val_dir, device, save_dir=None, csv_path=None,
               save_val_preds=False, save_errmaps=False,
               topk=10, rank_by="psnr"):
    """
    Returns avg dict and writes:
      - per-image CSV (with filename + metrics)
      - optional: denoised preds / error-maps
      - top-N best/worst folders according to rank_by
    """
    from torch.utils.data import DataLoader
    ds = PairedXRDataset(val_dir, crop_size=None, is_train=False)
    dl = DataLoader(ds, batch_size=1, shuffle=False, num_workers=0, pin_memory=True)
    rows = []
    psnrs, ssims, maes, mses = [], [], [], []

    save_root = save_dir
    if save_root:
        os.makedirs(save_root, exist_ok=True)
        if save_val_preds:
            os.makedirs(os.path.join(save_root, "val_preds"), exist_ok=True)
        if save_errmaps:
            os.makedirs(os.path.join(save_root, "val_errmaps"), exist_ok=True)

    for idx, (noisy, clean) in enumerate(tqdm(dl, desc="Validating")):
        noisy = noisy.to(device, non_blocking=True)
        clean = clean.to(device, non_blocking=True)

        # AMP forward for speed
        with autocast(device_type="cuda", enabled=True):
            pred = model(noisy)
        pred = torch.nan_to_num(pred, nan=0.0, posinf=1.0, neginf=0.0)

        # Metrics in fp32
        psnr, ssim, mae, mse = compute_metrics(pred, clean)
        psnrs.append(psnr); ssims.append(ssim); maes.append(mae); mses.append(mse)

        name = _extract_name(ds, idx)
        row = {"index": idx, "name": name, "psnr": psnr, "ssim": ssim, "mae": mae, "mse": mse}
        rows.append(row)

        if save_root and (save_val_preds or save_errmaps):
            out01 = pred.detach().float().cpu().numpy()[0,0]
            out01 = np.clip(out01, 0, 1)
            gt01  = clean.detach().float().cpu().numpy()[0,0]
            if save_val_preds:
                imageio.imwrite(os.path.join(save_root, "val_preds", f"{name}_denoised.png"),
                                (out01*255.0 + 0.5).astype(np.uint8))
            if save_errmaps:
                _save_errmap(out01, gt01, os.path.join(save_root, "val_errmaps", f"{name}_errmap.png"))

    # Averages
    avg = {
        "index": "AVG",
        "name": "AVG",
        "psnr": float(np.mean(psnrs)) if psnrs else 0.0,
        "ssim": float(np.mean(ssims)) if ssims else 0.0,
        "mae":  float(np.mean(maes))  if maes  else 0.0,
        "mse":  float(np.mean(mses))  if mses  else 0.0,
    }
    rows.append(avg)

    # CSV (per-image + average row)
    if csv_path:
        os.makedirs(os.path.dirname(csv_path) or ".", exist_ok=True)
        with open(csv_path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["index","name","psnr","ssim","mae","mse"])
            w.writeheader(); w.writerows(rows)

    print(f"VAL — PSNR: {avg['psnr']:.2f} | SSIM: {avg['ssim']:.4f} | MAE: {avg['mae']:.5f} | MSE: {avg['mse']:.6f}")

    # --------- Top-N best/worst by chosen metric ----------
    if save_root and topk > 0 and len(rows) > 1:
        # drop AVG row for ranking
        sample_rows = [r for r in rows if isinstance(r["index"], int)]
        key = rank_by.lower()
        assert key in {"psnr","ssim","mae","mse"}, "rank_by must be one of: psnr, ssim, mae, mse"

        reverse = key in {"psnr","ssim"}  # higher is better
        sample_rows_sorted = sorted(sample_rows, key=lambda r: r[key], reverse=reverse)

        K = min(topk, len(sample_rows_sorted))
        best = sample_rows_sorted[:K]
        worst = sample_rows_sorted[-K:][::-1]  # worst first

        # Make folders
        best_dir = os.path.join(save_root, f"top_{K}_best_{key}")
        worst_dir = os.path.join(save_root, f"top_{K}_worst_{key}")
        os.makedirs(best_dir, exist_ok=True)
        os.makedirs(worst_dir, exist_ok=True)

        # Copy/mirror images if we saved them; otherwise write small text markers
        val_preds_dir = os.path.join(save_root, "val_preds")
        val_errs_dir  = os.path.join(save_root, "val_errmaps")

        def maybe_copy(name, out_dir, rank, score):
            base = f"{rank:02d}_{name}_{key}_{score:.4f}"
            # copy prediction
            pred_src = os.path.join(val_preds_dir, f"{name}_denoised.png")
            if os.path.exists(pred_src):
                shutil.copy2(pred_src, os.path.join(out_dir, base + "_denoised.png"))
            # copy errmap
            err_src = os.path.join(val_errs_dir, f"{name}_errmap.png")
            if os.path.exists(err_src):
                shutil.copy2(err_src, os.path.join(out_dir, base + "_errmap.png"))
            # write a tiny txt if nothing to copy
            if not os.path.exists(pred_src) and not os.path.exists(err_src):
                with open(os.path.join(out_dir, base + ".txt"), "w") as f:
                    f.write("No saved images; enable --save_val_preds and/or --save_errmaps.\n")

        for i, r in enumerate(best, 1):
            maybe_copy(r["name"], best_dir, i, r[key])
        for i, r in enumerate(worst, 1):
            maybe_copy(r["name"], worst_dir, i, r[key])

        # Write small summaries
        for tag, group, out_dir in [("best", best, best_dir), ("worst", worst, worst_dir)]:
            with open(os.path.join(out_dir, f"{tag}_{key}.csv"), "w", newline="") as f:
                w = csv.DictWriter(f, fieldnames=["rank","index","name","psnr","ssim","mae","mse"])
                w.writeheader()
                for rank, r in enumerate(group, 1):
                    rr = {"rank": rank, **r}
                    w.writerow(rr)

    return avg

# ---------- Denoise a generic folder ----------
def denoise_folder(model, in_dir, out_dir, device, tile=768, overlap=48):
    os.makedirs(out_dir, exist_ok=True)
    exts = (".png",".tif",".tiff",".jpg",".jpeg")
    files = [p for p in glob.glob(os.path.join(in_dir, "*")) if p.lower().endswith(exts)]
    print(f"Found {len(files)} files in test folder")
    for fp in tqdm(files, desc="Denoising test"):
        img01, dt, maxv = _read_any01(fp)
        if img01.shape[0]*img01.shape[1] >= 2000*2000:
            out01 = denoise_tiled(model, img01, tile=tile, overlap=overlap, device=device)
        else:
            with torch.no_grad():
                patch = torch.from_numpy(img01[None,None,...]).to(device=device, dtype=torch.float32)
                with autocast(device_type="cuda", enabled=True):
                    out = model(patch)
                out01 = out.detach().float().cpu().numpy()[0,0]
        base, ext = os.path.splitext(os.path.basename(fp))
        ext = ext.lower()
        out_name = f"{base}_denoised{ext if ext in ('.tif','.tiff') else '.png'}"
        _write_like(os.path.join(out_dir, out_name), out01, dt, maxv)

# ---------- CLI ----------
def main():
    ap = argparse.ArgumentParser("N2C evaluation / test denoise (patched)")
    ap.add_argument("--ckpt", required=True, help="Path to checkpoint (.pt)")
    ap.add_argument("--val_dir", default=None, help="Paired *_noisy/*_clean directory for metrics")
    ap.add_argument("--test_dir", default=None, help="Folder of noisy images to denoise")
    ap.add_argument("--save_dir", default=None, help="Folder to save outputs (metrics/preds/errmaps/rankings)")
    ap.add_argument("--csv", default=None, help="Write per-image metrics CSV (val only)")
    ap.add_argument("--tile", type=int, default=768)
    ap.add_argument("--overlap", type=int, default=48)
    ap.add_argument("--save_val_preds", action="store_true", help="Save validation denoised outputs")
    ap.add_argument("--save_errmaps", action="store_true", help="Save validation error-maps")
    ap.add_argument("--topk", type=int, default=10, help="Top-N best/worst to export (0 to disable)")
    ap.add_argument("--rank_by", choices=["psnr","ssim","mae","mse"], default="psnr")
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Device:", device)
    if device.type == "cuda":
        print("GPU:", torch.cuda.get_device_name(0))

    model = EnhancedUNet().to(device)
    try:
        ckpt = torch.load(args.ckpt, map_location=device, weights_only=True)
    except TypeError:
        ckpt = torch.load(args.ckpt, map_location=device)
    model.load_state_dict(ckpt["model_state_dict"])

    if args.val_dir:
        eval_pairs(model, args.val_dir, device,
                   save_dir=args.save_dir, csv_path=args.csv,
                   save_val_preds=args.save_val_preds,
                   save_errmaps=args.save_errmaps,
                   topk=args.topk, rank_by=args.rank_by)

    if args.test_dir:
        out_dir = args.save_dir or os.path.join(args.test_dir, "denoised")
        denoise_folder(model, args.test_dir, out_dir, device, tile=args.tile, overlap=args.overlap)

if __name__ == "__main__":
    torch.backends.cudnn.benchmark = True
    try: torch.set_float32_matmul_precision("medium")
    except Exception: pass
    main()
