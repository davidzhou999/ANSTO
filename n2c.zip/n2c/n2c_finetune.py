#!/usr/bin/env python
# n2c_finetune.py
import os, time, math, argparse
import numpy as np
from tqdm import tqdm

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

# AMP (PyTorch 2.x / 1.x compatibility)
try:
    from torch.amp import autocast, GradScaler  # PyTorch ≥2.0
except ImportError:
    from torch.cuda.amp import autocast, GradScaler  # PyTorch 1.x

from model import EnhancedUNet
from dataset_mixed import PairedXRDataset

# ---------- Losses ----------
class SSIMLoss(nn.Module):
    def __init__(self, window_size=11):
        super().__init__()
        self.window_size = window_size
    def _gaussian(self, window_size, sigma):
        g = torch.tensor([math.exp(-(x-window_size//2)**2/(2*sigma**2)) for x in range(window_size)], dtype=torch.float32)
        return g / g.sum()
    def _win(self, c, device, dtype):
        w = self._gaussian(self.window_size, 1.5).unsqueeze(1)
        w2 = (w @ w.t()).float().unsqueeze(0).unsqueeze(0)
        return w2.expand(c, 1, self.window_size, self.window_size).contiguous().to(device=device, dtype=dtype)
    def forward(self, x, y):
        import torch.nn.functional as F
        c = x.shape[1]
        w = self._win(c, x.device, x.dtype)
        mu1 = F.conv2d(x, w, padding=self.window_size//2, groups=c)
        mu2 = F.conv2d(y, w, padding=self.window_size//2, groups=c)
        mu1_sq, mu2_sq, mu1_mu2 = mu1**2, mu2**2, mu1*mu2
        sigma1_sq = F.conv2d(x*x, w, padding=self.window_size//2, groups=c) - mu1_sq
        sigma2_sq = F.conv2d(y*y, w, padding=self.window_size//2, groups=c) - mu2_sq
        sigma12  = F.conv2d(x*y, w, padding=self.window_size//2, groups=c) - mu1_mu2
        C1, C2 = 0.01**2, 0.03**2
        ssim = ((2*mu1_mu2 + C1)*(2*sigma12 + C2))/((mu1_sq + mu2_sq + C1)*(sigma1_sq + sigma2_sq + C2))
        return 1 - ssim.mean()

class MixedLoss(nn.Module):
    def __init__(self, alpha=0.9):
        super().__init__()
        self.l1 = nn.L1Loss()
        self.ssim = SSIMLoss()
        self.alpha = alpha
    def forward(self, pred, tgt):
        return self.alpha*self.l1(pred, tgt) + (1-self.alpha)*self.ssim(pred, tgt)

# ---------- Helpers ----------
def psnr_from_mse(mse):
    mse = max(1e-12, float(mse))
    return 20*math.log10(1.0) - 10*math.log10(mse)

@torch.no_grad()
def validate(model, loader, device):
    model.eval()
    mse_sum, n_pix = 0.0, 0
    for noisy, clean in loader:
        noisy = noisy.to(device, non_blocking=True)
        clean = clean.to(device, non_blocking=True)
        with autocast(device_type="cuda", enabled=True):
            out = model(noisy)
        out = torch.nan_to_num(out, nan=0.0, posinf=1.0, neginf=0.0).clamp(0,1)
        mse = torch.mean((out-clean)**2).item()
        pixels = noisy.shape[-1]*noisy.shape[-2]
        mse_sum += mse * pixels
        n_pix += pixels
    avg_mse = mse_sum / max(1, n_pix)
    psnr = psnr_from_mse(avg_mse)
    return psnr, avg_mse

def freeze_strategy(model, mode="head", last_n=2):
    """
    mode:
      - 'head'   : train only output heads (fast, safe)
      - 'lastN'  : train last N decoder levels + heads
      - 'all'    : train all layers
    """
    # First freeze everything
    for p in model.parameters():
        p.requires_grad = False

    if mode == "all":
        for p in model.parameters():
            p.requires_grad = True
        return

    if mode == "head":
        for m in [model.dc1, model.head, model.res_conv]:
            for p in m.parameters(): p.requires_grad = True
        return

    if mode == "lastN":
        train_blocks = []
        # decoder levels from deepest to shallowest: (dc4,u4), (dc3,u3), (dc2,u2), (dc1,u1)
        order = [(model.dc1, model.u1),
                 (model.dc2, model.u2),
                 (model.dc3, model.u3),
                 (model.dc4, model.u4)]
        for i in range(min(last_n, len(order))):
            train_blocks += list(order[i])
        train_blocks += [model.head, model.res_conv]
        for blk in train_blocks:
            for p in blk.parameters(): p.requires_grad = True
        return

def main():
    ap = argparse.ArgumentParser("N2C fine-tuner")
    ap.add_argument("--train_dir", required=True)
    ap.add_argument("--val_dir", required=True)
    ap.add_argument("--from_ckpt", required=True, help="Base checkpoint to start from (.pt)")
    ap.add_argument("--save_path", default="data/n2c_finetuned.pt")
    ap.add_argument("--epochs", type=int, default=20)
    ap.add_argument("--batch_size", type=int, default=6)
    ap.add_argument("--lr", type=float, default=5e-5)
    ap.add_argument("--crop_size", type=int, default=256)
    ap.add_argument("--loss", choices=["l1","mixed"], default="l1")
    ap.add_argument("--alpha", type=float, default=0.9)
    ap.add_argument("--freeze", choices=["head","lastN","all"], default="head")
    ap.add_argument("--last_n", type=int, default=2)
    ap.add_argument("--log_dir", default="logs_finetune")
    ap.add_argument("--num_workers", type=int, default=0)
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)
    if device.type == "cuda":
        print("GPU:", torch.cuda.get_device_name(0))

    # Data
    train_ds = PairedXRDataset(args.train_dir, crop_size=args.crop_size, is_train=True)
    val_ds   = PairedXRDataset(args.val_dir,   crop_size=None,          is_train=False)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                              num_workers=args.num_workers, pin_memory=True)
    val_loader   = DataLoader(val_ds, batch_size=1, shuffle=False, num_workers=0, pin_memory=True)

    # Model
    model = EnhancedUNet().to(device)
    try:
        base = torch.load(args.from_ckpt, map_location=device, weights_only=True)
    except TypeError:
        base = torch.load(args.from_ckpt, map_location=device)
    model.load_state_dict(base["model_state_dict"], strict=True)

    # Freeze policy
    freeze_strategy(model, mode=args.freeze, last_n=args.last_n)
    trainable_params = [p for p in model.parameters() if p.requires_grad]
    print(f"Trainable params: {sum(p.numel() for p in trainable_params):,}")

    # Loss/optim/sched
    if args.loss == "l1":
        criterion = nn.L1Loss()
    else:
        criterion = MixedLoss(alpha=args.alpha)
    optimizer = torch.optim.AdamW(trainable_params, lr=args.lr, weight_decay=5e-5)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=1e-6)
    scaler = GradScaler(enabled=True)

    # Auto-resume if save exists (optional)
    start_epoch, best_psnr = 0, -float("inf")
    if os.path.exists(args.save_path):
        try:
            try:
                ckpt = torch.load(args.save_path, map_location=device, weights_only=True)
            except TypeError:
                ckpt = torch.load(args.save_path, map_location=device)
            model.load_state_dict(ckpt["model_state_dict"], strict=True)
            optimizer.load_state_dict(ckpt["optimizer_state_dict"])
            if "scheduler_state_dict" in ckpt:
                try:
                    scheduler.load_state_dict(ckpt["scheduler_state_dict"])
                except Exception:
                    print("Warn: scheduler state not compatible; continuing fresh scheduler")
            start_epoch = ckpt.get("epoch", 0) + 1
            best_psnr = ckpt.get("best_psnr", best_psnr)
            print(f"Resumed from epoch {start_epoch}, best PSNR {best_psnr:.2f}")
        except Exception as e:
            print("Resume failed:", e)

    writer = SummaryWriter(args.log_dir)
    accum = 4  # gradient accumulation for stability/VRAM

    try:
        for epoch in range(start_epoch, args.epochs):
            model.train()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                torch.cuda.reset_peak_memory_stats()

            tot_loss, steps = 0.0, 0
            optimizer.zero_grad(set_to_none=True)
            pbar = tqdm(train_loader, leave=False, desc=f"Finetune Epoch {epoch}")

            for i, (noisy, clean) in enumerate(pbar):
                noisy = noisy.to(device, non_blocking=True)
                clean = clean.to(device, non_blocking=True)
                with autocast(device_type="cuda", enabled=True):
                    pred = model(noisy)
                    if torch.isnan(pred).any() or torch.isinf(pred).any():
                        continue
                    loss = criterion(pred, clean)

                scaler.scale(loss/accum).backward()

                if (i+1) % accum == 0 or (i+1) == len(train_loader):
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(trainable_params, 0.1)
                    scaler.step(optimizer)
                    scaler.update()
                    optimizer.zero_grad(set_to_none=True)

                tot_loss += loss.item()
                steps += 1
                pbar.set_postfix(loss=f"{loss.item():.4f}")

            avg_loss = tot_loss / max(1, steps)
            psnr, mse = validate(model, val_loader, device)

            # Logs
            lr = optimizer.param_groups[0]["lr"]
            writer.add_scalar("train/loss", avg_loss, epoch)
            writer.add_scalar("val/psnr", psnr, epoch)
            writer.add_scalar("val/mse", mse, epoch)
            writer.add_scalar("train/lr", lr, epoch)

            print(f"Epoch {epoch}/{args.epochs} | Loss {avg_loss:.4f} | PSNR {psnr:.2f} | LR {lr:.2e}")

            # Save best
            if psnr > best_psnr:
                best_psnr = psnr
                torch.save({
                    "epoch": epoch,
                    "best_psnr": best_psnr,
                    "model_state_dict": model.state_dict(),
                    "optimizer_state_dict": optimizer.state_dict(),
                    "scheduler_state_dict": scheduler.state_dict(),
                }, args.save_path)
                print(f"Saved new best checkpoint (PSNR: {best_psnr:.2f})")

            scheduler.step()

    except KeyboardInterrupt:
        print("Interrupted by user.")
    finally:
        writer.close()
        print("Fine-tune done. Best PSNR:", best_psnr)

if __name__ == "__main__":
    import torch
    torch.backends.cudnn.benchmark = True
    try: torch.set_float32_matmul_precision("medium")
    except Exception: pass
    main()
