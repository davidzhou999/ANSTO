#!/usr/bin/env python
import os, argparse, glob
import numpy as np
import torch
from torch.cuda.amp import autocast
import imageio.v2 as imageio
import tifffile
from tqdm import tqdm
from model import EnhancedUNet

# AMP (PyTorch 2.x / 1.x compatibility)
try:
    from torch.amp import autocast, GradScaler  # PyTorch ≥2.0
except ImportError:
    from torch.cuda.amp import autocast, GradScaler  # PyTorch 1.x

def read_any(path):
    p = path.lower()
    if p.endswith((".tif",".tiff")):
        a = tifffile.imread(path)
        if a.ndim>2: a = a[...,0]
        dt = a.dtype
        a = a.astype(np.float32)
        maxv = np.iinfo(dt).max if np.issubdtype(dt, np.integer) else max(1.0, float(a.max()))
        return a/maxv, dt, maxv
    # PNG/JPG
    a = imageio.imread(path)
    if a.ndim==3 and a.shape[2]>=3:
        a = 0.2989*a[...,0] + 0.5870*a[...,1] + 0.1140*a[...,2]
    elif a.ndim==3:
        a = a[...,0]
    dt = a.dtype
    a = a.astype(np.float32)
    maxv = np.iinfo(dt).max if np.issubdtype(dt, np.integer) else max(1.0, float(a.max()))
    return a/maxv, dt, maxv

def write_like(path_out, arr01, orig_dtype, maxv):
    arr01 = np.clip(arr01, 0, 1)
    ext = os.path.splitext(path_out)[1].lower()
    if ext in (".tif",".tiff"):
        if np.issubdtype(orig_dtype, np.integer) and np.iinfo(orig_dtype).bits == 16:
            out = (arr01*65535.0 + 0.5).astype(np.uint16)
        else:
            out = (arr01*255.0 + 0.5).astype(np.uint8)
        tifffile.imwrite(path_out, out)
    else:
        out = (arr01*255.0 + 0.5).astype(np.uint8)
        imageio.imwrite(path_out, out)

@torch.no_grad()
def denoise_tiled(model, img01, tile=768, overlap=48, device="cuda"):
    model.eval()
    H, W = img01.shape
    step = tile - overlap
    out = np.zeros_like(img01, dtype=np.float32)
    weight = np.zeros_like(img01, dtype=np.float32)
    for y in range(0, H, step):
        y0 = min(max(0, y), max(0, H - tile)); y1 = min(H, y0 + tile)
        for x in range(0, W, step):
            x0 = min(max(0, x), max(0, W - tile)); x1 = min(W, x0 + tile)
            patch = img01[y0:y1, x0:x1][None, None, ...]
            patch_t = torch.from_numpy(patch).to(device=device, dtype=torch.float32)
            with autocast(device_type="cuda", enabled=True):
                pred = model(patch_t)  # <- This is correct
            pred = pred.detach().float().cpu().numpy()[0,0]
            out[y0:y1, x0:x1] += pred
            weight[y0:y1, x0:x1] += 1.0
    weight[weight==0] = 1.0
    return out/weight

def main():
    ap = argparse.ArgumentParser("N2C inference")
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--input_dir", required=True)
    ap.add_argument("--output_dir", required=True)
    ap.add_argument("--tile", type=int, default=768)
    ap.add_argument("--overlap", type=int, default=48)
    args = ap.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = EnhancedUNet().to(device)
    ckpt = torch.load(args.ckpt, map_location=device)
    model.load_state_dict(ckpt["model_state_dict"])

    exts = (".png",".tif",".tiff",".jpg",".jpeg")
    files = [p for p in glob.glob(os.path.join(args.input_dir, "*")) if p.lower().endswith(exts)]
    print(f"Found {len(files)} files")

    for fp in tqdm(files):
        img01, dt, maxv = read_any(fp)
        out01 = denoise_tiled(model, img01, tile=args.tile, overlap=args.overlap, device=device)
        base, ext = os.path.splitext(os.path.basename(fp))
        ext = ext.lower()
        out_name = f"{base}_denoised{ext if ext in ('.tif','.tiff') else '.png'}"
        write_like(os.path.join(args.output_dir, out_name), out01, dt, maxv)

if __name__=="__main__":
    main()