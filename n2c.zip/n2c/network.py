﻿import torch
import torch.nn as nn
import torch.nn.functional as F

class ResidualBlock(nn.Module):
    def __init__(self, in_ch):
        super().__init__()
        self.conv1 = nn.Conv2d(in_ch, in_ch, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(in_ch)
        self.conv2 = nn.Conv2d(in_ch, in_ch, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(in_ch)

    def forward(self, x):
        residual = x
        x = F.relu(self.bn1(self.conv1(x)))
        x = self.bn2(self.conv2(x))
        return F.relu(x + residual)

class UNetResidual(nn.Module):
    def __init__(self, n_channels, n_classes):
        super().__init__()
        self.inc = nn.Sequential(
            nn.Conv2d(n_channels, 64, 3, padding=1),
            nn.ReLU(inplace=True),
            ResidualBlock(64),
        )
        self.down1 = nn.Sequential(nn.MaxPool2d(2), ResidualBlock(64))
        self.down2 = nn.Sequential(nn.MaxPool2d(2), ResidualBlock(64))
        self.up1 = nn.ConvTranspose2d(64, 64, 2, stride=2)
        self.up2 = nn.ConvTranspose2d(64, 64, 2, stride=2)
        self.outc = nn.Conv2d(64, n_classes, 1)

    def forward(self, x):
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x = self.up1(x3)
        x = self.up2(x + x2)
        x = self.outc(x + x1)
        return x
