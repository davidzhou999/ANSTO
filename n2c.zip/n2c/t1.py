﻿import cv2
import numpy as np
from skimage.metrics import structural_similarity as ssim
import os

# Verify files exist
print("Clean exists:", os.path.exists("clean.png"))
print("Noisy exists:", os.path.exists("noisy.png"))

# Load images
clean = cv2.imread("clean.png", cv2.IMREAD_GRAYSCALE)
noisy = cv2.imread("noisy.png", cv2.IMREAD_GRAYSCALE)

# Check image loading
if clean is None or noisy is None:
    raise ValueError("Error loading images - check file paths and formats")

# Calculate metrics
mse = np.mean((clean - noisy) ** 2)
psnr = cv2.PSNR(clean, noisy)
ssim_val, _ = ssim(clean, noisy, full=True)
mae = np.mean(np.abs(clean - noisy))

print(f"MSE: {mse:.2f}, PSNR: {psnr:.2f} dB, SSIM: {ssim_val:.4f}, MAE: {mae:.2f}")