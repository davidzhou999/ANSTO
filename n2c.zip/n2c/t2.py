﻿import cv2
print("OpenCV version:", cv2.__version__)
