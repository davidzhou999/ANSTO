# util.py
import os
import torch
import torchvision.utils as vutils
import torch.nn.functional as F
from skimage.metrics import peak_signal_noise_ratio as psnr
from skimage.metrics import structural_similarity as ssim
import numpy as np


def save_checkpoint(model, optimizer, path, epoch):
    torch.save({
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict()
    }, path)


def save_best_model(model, optimizer, epoch, best_psnr, path):
    torch.save({
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'best_psnr': best_psnr
    }, path)


def load_checkpoint(path, model):
    checkpoint = torch.load(path, map_location='cpu')
    model.load_state_dict(checkpoint['model_state_dict'])
    print(f"Loaded checkpoint from {path}")


def normalize(tensor):
    """Normalize tensor to [0, 1] range."""
    if isinstance(tensor, torch.utils.data.DataLoader):
        raise ValueError("Pass tensors, not DataLoader objects.")
    min_val = tensor.min()
    max_val = tensor.max()
    return (tensor - min_val) / (max_val - min_val + 1e-8)


def visualize_sample(writer, noisy, clean, output, epoch, step):
    """Logs images to TensorBoard with proper normalization and separate channels."""
    # Normalize tensors
    noisy = normalize(noisy)
    clean = normalize(clean)
    output = normalize(output)

    # Log images separately for better comparison
    writer.add_images("Sample/noisy", noisy, step)
    writer.add_images("Sample/clean", clean, step)
    writer.add_images("Sample/output", output, step)

    # Also save a comparison grid
    comparison = torch.cat([noisy, output, clean], dim=0)
    grid = vutils.make_grid(comparison, nrow=noisy.size(0), normalize=False, scale_each=False)
    writer.add_image('Comparison/Noisy_Output_Clean', grid, step)


def validate_metrics(model, dataloader, device):
    """Compute average PSNR and SSIM over the validation set."""
    model.eval()
    avg_psnr = []
    avg_ssim = []

    with torch.no_grad():
        for noisy, clean in dataloader:
            noisy = noisy.to(device)
            clean = clean.to(device)
            output = model(noisy)

            # Process each image in batch separately
            for i in range(noisy.size(0)):
                # Convert to numpy and squeeze channel dim if needed
                out_np = output[i].detach().cpu().squeeze().numpy()
                clean_np = clean[i].detach().cpu().squeeze().numpy()

                # Calculate metrics
                psnr_val = psnr(clean_np, out_np, data_range=1.0)
                ssim_val = ssim(clean_np, out_np, data_range=1.0,
                               win_size=7, channel_axis=None)  # For grayscale

                avg_psnr.append(psnr_val)
                avg_ssim.append(ssim_val)

    return np.mean(avg_psnr), np.mean(avg_ssim)


def log_gpu_memory():
    """Print current GPU memory usage with more detailed information."""
    if torch.cuda.is_available():
        alloc = torch.cuda.memory_allocated() / (1024 ** 3)
        reserved = torch.cuda.memory_reserved() / (1024 ** 3)
        total = torch.cuda.get_device_properties(0).total_memory / (1024 ** 3)
        print(f"[GPU Memory] Allocated: {alloc:.2f}GB, Reserved: {reserved:.2f}GB, "
              f"Total: {total:.2f}GB, Free: {total-alloc:.2f}GB")