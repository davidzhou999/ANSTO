
Neutron Self-Supervised Denoising + Reconstruction Pipeline

1) Pretrain (>=5000 mixed 8/16-bit TIFFs):
  python train_n2same_het_multi.py --roots D:/neutron/train1 D:/neutron/train2 --epochs 50 --batch 8 --amp --save_path data/n2same_het_pretrained.pt

2) Calibration-aware denoising of projections (dark/flat + -log export):
  python calibrate_and_predict.py ^
    --checkpoint data/n2same_het_pretrained.pt ^
    --input_dir data/scan ^
    --dark_dir data/dark ^
    --open_dir data/open ^
    --output_dir data/denoised ^
    --tile 768 --overlap 64 --amp --save_log

3) Reconstruction with TomoPy (+ASTRA GPU optional):
  python reconstruct_tomopy_astra.py ^
    --input_dir data/denoised ^
    --output_dir data/recon ^
    --theta_mode linspace --theta_start_deg 0 --theta_end_deg 180 --exclude_endpoint ^
    --algorithm gridrec --filter hann --remove_stripe --gpu --output_nii --output_tiff

Notes
-----
- The denoiser uses a Noise2Same-style masked objective with a heteroscedastic (per-pixel σ) head.
- `calibrate_and_predict.py` averages 5–100 darks and flats, normalizes each projection, denoises in [0,1], and optionally writes scaled -log(I) images (`*_log.tif`) for direct input into reconstruction.
- For 3D denoising of reconstructed volumes, use `train_n2same3d_het.py` and `predict_n2same3d_het.py` on .nii.gz volumes.



New helpers
-----------
- reconstruct_tomopy_astra.py: add --theta_mode filename with --angle_regex (default '(\d+(?:\.\d+)?)'), --angle_scale, --angle_offset.
- reconstruct_center_sweep.py: fast center search using downsampled projections and a focus metric (Tenengrad).

Ring-aware training
-------------------
- In 2D trainers, add --ring_w (default 0.01). This adds a stripe/ring proxy regularizer that penalizes column-wise bias of the context residuals, reducing ring propensity after reconstruction.
