import sys, os, platform, time
print("="*78)
print(f"Python: {sys.version.split()[0]}  |  Executable: {sys.executable}")
print(f"Conda/venv prefix: {sys.prefix}")
print(f"OS: {platform.system()} {platform.release()}  |  CPU: {platform.processor()}")
print("="*78)

# Torch / CUDA
import torch
print("[OK]  torch version:", torch.__version__)
print("CUDA available:", torch.cuda.is_available())
print("Torch CUDA build:", torch.version.cuda)
try:
    import torch.backends.cudnn as cudnn
    print("cuDNN version:", getattr(cudnn, 'version', lambda: 'n/a')())
except Exception as e:
    print("cuDNN check issue:", e)

if torch.cuda.is_available():
    print("CUDA device count:", torch.cuda.device_count())
    for i in range(torch.cuda.device_count()):
        props = torch.cuda.get_device_properties(i)
        print(f"  [{i}] {props.name} | CC {props.major}.{props.minor} | {props.total_memory/1024**3:.1f} GB")

# Tiny CPU/GPU matmul smoke
import time
import torch.nn.functional as F
import numpy as np

A = torch.randn(512, 512)
B = torch.randn(512, 512)
t0=time.time(); C = A@B; t1=time.time()
ms=(t1-t0)*1000
gflops = (2*512**3)/(t1-t0)/1e9
print(f"CPU matmul 512x512: {ms:.1f} ms | ~{gflops:.2f} GFLOP/s")

if torch.cuda.is_available():
    A = torch.randn(1024,1024, device='cuda')
    B = torch.randn(1024,1024, device='cuda')
    t0=torch.cuda.Event(enable_timing=True); t1=torch.cuda.Event(enable_timing=True)
    torch.cuda.synchronize(); t0.record(); C = A@B; t1.record(); torch.cuda.synchronize()
    ms = t0.elapsed_time(t1)
    gflops = (2*1024**3)/ (ms/1e3) / 1e9
    print(f"GPU matmul 1024x1024 ({torch.cuda.get_device_name(0)}): {ms:.1f} ms | ~{gflops:.2f} GFLOP/s")

# IO libs
import nibabel as nib, tifffile, tomopy
print("[OK]  nibabel version:", nib.__version__)
print("[OK]  tifffile version:", tifffile.__version__)
print("[OK]  tomopy version:", tomopy.__version__)
try:
    import astra
    print("[OK]  astra version:", astra.__version__)
except Exception as e:
    print("[MISS] astra:", e)

# tifffile in-memory write test
import io
arr = (np.random.rand(32,32)*65535).astype(np.uint16)
buf = io.BytesIO()
tifffile.imwrite(buf, arr)
print("[OK]  tifffile in-memory write test passed")
print("="*78)
print("Done.")

