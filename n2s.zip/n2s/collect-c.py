#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
TIFF Keyframe Extraction Script
===============================

Objective
---------
Recursively search a given ROOT folder (e.g. "\\\\zfstor6\\dingo\\proposal"), find
subfolders named "scan" (case-insensitive) that contain >100 TIFF images directly inside,
select 11 key images by position, rename them using a root-relative path scheme,
and copy them to Desktop\\david.

Details
-------
0) Folder Search
   - Walk all subfolders under ROOT (recursive).

1) Identify Target Folders
   - Folder name must be exactly "scan" (case-insensitive).
   - Count only ".tif"/".tiff" files directly under that folder (no recursion).
   - Proceed only if there are > 100 such files.

2) Image Selection Logic
   - Assume files are ordered by numeric sequence in their names (e.g. DINGO_000000.tiff ... DINGO_000999.tiff).
   - Sort ascending by numeric suffix (last run of digits before extension).
   - Select 11 frames: first (0%), last (100%), and 10%,20%,...,90%.
   - Use ceil() for rounding up decimal indices.

3) Renaming & Copying
   - Build new filename prefix from all intermediate folder names between ROOT and the "scan" folder,
     joined with underscores "_".
     Example:
       ROOT: \\zfstor6\\dingo\\proposal
       SCAN: \\zfstor6\\dingo\\proposal\\abc\\def\\hij\\scan
       New prefix: "abc_def_hij"
   - For each of the 11 selected images:
       abc_def_hij0.tiff … abc_def_hij10.tiff
   - Copy to: ~/Desktop/david
   - If a file with the same name exists, append "_dup1", "_dup2", etc. before extension to avoid overwriting.

4) Logging & Safety
   - Print actions (source -> destination).
   - Support --dry-run to simulate without copying.

Usage
-----
  python pick_scan_keyframes.py "\\\\zfstor6\\dingo\\proposal"

Optional:
  --dest "C:\\Users\\YourName\\Desktop\\david"
  --dry-run
"""

import os
import re
import math
import shutil
import argparse
from pathlib import Path

# Regex: last run of digits before .tif/.tiff
NUM_RE = re.compile(r'(\d+)(?=\.(?:tif|tiff)$)', re.IGNORECASE)

def numeric_key(p: Path):
    """Return a numeric sort key based on digits before the extension."""
    m = NUM_RE.search(p.name)
    if m:
        try:
            return (0, int(m.group(1)))
        except ValueError:
            pass
    return (1, p.name.lower())

def pick_indices(n: int):
    """Return indices for first, 10%,...,90%, last (ceil rule)."""
    idxs = [0]
    for k in range(1, 10):  # 10% … 90%
        idx = math.ceil(k * 0.1 * n)
        idx = min(max(idx, 0), n - 1)
        idxs.append(idx)
    idxs.append(n - 1)
    # Deduplicate
    cleaned, seen = [], set()
    for i in idxs:
        if i not in seen:
            cleaned.append(i)
            seen.add(i)
    return cleaned

def find_scan_dirs(root: Path):
    """Yield directories named 'scan' (case-insensitive)."""
    for dirpath, dirnames, filenames in os.walk(root):
        if Path(dirpath).name.lower() == "scan":
            yield Path(dirpath)

def list_tiffs(scan_dir: Path):
    """List .tif/.tiff files directly under scan_dir."""
    return [scan_dir / f for f in os.listdir(scan_dir)
            if (scan_dir / f).is_file() and f.lower().endswith(('.tif', '.tiff'))]

def ensure_dest_folder(dest: Path):
    dest.mkdir(parents=True, exist_ok=True)
    return dest

def unique_dst_path(dst: Path) -> Path:
    """Ensure no overwrite — append _dupN before extension if needed."""
    if not dst.exists():
        return dst
    stem, suffix = dst.stem, dst.suffix
    counter = 1
    while True:
        candidate = dst.with_name(f"{stem}_dup{counter}{suffix}")
        if not candidate.exists():
            return candidate
        counter += 1

def rel_base_name(root: Path, scan_dir: Path) -> str:
    """Return root-relative subpath (excluding scan), joined by underscores."""
    parent = scan_dir.parent
    try:
        rel = parent.relative_to(root)
        parts = [p for p in rel.parts if p not in (".", "")]
    except ValueError:
        parts = [p for p in parent.parts if p not in (".", "")]
    return "_".join(parts) if parts else "scan"

def main():
    parser = argparse.ArgumentParser(
        description="Pick 11 key TIFF frames from 'scan' folders and copy/rename them safely to Desktop/david."
    )
    parser.add_argument("root", help="Root folder to search (e.g. \\\\zfstor6\\dingo\\proposal)")
    parser.add_argument("--dest", default=str(Path.home() / "Desktop" / "david"),
                        help="Destination folder (default: ~/Desktop/david)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Simulate only; do not copy files.")
    args = parser.parse_args()

    root = Path(args.root)
    dest_root = ensure_dest_folder(Path(args.dest))

    if not root.exists():
        print(f"[ERROR] Root path does not exist: {root}")
        return

    total_copied = 0
    for scan_dir in find_scan_dirs(root):
        files = list_tiffs(scan_dir)
        if len(files) <= 100:
            print(f"[SKIP] {scan_dir} has {len(files)} TIFFs (need >100).")
            continue

        files.sort(key=numeric_key)
        n = len(files)
        idxs = pick_indices(n)
        base = rel_base_name(root, scan_dir)

        print(f"\n[INFO] Processing: {scan_dir}")
        print(f"       TIFF count: {n}, selected indices: {idxs}")
        print(f"       New filename base: {base}")

        for order, idx in enumerate(idxs):
            src = files[idx]
            new_name = f"{base}{order}{src.suffix.lower()}"
            dst = dest_root / new_name
            dst = unique_dst_path(dst)

            if args.dry_run:
                print(f"  [DRY] {src.name}  ->  {dst.name}")
            else:
                try:
                    shutil.copy2(src, dst)
                    print(f"  [OK ] {src.name}  ->  {dst.name}")
                    total_copied += 1
                except Exception as e:
                    print(f"  [ERR] Failed to copy {src.name}: {e}")

    print(f"\n[DONE] Total files copied: {total_copied}")
    print(f"       Destination: {dest_root}")

if __name__ == "__main__":
    main()
