#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
TIFF Keyframe Extraction Script (Rename clarified, copy debug-friendly)
======================================================================

Rename rule (exact):
1) The first part of the new filename is the ROOT-relative subpath of the folder
   that contains 'scan', with each level joined by underscores "_".
   (Exclude the ROOT prefix itself and exclude the final 'scan' segment.)
   Example:
     ROOT: \\\\zfstor6\\dingo\\proposal\\
     MATCHED SCAN: \\\\zfstor6\\dingo\\proposal\\abc\\def\\hij\\scan
     New name base: "abc_def_hij"

2) The last part is the order index of the 11 chosen images, from 0..10 (no zero padding),
   preserving the original extension (.tif/.tiff).
   So the 11 outputs will be:
     abc_def_hij0.tiff ... abc_def_hij10.tiff

Other rules:
- Search recursively for folders named exactly 'scan' (case-insensitive).
- Only process a 'scan' folder if it contains >100 .tif/.tiff files directly inside it.
- Select 11 images: first (0), ceil(10%*N), ..., ceil(90%*N), and last (N-1).
- Copy to ~/Desktop/david (or --dest). Create destination if missing.
- Avoid overwrites: append _dupN before extension when needed.
- Clear logging: prints every planned new name and copy result.
"""

import os
import re
import math
import shutil
import argparse
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

# Regex: last run of digits before .tif/.tiff (for sensible sort)
NUM_RE = re.compile(r'(\d+)(?=\.(?:tif|tiff)$)', re.IGNORECASE)


def numeric_key(p: Path):
    """Sort by the last numeric chunk before extension, else by lowercase name."""
    m = NUM_RE.search(p.name)
    if m:
        try:
            return (0, int(m.group(1)))
        except ValueError:
            pass
    return (1, p.name.lower())


def pick_indices(n: int):
    """
    Return indices [0, ceil(0.1*n), ..., ceil(0.9*n), n-1], de-duplicated and clamped.
    Matches the example: for 1000 files (0..999), yields [0,100,200,...,900,999].
    """
    idxs = [0]
    for k in range(1, 10):  # 10%..90%
        idx = math.ceil(k * 0.1 * n)
        if idx < 0:
            idx = 0
        if idx > n - 1:
            idx = n - 1
        idxs.append(idx)
    idxs.append(n - 1)
    # De-dup (defensive)
    seen = set()
    out = []
    for i in idxs:
        if i not in seen:
            out.append(i)
            seen.add(i)
    return out


def find_scan_dirs(root: Path):
    """Yield directories named 'scan' (case-insensitive)."""
    for dirpath, dirnames, filenames in os.walk(root):
        if Path(dirpath).name.lower() == "scan":
            yield Path(dirpath)


def list_tiffs(scan_dir: Path):
    """List .tif/.tiff files directly under scan_dir (non-recursive)."""
    files = []
    for name in os.listdir(scan_dir):
        p = scan_dir / name
        if p.is_file() and p.suffix.lower() in (".tif", ".tiff"):
            files.append(p)
    return files


def ensure_dest_folder(dest: Path):
    dest.mkdir(parents=True, exist_ok=True)
    return dest


def rel_base_name(root: Path, scan_dir: Path) -> str:
    """
    Build the base part of the new filename:
    - Take the path RELATIVE to ROOT of the parent folder of 'scan'
    - Join parts with underscores
    Example: ROOT/.../proposal, SCAN at .../proposal/abc/def/hij/scan -> "abc_def_hij"
    """
    parent = scan_dir.parent
    try:
        rel = parent.relative_to(root)
        parts = [p for p in rel.parts if p not in (".", "")]
    except ValueError:
        # Not under root? Fall back to all parts except drive/share and 'scan'
        parts = [p for p in parent.parts if p not in (".", "")]
    base = "_".join(parts) if parts else "scan"
    return base


def build_unique_name_reserver(dest_root: Path):
    """
    Thread-safe name reserver so two workers don't pick the same _dupN.
    """
    lock = threading.Lock()
    reserved = set()
    # Preload existing filenames (avoid clobbering)
    for f in dest_root.iterdir():
        if f.is_file():
            reserved.add(f.name)

    def reserve(desired: str) -> str:
        base, ext = os.path.splitext(desired)
        with lock:
            if desired not in reserved:
                reserved.add(desired)
                return desired
            n = 1
            while True:
                candidate = f"{base}_dup{n}{ext}"
                if candidate not in reserved:
                    reserved.add(candidate)
                    return candidate
                n += 1

    return reserve


def copy_one(src: Path, dest_root: Path, final_name: str, dry_run: bool, log_lock: threading.Lock):
    """
    Actually perform the copy (or dry-run log). final_name is already reserved/unique.
    """
    dst = dest_root / final_name
    if dry_run:
        with log_lock:
            print(f"  [DRY] {src}  ->  {dst}")
        return "DRY"
    try:
        shutil.copy2(src, dst)
        with log_lock:
            print(f"  [OK ] {src.name} -> {dst.name}")
        return "OK"
    except Exception as e:
        with log_lock:
            print(f"  [ERR] {src} -> {dst} :: {e}")
        return "ERR"


def main():
    parser = argparse.ArgumentParser(
        description="Pick key TIFF frames from 'scan' folders, rename per ROOT-relative path, and copy to Desktop/david."
    )
    parser.add_argument("root", help=r"Root folder to search (e.g. \\zfstor6\dingo\proposal)")
    parser.add_argument("--dest", default=str(Path.home() / "Desktop" / "david"),
                        help="Destination folder (default: ~/Desktop/david)")
    parser.add_argument("--dry-run", action="store_true", help="Print actions only; do not copy.")
    parser.add_argument("--workers", type=int, default=2,
                        help="Number of parallel copy workers (use 1 to debug; default 2).")
    parser.add_argument("--verbose", action="store_true", help="Print extra debug info.")
    args = parser.parse_args()

    root = Path(args.root)
    dest_root = ensure_dest_folder(Path(args.dest))
    if not root.exists():
        print(f"[ERROR] Root path does not exist: {root}")
        return

    # Allow workers=1 for debug clarity
    workers = max(1, args.workers or 1)

    log_lock = threading.Lock()
    reserve_unique = build_unique_name_reserver(dest_root)

    # Scan and collect jobs
    jobs = []  # tuples of (src_path, final_name)
    total_scan_dirs = 0
    total_candidates = 0

    for scan_dir in find_scan_dirs(root):
        total_scan_dirs += 1
        files = list_tiffs(scan_dir)
        if len(files) <= 100:
            print(f"[SKIP] {scan_dir} has {len(files)} TIFFs (need >100).")
            continue

        files.sort(key=numeric_key)
        n = len(files)
        idxs = pick_indices(n)
        base = rel_base_name(root, scan_dir)

        print(f"\n[INFO] Processing 'scan' folder: {scan_dir}")
        print(f"       TIFF count: {n}")
        print(f"       Selected indices: {idxs}")
        print(f"       New filename base: {base}")

        # Show a preview of the names that will be created (before reserving dup suffix)
        if args.verbose:
            preview = [f"{base}{i}{files[idx].suffix.lower()}" for i, idx in enumerate(idxs)]
            print("       Preview new names (before _dupN reservation):")
            for name in preview:
                print(f"         - {name}")

        for order, idx in enumerate(idxs):
            src = files[idx]
            desired = f"{base}{order}{src.suffix.lower()}"
            final_name = reserve_unique(desired)
            jobs.append((src, final_name))
            total_candidates += 1

    if not jobs:
        print("\n[INFO] No files to copy (no qualifying 'scan' folders or files).")
        print(f"      Searched scan folders: {total_scan_dirs}, destination: {dest_root}")
        print("      Tip: ensure there are >100 TIFFs directly under each 'scan' folder.")
        return

    mode = "DRY RUN" if args.dry_run else "COPY MODE"
    print(f"\n[INFO] Starting {mode} with {workers} worker(s). "
          f"Planned files: {total_candidates}")
    # Copy (possibly threaded)
    copied_ok = 0
    if workers == 1:
        # Sequential (debug-friendly)
        for src, final_name in jobs:
            status = copy_one(src, dest_root, final_name, args.dry_run, log_lock)
            if status == "OK":
                copied_ok += 1
    else:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futures = [ex.submit(copy_one, src, dest_root, final_name, args.dry_run, log_lock)
                       for (src, final_name) in jobs]
            for f in as_completed(futures):
                status = f.result()
                if status == "OK":
                    copied_ok += 1

    print(f"\n[DONE] {'Planned' if args.dry_run else 'Copied'}: "
          f"{total_candidates if args.dry_run else copied_ok} / {total_candidates}")
    print(f"       Destination: {dest_root}")


if __name__ == "__main__":
    main()
