
import torch
import torch.nn as nn
import torch.nn.functional as F

class ConvBlock3D(nn.Module):
    def __init__(self, in_ch, out_ch, k=3, s=1, p=1, groups=8):
        super().__init__()
        self.pad = nn.ReflectionPad3d(p)
        self.conv = nn.Conv3d(in_ch, out_ch, k, s, padding=0)
        self.gn = nn.GroupNorm(num_groups=min(groups, out_ch), num_channels=out_ch)
        self.act = nn.SiLU(inplace=True)
    def forward(self, x):
        x = self.pad(x); x = self.conv(x); x = self.gn(x); return self.act(x)

class ResBlock3D(nn.Module):
    def __init__(self, ch):
        super().__init__()
        self.c1 = ConvBlock3D(ch, ch)
        self.c2 = ConvBlock3D(ch, ch)
    def forward(self, x): return x + self.c2(self.c1(x))

class Down3D(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.pool = nn.AvgPool3d(2)
        self.conv = ConvBlock3D(in_ch, out_ch)
        self.res = ResBlock3D(out_ch)
    def forward(self, x):
        x = self.pool(x); x = self.conv(x); return self.res(x)

class Up3D(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.up = nn.Upsample(scale_factor=2, mode='trilinear', align_corners=False)
        self.conv = ConvBlock3D(in_ch, out_ch)
        self.res = ResBlock3D(out_ch)
    def forward(self, x, skip):
        x = self.up(x)
        dz = skip.size(-3) - x.size(-3)
        dy = skip.size(-2) - x.size(-2)
        dx = skip.size(-1) - x.size(-1)
        if dz or dy or dx: x = F.pad(x, (0, dx, 0, dy, 0, dz))
        x = torch.cat([skip, x], dim=1); x = self.conv(x); return self.res(x)

class ResUNet3DHet(nn.Module):
    def __init__(self, in_ch=1, base=32, depth=4):
        super().__init__()
        self.inc = ConvBlock3D(in_ch, base)
        self.downs = nn.ModuleList()
        ch = base
        for d in range(depth):
            self.downs.append(Down3D(ch, ch*2)); ch *= 2
        self.bottleneck = ResBlock3D(ch)
        self.ups = nn.ModuleList()
        for d in range(depth):
            self.ups.append(Up3D(ch, ch//2)); ch //= 2
        self.outc = nn.Conv3d(ch, 2, 1) # mu, logvar
    def forward(self, x):
        x1 = self.inc(x); skips = [x1]; x_ = x1
        for down in self.downs: x_ = down(x_); skips.append(x_)
        x_ = self.bottleneck(x_)
        for i, up in enumerate(self.ups[::-1]): x_ = up(x_, skips[-(i+2)])
        out = self.outc(x_)
        mu, logvar = out[:, :1], out[:, 1:2]
        return mu, logvar
