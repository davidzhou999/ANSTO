
import os, argparse, numpy as np, tifffile as tiff, torch
from models.resunet_het import ResUNetHet
from utils.vst import anscombe_forward, anscombe_inverse

@torch.no_grad()
def tile_infer(img, model, tile=768, overlap=64, alpha=1.0, sigma=0.0, amp=True, device='cuda'):
    H, W = img.shape
    step = tile - overlap
    out_mu = np.zeros_like(img, dtype=np.float32)
    out_s  = np.zeros_like(img, dtype=np.float32)
    wsum   = np.zeros_like(img, dtype=np.float32)
    wy = np.hanning(tile).astype(np.float32); wx = np.hanning(tile).astype(np.float32)
    win = np.outer(wy, wx)
    for y in range(0, H, step):
        for x in range(0, W, step):
            ys = min(y+tile, H); xs = min(x+tile, W)
            y0 = ys - tile; x0 = xs - tile
            if y0 < 0: y0 = 0
            if x0 < 0: x0 = 0
            patch = img[y0:ys, x0:xs]
            ph, pw = patch.shape
            pad = ((0, tile-ph), (0, tile-pw))
            patch = np.pad(patch, pad, mode='edge')
            ten = torch.from_numpy(patch).unsqueeze(0).unsqueeze(0).to(device)
            ten = anscombe_forward(ten, alpha=alpha, sigma=sigma)
            with torch.cuda.amp.autocast(enabled=amp):
                mu, logv = model(ten)
            mu = anscombe_inverse(mu, alpha=alpha, sigma=sigma).squeeze().float().cpu().numpy()
            s  = (logv.exp().sqrt()).squeeze().float().cpu().numpy()
            mu = mu[:ph,:pw]; s = s[:ph,:pw]; w = win[:ph,:pw]
            out_mu[y0:y0+ph, x0:x0+pw] += mu*w
            out_s [y0:y0+ph, x0:x0+pw] += s*w
            wsum  [y0:y0+ph, x0:x0+pw] += w
    out_mu /= (wsum + 1e-8); out_s /= (wsum + 1e-8)
    return out_mu, out_s

def main(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    ckpt = torch.load(args.checkpoint, map_location=device)
    model = ResUNetHet(in_ch=1, base=args.base, depth=args.depth, blind_spot=True).to(device)
    model.load_state_dict(ckpt['model'], strict=True)
    if 'ema' in ckpt and isinstance(ckpt['ema'], dict):
        for n, p in model.named_parameters():
            if n in ckpt['ema']: p.data.copy_(ckpt['ema'][n])
    model.eval()

    os.makedirs(args.output_dir, exist_ok=True)
    files = [os.path.join(args.input_dir, f) for f in os.listdir(args.input_dir) if f.lower().endswith(('.tif','.tiff'))]
    files = sorted(files); print(f"Found {len(files)} files")
    for fp in files:
        img16 = tiff.imread(fp)
        if img16.ndim == 3: img16 = img16[...,0]
        pmin = np.percentile(img16, 0.5); pmax = np.percentile(img16, 99.5)
        scale = (pmin, pmax)
        imgf = (img16.astype(np.float32) - pmin) / (pmax - pmin + 1e-8); imgf = np.clip(imgf, 0.0, 1.0)
        mu, s = tile_infer(imgf, model, tile=args.tile, overlap=args.overlap, alpha=args.alpha, sigma=args.sigma, amp=args.amp, device=device)
        mu16 = np.clip(mu * (scale[1] - scale[0]) + scale[0], 0, 65535).astype(np.uint16)
        s16  = np.clip(s / (s.max()+1e-8) * 65535, 0, 65535).astype(np.uint16)
        base = os.path.splitext(os.path.basename(fp))[0]
        tiff.imwrite(os.path.join(args.output_dir, base + "_den.tif"), mu16)
        tiff.imwrite(os.path.join(args.output_dir, base + "_sigma.tif"), s16)
        print("Saved", base)

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--checkpoint', type=str, required=True)
    ap.add_argument('--input_dir', type=str, required=True)
    ap.add_argument('--output_dir', type=str, required=True)
    ap.add_argument('--tile', type=int, default=768)
    ap.add_argument('--overlap', type=int, default=64)
    ap.add_argument('--alpha', type=float, default=1.0)
    ap.add_argument('--sigma', type=float, default=0.0)
    ap.add_argument('--amp', action='store_true')
    ap.add_argument('--base', type=int, default=64)
    ap.add_argument('--depth', type=int, default=4)
    args = ap.parse_args(); main(args)
