
import os, re, argparse, numpy as np, tifffile as tiff

def load_stack(folder, use_log_suffix=True):
    files = sorted([f for f in os.listdir(folder) if f.lower().endswith(('.tif','.tiff'))])
    if use_log_suffix:
        files = [f for f in files if f.lower().endswith('_log.tif') or f.lower().endswith('_log.tiff')]
        if len(files)==0:
            raise FileNotFoundError("No *_log.tif[f] files found in input_dir.")
    paths = [os.path.join(folder, f) for f in files]
    arr = [tiff.imread(p).astype(np.float32) / 1000.0 for p in paths]
    V = np.stack(arr, axis=0)  # [angles, H, W]
    return V, files

def parse_angles_from_filenames(files, angle_regex, scale=1.0, offset=0.0):
    rx = re.compile(angle_regex)
    ang = []
    for fn in files:
        m = rx.search(fn)
        if not m:
            raise ValueError(f"Angle regex '{angle_regex}' did not match filename: {fn}")
        a = float(m.group(1)) * scale + offset
        ang.append(a)
    return np.deg2rad(np.array(ang, dtype=np.float32))

def reconstruct(args):
    import tomopy
    data, names = load_stack(args.input_dir, use_log_suffix=not args.use_raw)
    if args.use_raw:
        eps = 1e-6
        data = -np.log(np.clip(data, eps, 10.0))

    N, H, W = data.shape
    if args.theta_mode == 'linspace':
        theta = np.linspace(np.deg2rad(args.theta_start_deg), np.deg2rad(args.theta_end_deg), N, endpoint=(not args.exclude_endpoint))
    elif args.theta_mode == 'file':
        with open(args.angles_file, 'r') as f:
            arr = [float(x.strip()) for x in f if x.strip()!='']
        assert len(arr) == N, "angles file length must equal number of projections"
        theta = np.deg2rad(np.array(arr, dtype=np.float32))
    elif args.theta_mode == 'filename':
        theta = parse_angles_from_filenames(names, args.angle_regex, args.angle_scale, args.angle_offset)
    else:
        raise ValueError("theta_mode must be linspace/file/filename")

    if args.remove_stripe:
        data = tomopy.remove_stripe_fw(data, level=7, wname='sym16', sigma=1, pad=True)

    if args.center == 'auto':
        cen = tomopy.find_center(data, theta, init=(W/2), tol=0.5, ind=int(N*0.5))
        print(f"[auto] center = {cen:.3f}")
    else:
        cen = float(args.center)

    if args.algorithm.lower() == 'gridrec':
        rec = tomopy.recon(data, theta, center=cen, algorithm='gridrec', filter_name=args.filter)
    elif args.algorithm.lower() == 'fbp':
        rec = tomopy.recon(data, theta, center=cen, algorithm='fbp', filter_name=args.filter)
    elif args.algorithm.lower() in ('sirt','sirtfbp','sart'):
        options = {'proj_type':'cuda'} if args.gpu else {}
        rec = tomopy.recon(data, theta, center=cen, algorithm=args.algorithm.lower(), num_iter=args.num_iter, options=options)
    else:
        raise ValueError("Unsupported algorithm. Choose gridrec/fbp/sirt/sart/sirtfbp")

    rec = np.nan_to_num(rec, nan=0.0, posinf=0.0, neginf=0.0)
    os.makedirs(args.output_dir, exist_ok=True)
    if args.output_nii:
        import nibabel as nib
        nib.save(nib.Nifti1Image(rec.astype(np.float32), affine=np.eye(4)), os.path.join(args.output_dir, 'recon.nii.gz'))
    if args.output_tiff:
        os.makedirs(os.path.join(args.output_dir, 'tiff_stack'), exist_ok=True)
        for i in range(rec.shape[0]):
            sl = rec[i]; sl = (sl - sl.min()) / (sl.max() - sl.min() + 1e-8)
            tiff.imwrite(os.path.join(args.output_dir, 'tiff_stack', f'slice_{i:04d}.tif'),
                         (sl*65535).astype(np.uint16))
    print("Reconstruction saved to", args.output_dir)

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--input_dir', type=str, required=True)
    ap.add_argument('--output_dir', type=str, required=True)
    ap.add_argument('--theta_mode', choices=['linspace','file','filename'], default='linspace')
    ap.add_argument('--theta_start_deg', type=float, default=0.0)
    ap.add_argument('--theta_end_deg', type=float, default=180.0)
    ap.add_argument('--exclude_endpoint', action='store_true')
    ap.add_argument('--angles_file', type=str)
    ap.add_argument('--angle_regex', type=str, default=r'(\\d+(?:\\.\\d+)?)', help='first capture group = degrees in filename')
    ap.add_argument('--angle_scale', type=float, default=1.0, help='multiply parsed values')
    ap.add_argument('--angle_offset', type=float, default=0.0, help='add degrees after scaling')
    ap.add_argument('--center', type=str, default='auto')
    ap.add_argument('--algorithm', type=str, default='gridrec')
    ap.add_argument('--filter', type=str, default='hann')
    ap.add_argument('--num_iter', type=int, default=64)
    ap.add_argument('--gpu', action='store_true')
    ap.add_argument('--remove_stripe', action='store_true')
    ap.add_argument('--use_raw', action='store_true')
    ap.add_argument('--output_nii', action='store_true', default=True)
    ap.add_argument('--output_tiff', action='store_true')
    args = ap.parse_args(); reconstruct(args)
