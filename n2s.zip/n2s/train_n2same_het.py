
import os, argparse, time, torch
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from models.resunet_het import ResUNetHet
from utils.dataio import TiffLazyDataset
from utils.vst import anscombe_forward
from utils.metrics_ext import CharbonnierLoss, HeteroscedasticNLL, gsure_vst, cnr_auto, ring_index

def ring_aware_loss(residual):
    # residual: [B,1,H,W]; encourage zero column-wise bias in context -> penalize mean across rows
    col_mean = residual.mean(dim=-2, keepdim=True)
    return (col_mean**2).mean()

from utils.ema import EMA

def random_mask(b, h, w, ratio=0.07, device='cpu'):
    m = torch.zeros((b,1,h,w), device=device)
    num = int(h*w*ratio)
    idx = torch.randint(0, h*w, (b, num), device=device)
    m = m.view(b,1,-1); m.scatter_(2, idx.unsqueeze(1), 1.0)
    return m.view(b,1,h,w)

@torch.no_grad()
def destripe_columnwise(x, strength=0.0):
    if strength <= 0: return x
    xlog = torch.log1p(torch.clamp(x, 0, 1)*1000.0)
    mean_col = xlog.mean(dim=-2, keepdim=True)
    hp = xlog - mean_col
    y = torch.expm1(hp) / 1000.0
    y = torch.clamp(y, 0.0, 1.0)
    return (1-strength)*x + strength*y

def train(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    writer = SummaryWriter(args.log_dir)
    train_ds = TiffLazyDataset(args.train_dir, patch_size=args.patch, repeat=args.iters_per_epoch)
    val_ds   = TiffLazyDataset(args.val_dir,   patch_size=args.patch, repeat=max(256, args.batch*8))
    train_loader = DataLoader(train_ds, batch_size=args.batch, shuffle=False, num_workers=args.workers, pin_memory=True, drop_last=True)
    val_loader   = DataLoader(val_ds,   batch_size=args.batch, shuffle=False, num_workers=args.workers, pin_memory=True, drop_last=True)
    net = ResUNetHet(in_ch=1, base=args.base, depth=args.depth, blind_spot=True).to(device)
    opt = torch.optim.AdamW(net.parameters(), lr=args.lr, weight_decay=args.wd)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.epochs)
    scaler = torch.cuda.amp.GradScaler(enabled=args.amp)
    ema = EMA(net, decay=args.ema)
    nll = HeteroscedasticNLL(); stab = CharbonnierLoss(epsilon=args.eps)
    best_val = 1e9; global_step = 0
    for epoch in range(1, args.epochs+1):
        net.train(); t0 = time.time()
        for it, batch in enumerate(train_loader):
            batch = batch.to(device)
            batch = destripe_columnwise(batch, args.destripe)
            x = anscombe_forward(batch, alpha=args.alpha, sigma=args.sigma)
            B,_,H,W = x.shape
            M1 = random_mask(B,H,W, ratio=args.mask_ratio, device=device)
            M2 = random_mask(B,H,W, ratio=args.mask_ratio, device=device)
            with torch.cuda.amp.autocast(enabled=args.amp):
                mu1, logv1 = net(x * (1.0 - M1))
                mu2, logv2 = net(x * (1.0 - M2))
                loss = 0.5*nll(mu1, logv1, x, mask=M1) + 0.5*nll(mu2, logv2, x, mask=M2)
                # ring-aware: penalize column bias in context residuals
                res1 = (mu1 - x) * (1.0 - M1)
                res2 = (mu2 - x) * (1.0 - M2)
                loss = loss + args.stab_w * (0.5*stab(mu1, x, mask=M1) + 0.5*stab(mu2, x, mask=M2)) + args.ring_w * (0.5*ring_aware_loss(res1) + 0.5*ring_aware_loss(res2))
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward(); scaler.step(opt); scaler.update(); ema.update(net)
            writer.add_scalar('train/loss_total', loss.item(), global_step); global_step += 1
        net.eval(); ema.apply_shadow(net)
        with torch.no_grad():
            vloss = 0.0
            for vb, batch in enumerate(val_loader):
                batch = batch.to(device)
                batch = destripe_columnwise(batch, args.destripe)
                x = anscombe_forward(batch, alpha=args.alpha, sigma=args.sigma)
                B,_,H,W = x.shape
                M = random_mask(B,H,W, ratio=args.mask_ratio, device=device)
                mu, logv = net(x * (1.0 - M))
                l = nll(mu, logv, x, mask=M)
                vloss += l.item()
            vloss /= max(1, vb+1)
            writer.add_scalar('val/loss_masked_nll', vloss, epoch)
            vb0 = next(iter(val_loader)).to(device)
            vb0 = destripe_columnwise(vb0, args.destripe)
            x0 = anscombe_forward(vb0, alpha=args.alpha, sigma=args.sigma)
            class _Wrap(torch.nn.Module):
                def __init__(self, net): super().__init__(); self.net = net
                def forward(self, inp): mu, _ = self.net(inp); return mu
            g = gsure_vst(_Wrap(net), x0, sigma2=1.0, amp=args.amp); writer.add_scalar('val/gsure_vst', g.item(), epoch)
            mu0, _ = net(x0)
            cnr, thr = cnr_auto(mu0[0,0].detach().cpu()); writer.add_scalar('val/cnr_auto', cnr, epoch)
            ri = ring_index(mu0[0,0].detach().cpu()); writer.add_scalar('val/ring_index', ri, epoch)
            if vloss < best_val:
                best_val = vloss; os.makedirs(os.path.dirname(args.save_path), exist_ok=True)
                torch.save({'model': net.state_dict(), 'ema': ema.shadow, 'args': vars(args)}, args.save_path)
        ema.restore(net); sched.step()
        print(f"Epoch {epoch:03d} | time {(time.time()-t0):.1f}s | val_nll {vloss:.6f} | best {best_val:.6f}")
    writer.close()

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--train_dir', type=str, required=True)
    ap.add_argument('--val_dir',   type=str, required=True)
    ap.add_argument('--save_path', type=str, default='data/n2same_het_best.pt')
    ap.add_argument('--log_dir',   type=str, default='logs')
    ap.add_argument('--patch', type=int, default=384)
    ap.add_argument('--batch', type=int, default=4)
    ap.add_argument('--workers', type=int, default=4)
    ap.add_argument('--iters_per_epoch', type=int, default=2000)
    ap.add_argument('--epochs', type=int, default=150)
    ap.add_argument('--base', type=int, default=64)
    ap.add_argument('--depth', type=int, default=4)
    ap.add_argument('--lr', type=float, default=1e-3)
    ap.add_argument('--wd', type=float, default=1e-4)
    ap.add_argument('--amp', action='store_true')
    ap.add_argument('--ema', type=float, default=0.999)
    ap.add_argument('--mask_ratio', type=float, default=0.07)
    ap.add_argument('--alpha', type=float, default=1.0)
    ap.add_argument('--sigma', type=float, default=0.0)
    ap.add_argument('--destripe', type=float, default=0.0)
    ap.add_argument('--eps', type=float, default=1e-3)
    ap.add_argument('--stab_w', type=float, default=0.05)
    ap.add_argument('--ring_w', type=float, default=0.01, help='ring-aware residual regularizer weight')
    args = ap.parse_args(); train(args)
