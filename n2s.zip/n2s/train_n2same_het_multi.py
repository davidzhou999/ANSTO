
import os, glob, argparse, random, torch, numpy as np, tifffile as tiff
from torch.utils.data import Dataset, DataLoader
from torch.utils.tensorboard import SummaryWriter
from models.resunet_het import ResUNetHet
from utils.ema import EMA
from utils.metrics_ext import HeteroscedasticNLL, CharbonnierLoss


def ring_aware_loss(residual):
    # residual: [B,1,H,W]; encourage zero column-wise bias in context -> penalize mean across rows
    col_mean = residual.mean(dim=-2, keepdim=True)
    return (col_mean**2).mean()


class MultiRootDataset(Dataset):
    def __init__(self, roots, patch=384, repeat=5000*4):
        self.files = []
        for r in roots:
            self.files += sorted(glob.glob(os.path.join(r, '*.tif'))) + sorted(glob.glob(os.path.join(r, '*.tiff')))
        if len(self.files)==0: raise FileNotFoundError("No TIFFs in given roots")
        self.patch = patch; self.repeat = repeat
    def __len__(self): return self.repeat
    def __getitem__(self, idx):
        fp = random.choice(self.files)
        img = tiff.imread(fp)
        if img.ndim==3: img = img[...,0]
        img = img.astype(np.float32)
        pmin = np.percentile(img, 0.5); pmax = np.percentile(img, 99.5)
        img = np.clip((img - pmin) / (pmax - pmin + 1e-8), 0.0, 1.0)
        H, W = img.shape; ps = self.patch
        y = np.random.randint(0, H-ps+1); x = np.random.randint(0, W-ps+1)
        patch = img[y:y+ps, x:x+ps]
        if np.random.rand()<0.5: patch = patch[:, ::-1]
        if np.random.rand()<0.5: patch = patch[::-1, :]
        if np.random.rand()<0.5: patch = np.rot90(patch, k=np.random.choice([1,2,3]))

        # 🔧 add one of these lines:
        patch = np.ascontiguousarray(patch, dtype=np.float32)
        # or: patch = patch.copy().astype(np.float32)

        return torch.from_numpy(patch).unsqueeze(0)

def random_mask(b, h, w, ratio, device):
    m = torch.zeros((b,1,h,w), device=device)
    num = int(h*w*ratio); idx = torch.randint(0, h*w, (b, num), device=device)
    m = m.view(b,1,-1); m.scatter_(2, idx.unsqueeze(1), 1.0)
    return m.view(b,1,h,w)

def main(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    ds = MultiRootDataset(args.roots, patch=args.patch, repeat=args.iters_per_epoch)
    dl = DataLoader(ds, batch_size=args.batch, shuffle=False, num_workers=args.workers, pin_memory=True, drop_last=True)
    # net = ResUNetHet(in_ch=1, base=args.base, depth=args.depth, blind_spot=True).to(device)
    net = ResUNetHet(in_ch=1, base=args.base, depth=args.depth, blind_spot=False).to(device)

    opt = torch.optim.AdamW(net.parameters(), lr=args.lr, weight_decay=args.wd)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.epochs)
    # scaler = torch.cuda.amp.GradScaler(enabled=args.amp)
    scaler = torch.amp.GradScaler('cuda', enabled=args.amp)

    ema = EMA(net, decay=args.ema)
    nll = HeteroscedasticNLL(); stab = CharbonnierLoss(epsilon=args.eps)
    writer = SummaryWriter(args.log_dir); global_step = 0
    for epoch in range(1, args.epochs+1):
        net.train()
        for it, batch in enumerate(dl):
            batch = batch.to(device)
            B,_,H,W = batch.shape
            M1 = random_mask(B,H,W,args.mask_ratio,device); M2 = random_mask(B,H,W,args.mask_ratio,device)
            with torch.cuda.amp.autocast(enabled=args.amp):
                mu1, logv1 = net(batch * (1.0 - M1))
                mu2, logv2 = net(batch * (1.0 - M2))
                loss = 0.5*nll(mu1, logv1, batch, mask=M1) + 0.5*nll(mu2, logv2, batch, mask=M2)
                res1 = (mu1 - batch) * (1.0 - M1)
                res2 = (mu2 - batch) * (1.0 - M2)
                loss = loss + args.stab_w * (0.5*stab(mu1, batch, mask=M1) + 0.5*stab(mu2, batch, mask=M2)) + args.ring_w * (0.5*ring_aware_loss(res1) + 0.5*ring_aware_loss(res2))
            opt.zero_grad(set_to_none=True); scaler.scale(loss).backward(); scaler.step(opt); scaler.update(); ema.update(net)
            writer.add_scalar('train/loss', loss.item(), global_step); global_step += 1
        sched.step()
        os.makedirs(os.path.dirname(args.save_path), exist_ok=True)
        torch.save({'model': net.state_dict(), 'ema': ema.shadow, 'args': vars(args)}, args.save_path)
        print(f"Epoch {epoch:03d} saved {args.save_path}")
    writer.close()

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--roots', nargs='+', required=True, help='one or more folders with mixed 8/16-bit TIFFs')
    ap.add_argument('--save_path', type=str, default='data/n2same_het_pretrained.pt')
    ap.add_argument('--log_dir', type=str, default='logs_pretrain')
    ap.add_argument('--patch', type=int, default=384)
    ap.add_argument('--batch', type=int, default=8)
    ap.add_argument('--workers', type=int, default=4)
    ap.add_argument('--iters_per_epoch', type=int, default=5000)
    ap.add_argument('--epochs', type=int, default=50)
    ap.add_argument('--base', type=int, default=64)
    ap.add_argument('--depth', type=int, default=4)
    ap.add_argument('--lr', type=float, default=1e-3)
    ap.add_argument('--wd', type=float, default=1e-4)
    ap.add_argument('--amp', action='store_true')
    ap.add_argument('--ema', type=float, default=0.999)
    ap.add_argument('--mask_ratio', type=float, default=0.07)
    ap.add_argument('--eps', type=float, default=1e-3)
    ap.add_argument('--stab_w', type=float, default=0.05)
    ap.add_argument('--ring_w', type=float, default=0.01)
    args = ap.parse_args(); main(args)
