#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os, math, time, argparse, random
from dataclasses import dataclass
from typing import Tuple, List

import numpy as np
import tifffile as tiff
from tqdm import tqdm

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

import math

# ---- Model import (your repo) ----
try:
    from models.resunet_het import ResUNetHetero
except Exception:
    from models.resunet_het import ResUNetHet as ResUNetHetero

torch.backends.cudnn.benchmark = True
torch.set_float32_matmul_precision('high')
DEFAULT_SEED = 1337


# ====================== Dataset ======================

class PatchDataset(Dataset):
    """
    Streams random patches from TIFFs. Optional 2.5D triplet input:
    x_in: [3,H,W] = [prev, center, next], y_tgt: [1,H,W] = center.
    Otherwise x_in==y_tgt==[1,H,W].
    """

    def __init__(self, roots: List[str], patch=384, iters_per_epoch=2000,
                 eval_mode=False, triplet_in=False):
        paths = []
        for r in roots:
            if os.path.isdir(r):
                for f in os.listdir(r):
                    if f.lower().endswith(('.tif', '.tiff')):
                        paths.append(os.path.join(r, f))
            elif r.lower().endswith(('.tif', '.tiff')):
                paths.append(r)
        if not paths:
            raise FileNotFoundError(f"No TIFFs under: {roots}")
        self.paths = sorted(paths)
        self.patch = int(patch)
        self.iters = int(iters_per_epoch)
        self.eval_mode = eval_mode
        self.triplet = bool(triplet_in)

    def __len__(self):
        return self.iters if not self.eval_mode else min(len(self.paths), self.iters)

    def _read(self, idx):
        fp = self.paths[idx]
        arr = tiff.imread(fp).astype(np.float32)
        if arr.ndim != 2:
            raise ValueError(f"Expected 2D grayscale TIFF, got {arr.shape} for {fp}")
        return arr

    def _random_index(self):
        return np.random.randint(0, len(self.paths))

    def _center_index(self, i):
        return max(0, min(i, len(self.paths) - 1))

    def _crop(self, arr):
        H, W = arr.shape
        P = self.patch
        if H < P or W < P:
            pad_y = max(0, P - H);
            pad_x = max(0, P - W)
            arr = np.pad(arr, ((0, pad_y), (0, pad_x)), mode='reflect')
            H, W = arr.shape
        y0 = np.random.randint(0, H - P + 1)
        x0 = np.random.randint(0, W - P + 1)
        return arr[y0:y0 + P, x0:x0 + P]

    def _center_crop(self, arr):
        H, W = arr.shape;
        P = self.patch
        y0 = max((H - P) // 2, 0);
        x0 = max((W - P) // 2, 0)
        return arr[y0:y0 + P, x0:x0 + P]

    @staticmethod
    def _pctl01(x: np.ndarray, lo=0.5, hi=99.5) -> Tuple[float, float]:
        p = np.percentile(x, [lo, hi])
        p0, p1 = float(p[0]), float(p[1])
        if not np.isfinite(p0) or not np.isfinite(p1) or p1 <= p0:
            p0, p1 = float(x.min()), float(max(x.max(), x.min() + 1.0))
        return p0, p1

    def __getitem__(self, idx):
        if self.eval_mode:
            i = idx % len(self.paths)
            center = self._read(i)
            patcher = self._center_crop
            if self.triplet:
                prev = self._read(self._center_index(i - 1))
                nxt = self._read(self._center_index(i + 1))
                # normalize all three by center’s percentile for consistency
                p0, p1 = self._pctl01(center)
                prev = np.clip((prev - p0) / (p1 - p0 + 1e-6), 0, 1)
                cent = np.clip((center - p0) / (p1 - p0 + 1e-6), 0, 1)
                nxt = np.clip((nxt - p0) / (p1 - p0 + 1e-6), 0, 1)
                prev = patcher(prev);
                cent = patcher(cent);
                nxt = patcher(nxt)
                x_in = np.stack([prev, cent, nxt], 0).astype(np.float32)
                y_tg = cent[None, ...].astype(np.float32)
            else:
                p0, p1 = self._pctl01(center)
                cent = np.clip((center - p0) / (p1 - p0 + 1e-6), 0, 1)
                cent = patcher(cent)
                x_in = cent[None, ...].astype(np.float32)
                y_tg = x_in.copy()
        else:
            i = self._random_index()
            center = self._read(i)
            patcher = self._crop
            if self.triplet:
                prev = self._read(self._center_index(i - 1))
                nxt = self._read(self._center_index(i + 1))
                p0, p1 = self._pctl01(center)
                prev = np.clip((prev - p0) / (p1 - p0 + 1e-6), 0, 1)
                cent = np.clip((center - p0) / (p1 - p0 + 1e-6), 0, 1)
                nxt = np.clip((nxt - p0) / (p1 - p0 + 1e-6), 0, 1)
                prev = patcher(prev);
                cent = patcher(cent);
                nxt = patcher(nxt)
                x_in = np.stack([prev, cent, nxt], 0).astype(np.float32)
                y_tg = cent[None, ...].astype(np.float32)
            else:
                p0, p1 = self._pctl01(center)
                cent = np.clip((center - p0) / (p1 - p0 + 1e-6), 0, 1)
                cent = patcher(cent)
                x_in = cent[None, ...].astype(np.float32)
                y_tg = x_in.copy()

        return torch.from_numpy(x_in), torch.from_numpy(y_tg)


# ====================== Speckle mask ======================

@torch.no_grad()
def make_symmetric_speckle_mask(x01,
                                hi_pctl=99.95, lo_pctl=0.05,
                                z_tau_hi=6.0, z_tau_lo=6.0,
                                dilate_ks=3):
    """
    x01: [B,1,H,W] in [0,1]
    Returns uint8 mask [B,1,H,W] for bright/dark spikes, dilated by dilate_ks.
    """
    B, C, H, W = x01.shape
    flat = x01.reshape(B, -1)
    q_hi = torch.quantile(flat, hi_pctl / 100.0, dim=1).view(B, 1, 1, 1)
    q_lo = torch.quantile(flat, lo_pctl / 100.0, dim=1).view(B, 1, 1, 1)
    m_hi = (x01 > q_hi);
    m_lo = (x01 < q_lo)

    mean = flat.mean(dim=1, keepdim=True);
    std = flat.std(dim=1, unbiased=False, keepdim=True) + 1e-6
    z = ((flat - mean) / std).view(B, 1, H, W)
    m_zh = z > z_tau_hi
    m_zl = z < -z_tau_lo
    m = (m_hi | m_lo | m_zh | m_zl).to(torch.uint8)

    # morphological dilation (max filter) via depthwise conv with ones kernel
    if dilate_ks > 1:
        pad = dilate_ks // 2
        k = torch.ones((1, 1, dilate_ks, dilate_ks), device=x01.device, dtype=torch.float32)
        m = (torch.nn.functional.conv2d(m.float(), k, padding=pad) > 0).to(torch.uint8)
    return m


# ====================== Ring loss ======================

def _gauss1d(sigma: int, device):
    if sigma <= 0:
        w = torch.tensor([1.0], device=device, dtype=torch.float32)
        return w / w.sum()
    k = int(max(3, 3 * sigma))
    xs = torch.arange(-k, k + 1, device=device, dtype=torch.float32)
    w = torch.exp(-(xs ** 2) / (2.0 * sigma * sigma))
    w = w / w.sum()
    return w


def ring_map_thin(img, sigma=7, axis='x'):
    """
    Thin vertical/horizontal stripe extractor via 1D Gaussian top-hat.
    img: [B,1,H,W] in [0,1]
    axis='x' => vertical rings (columns), blur along width.
    """
    B, C, H, W = img.shape
    if sigma <= 0:
        return torch.zeros_like(img)
    g = _gauss1d(sigma, img.device)
    if axis == 'x':  # blur along width
        k = g.view(1, 1, 1, -1)
        pad = (k.shape[-1] // 2, k.shape[-1] // 2, 0, 0)
    else:  # blur along height
        k = g.view(1, 1, -1, 1)
        pad = (0, 0, k.shape[-2] // 2, k.shape[-2] // 2)
    blur = F.conv2d(F.pad(img, pad, mode='reflect'), k)
    return img - blur  # top-hat residual


def ring_loss(mu01, w=0.0, sigma=7, axis='x'):
    if w <= 0.0:
        return mu01.new_zeros(())
    r = ring_map_thin(mu01, sigma=sigma, axis=axis)
    return w * r.abs().mean()


def charbonnier(x, eps=1e-3):
    return torch.sqrt(x * x + eps * eps)


# ====================== Losses / Metrics ======================

def hetero_nll(mu, logv, y):
    invv = torch.exp(-logv)
    return 0.5 * (invv * (y - mu) ** 2 + logv)


def l2_loss(mu, y):
    return 0.5 * (y - mu) ** 2


@torch.no_grad()
def psnr(x, y, eps=1e-8):
    mse = torch.mean((x - y) ** 2).clamp_min(eps)
    return 10.0 * torch.log10(1.0 / mse)


@torch.no_grad()
def ssim_simple(x, y, C1=0.01 ** 2, C2=0.03 ** 2):
    mu_x = x.mean();
    mu_y = y.mean()
    var_x = x.var(unbiased=False);
    var_y = y.var(unbiased=False)
    cov = ((x - mu_x) * (y - mu_y)).mean()
    num = (2 * mu_x * mu_y + C1) * (2 * cov + C2)
    den = (mu_x ** 2 + mu_y ** 2 + C1) * (var_x + var_y + C2)
    return (num / (den + 1e-8)).clamp(-1, 1)


# ====================== Training / Eval ======================

@dataclass
class Args:
    roots: list
    epochs: int
    iters_per_epoch: int
    eval_iters: int
    batch: int
    patch: int
    workers: int
    amp: bool
    save_path: str
    resume: str | None
    seed: int
    # speckle
    speckle_weight: float
    hi_pctl: float
    lo_pctl: float
    z_tau_hi: float
    z_tau_lo: float
    # ring
    ring_w: float
    ring_sigma: int
    ring_axis: str
    # 2.5D
    triplet_in: bool


def build_net(device, in_ch=1):
    try:
        net = ResUNetHetero(in_ch=in_ch, base=64).to(device)
    except TypeError:
        try:
            net = ResUNetHetero(in_ch=in_ch, ch=64).to(device)
        except TypeError:
            net = ResUNetHetero(in_ch).to(device)
    return net


def train_one_epoch(net, dl, opt, scaler, device, args):
    net.train()
    it = tqdm(dl, total=len(dl), leave=False, desc="Train")
    total, t0 = 0.0, time.time()
    masked_frac_ema = None

    for step, batch in enumerate(it, 1):
        x_in, y_tg = batch  # x_in: [B,C,H,W], y_tg: [B,1,H,W]
        x_in = x_in.to(device, non_blocking=True)
        y_tg = y_tg.to(device, non_blocking=True)

        with torch.amp.autocast('cuda', enabled=args.amp):
            out = net(x_in)
            if isinstance(out, (tuple, list)):
                mu, logv = out
                perpx = hetero_nll(mu, logv, y_tg)
                mu01 = mu.clamp(0, 1)
            else:
                mu = out
                perpx = l2_loss(mu, y_tg)
                mu01 = mu.clamp(0, 1)

            # speckle mask on target (center)
            m = make_symmetric_speckle_mask(
                y_tg.detach().clamp(0, 1),
                hi_pctl=args.hi_pctl,
                lo_pctl=args.lo_pctl,
                z_tau_hi=args.z_tau_hi,
                z_tau_lo=args.z_tau_lo,
                dilate_ks=args.speckle_dilate
            ).to(y_tg.dtype)

            # main per-pixel data term with down-weight on spikes
            w_keep = 1.0 - m + m * args.speckle_weight
            eff = torch.clamp(w_keep.mean(), min=1e-4)
            main_loss = (perpx * w_keep).mean() / eff

            # --- Robust prior on masked pixels: match local 3x3 median of the target ---
            # Take 3x3 patches from y_tg and compute per-pixel median as teacher
            B, _, H, W = y_tg.shape
            y_unf = F.unfold(y_tg, kernel_size=3, padding=1)  # [B, 9, HW]
            y_med = torch.quantile(y_unf, q=0.5, dim=1)  # [B, HW]
            y_med = y_med.view(B, 1, H, W)  # [B,1,H,W]

            mu_ = out[0] if isinstance(out, (tuple, list)) else out  # prediction
            mask_f = m  # [B,1,H,W]
            if args.charb_w > 0:
                # encourage prediction to match the local median on masked (speckle) pixels
                charb = charbonnier(mu_ - y_med)
                charb_loss = (charb * mask_f).sum() / (mask_f.sum() + 1e-6)
            else:
                charb_loss = mu_.new_zeros(())

            # ring loss on prediction
            rloss = ring_loss(mu01, w=args.ring_w, sigma=args.ring_sigma, axis=args.ring_axis)

            loss = main_loss + args.charb_w * charb_loss + rloss

        scaler.scale(loss).backward()
        scaler.step(opt);
        scaler.update()
        opt.zero_grad(set_to_none=True)

        total += float(loss.detach().cpu())
        masked_frac = float(m.mean().detach().cpu())
        masked_frac_ema = masked_frac if masked_frac_ema is None else 0.95 * masked_frac_ema + 0.05 * masked_frac

        it.set_postfix(loss=f"{total / step:.4f}", msk=f"{masked_frac_ema:.4f}", r=f"{float(rloss.detach().cpu()):.4f}")

    return total / max(step, 1), time.time() - t0


@torch.no_grad()
def evaluate(net, dl, device, args):
    net.eval()
    total, n, p_acc, s_acc = 0.0, 0, 0.0, 0.0
    for x_in, y_tg in dl:
        x_in = x_in.to(device, non_blocking=True)
        y_tg = y_tg.to(device, non_blocking=True)
        with torch.amp.autocast('cuda', enabled=args.amp):
            out = net(x_in)
            mu = out[0] if isinstance(out, (tuple, list)) else out
            perpx = l2_loss(mu, y_tg)
            total += float(perpx.mean().detach().cpu())
            p_acc += float(psnr(mu.clamp(0, 1), y_tg).detach().cpu())
            s_acc += float(ssim_simple(mu.clamp(0, 1), y_tg).detach().cpu())
            n += 1
    return total / max(n, 1), p_acc / max(n, 1), s_acc / max(n, 1)


def main(cli=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--roots', nargs='+', required=True)
    ap.add_argument('--epochs', type=int, default=50)
    ap.add_argument('--iters_per_epoch', type=int, default=2000)
    ap.add_argument('--eval_iters', type=int, default=50)
    ap.add_argument('--batch', type=int, default=24)
    ap.add_argument('--patch', type=int, default=384)
    ap.add_argument('--workers', type=int, default=8)
    ap.add_argument('--amp', action='store_true')
    ap.add_argument('--save_path', required=True)
    ap.add_argument('--resume', default=None)
    ap.add_argument('--seed', type=int, default=DEFAULT_SEED)
    # speckle
    ap.add_argument('--speckle_weight', type=float, default=0.0)
    ap.add_argument('--hi_pctl', type=float, default=99.98)
    ap.add_argument('--lo_pctl', type=float, default=0.02)
    ap.add_argument('--z_tau_hi', type=float, default=5.0)
    ap.add_argument('--z_tau_lo', type=float, default=5.0)
    # ring
    ap.add_argument('--ring_w', type=float, default=0.0)
    ap.add_argument('--ring_sigma', type=int, default=7)
    ap.add_argument('--ring_axis', type=str, default='x', choices=['x', 'y'])
    # 2.5D
    ap.add_argument('--triplet_in', action='store_true',
                    help='Use [prev,center,next] as 3-ch input; target is center.')

    ap.add_argument('--speckle_dilate', type=int, default=3, help='kernel size for mask dilation')
    ap.add_argument('--charb_w', type=float, default=0.2, help='weight of Charbonnier loss on masked pixels')

    ap.add_argument('--lr', type=float, default=1e-4, help='base learning rate')
    ap.add_argument('--min_lr', type=float, default=1e-6, help='final LR floor for cosine schedule')
    ap.add_argument('--sched', type=str, default='none', choices=['none', 'cosine'], help='LR scheduler type')
    ap.add_argument('--warmup_steps', type=int, default=0, help='linear warmup steps before cosine')

    args_ns = ap.parse_args(cli)

    random.seed(args_ns.seed);
    np.random.seed(args_ns.seed);
    torch.manual_seed(args_ns.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"[INFO] device: {device.type}, AMP={'on' if args_ns.amp else 'off'}")

    ds_tr = PatchDataset(args_ns.roots, patch=args_ns.patch,
                         iters_per_epoch=args_ns.iters_per_epoch,
                         eval_mode=False, triplet_in=args_ns.triplet_in)
    ds_ev = PatchDataset(args_ns.roots, patch=args_ns.patch,
                         iters_per_epoch=args_ns.eval_iters,
                         eval_mode=True, triplet_in=args_ns.triplet_in)

    dl_tr = DataLoader(ds_tr, batch_size=args_ns.batch, shuffle=True,
                       num_workers=args_ns.workers, pin_memory=True, drop_last=True)
    dl_ev = DataLoader(ds_ev, batch_size=args_ns.batch, shuffle=False,
                       num_workers=max(0, args_ns.workers // 2), pin_memory=True, drop_last=False)

    in_ch = 3 if args_ns.triplet_in else 1
    net = build_net(device, in_ch=in_ch)

    opt = torch.optim.Adam(net.parameters(), lr=args_ns.lr, betas=(0.9, 0.999))

    scaler = torch.cuda.amp.GradScaler(enabled=args_ns.amp)

    # If you use AdamW:
    # opt = torch.optim.AdamW(net.parameters(), lr=args.lr, betas=(0.9, 0.999), weight_decay=0.0)
    # opt = torch.optim.AdamW(net.parameters(), lr=2e-4, betas=(0.9, 0.99), weight_decay=1e-4)

    best_eval = float('inf')
    if args_ns.resume and os.path.isfile(args_ns.resume):
        ckpt = torch.load(args_ns.resume, map_location=device)
        state = ckpt.get('model', ckpt)
        missing, unexpected = net.load_state_dict(state, strict=False)
        if 'opt' in ckpt:
            try:
                opt.load_state_dict(ckpt['opt'])
            except Exception:
                pass
        best_eval = float(ckpt.get('best_eval', best_eval))
        print(f"[INFO] resumed from {args_ns.resume} (best_eval={best_eval})")

    os.makedirs(os.path.dirname(args_ns.save_path), exist_ok=True)
    best_path = args_ns.save_path
    last_path = os.path.splitext(best_path)[0] + ".last.pt"
    print(f"[INFO] saving to: best={os.path.basename(best_path)}, last={os.path.basename(last_path)}")

    for ep in range(1, args_ns.epochs + 1):
        tr_loss, tr_sec = train_one_epoch(net, dl_tr, opt, scaler, device, args_ns)
        ev_loss, ev_psnr, ev_ssim = evaluate(net, dl_ev, device, args_ns)

        try:
            vram = torch.cuda.max_memory_allocated() / (1024 ** 3)
            torch.cuda.reset_peak_memory_stats()
            vram_str = f"{vram:.2f}GB"
        except Exception:
            vram_str = "n/a"

        print(f"[EPOCH {ep:03d}/{args_ns.epochs}] train_loss={tr_loss:+.4f}  "
              f"eval_loss={ev_loss:+.4f}  PSNR={ev_psnr:.2f}dB  SSIM={ev_ssim:.4f}  "
              f"time={tr_sec / 60:.2f}m  vram={vram_str}")

        torch.save({'model': net.state_dict(), 'opt': opt.state_dict(),
                    'best_eval': best_eval, 'epoch': ep}, last_path)

        if ev_loss < best_eval:
            best_eval = ev_loss
            torch.save({'model': net.state_dict(),
                        'best_eval': best_eval, 'epoch': ep}, best_path)
            print(f"[BEST] {os.path.basename(best_path)} (eval_loss={best_eval:+.4f})")


if __name__ == "__main__":
    main()

