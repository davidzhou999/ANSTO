
import os, glob, random, numpy as np, torch, tifffile as tiff
from torch.utils.data import Dataset

class TiffLazyDataset(Dataset):
    def __init__(self, root_dir, patch_size=384, repeat=2000):
        self.files = sorted(glob.glob(os.path.join(root_dir, '*.tif'))) + \
                     sorted(glob.glob(os.path.join(root_dir, '*.tiff')))
        if len(self.files) == 0:
            raise FileNotFoundError(f"No TIFF files under {root_dir}")
        self.patch = patch_size; self.repeat = repeat
    def __len__(self): return self.repeat
    def __getitem__(self, idx):
        path = random.choice(self.files)
        img = tiff.imread(path)
        if img.ndim == 3: img = img[...,0]
        img = img.astype(np.float32)
        pmin = np.percentile(img, 0.5); pmax = np.percentile(img, 99.5)
        img = np.clip((img - pmin) / (pmax - pmin + 1e-8), 0.0, 1.0)
        H, W = img.shape; ps = self.patch
        y = random.randrange(0, H-ps+1); x = random.randrange(0, W-ps+1)
        patch = img[y:y+ps, x:x+ps]
        if random.random() < 0.5: patch = patch[:, ::-1]
        if random.random() < 0.5: patch = patch[::-1, :]
        if random.random() < 0.5: patch = np.rot90(patch, k=random.choice([1,2,3]))
        return torch.from_numpy(patch).unsqueeze(0)
