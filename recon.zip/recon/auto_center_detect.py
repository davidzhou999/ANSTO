#!/usr/bin/env python3
"""
auto_center_detect.py

Automatically estimate center-of-rotation (COR) from a single detector row.

- Uses only one sinogram row -> very fast, low memory.
- Optional flat/dark normalization (using OB/DI frames).
- Optional median filter and stripe removal.
- Tries a range of centers and computes a focus/sharpness score.
- Prints best center and saves CSV of (center, score) for inspection.

Usage example (for your tooth dataset):

  conda activate recon

  python auto_center_detect.py \
    --projs_dir data/scan \
    --pattern "to_tooth_*.tif" \
    --flats_dir data/scan \
    --darks_dir data/scan \
    --row 1500 \
    --downsample 2 \
    --center_start 3000 \
    --center_end 3260 \
    --center_step 2 \
    --median 3 \
    --stripe fw \
    --out_dir data/auto_center

"""

from __future__ import annotations
import argparse
from pathlib import Path
from typing import List, Tuple

import numpy as np
import tifffile as tiff

try:
    import tomopy
except Exception as e:
    raise SystemExit(
        "TomoPy is required. Install in 'recon' env:\n"
        "  conda install -c conda-forge tomopy -y\n\n"
        + str(e)
    )


def natural_key(s: str):
    out = []
    num = ""
    for ch in s:
        if ch.isdigit():
            num += ch
        else:
            if num:
                out.append(int(num))
                num = ""
            out.append(ch.lower())
    if num:
        out.append(int(num))
    return out


def build_theta(n_proj: int,
                start_deg: float | None,
                step_deg: float | None,
                end_deg: float | None) -> np.ndarray:
    """Generate projection angles in radians."""
    import math
    if start_deg is None and step_deg is None and end_deg is None:
        return np.linspace(0.0, math.pi, n_proj, endpoint=True).astype(np.float32)
    if start_deg is None:
        start_deg = 0.0
    if step_deg is not None and end_deg is None:
        end_deg = start_deg + (n_proj - 1) * step_deg
    if end_deg is None:
        end_deg = 180.0
    return np.linspace(
        math.radians(start_deg),
        math.radians(end_deg),
        n_proj,
        endpoint=True,
    ).astype(np.float32)


def downsample_1d_x(arr: np.ndarray, factor: int) -> np.ndarray:
    """
    Downsample along the last axis (X) by integer factor using average pooling.
    Works for shape (N, X) or (1, X) etc.
    """
    if factor <= 1:
        return arr
    x = arr.shape[-1]
    sx = (x // factor) * factor
    arr = arr[..., :sx]
    new_shape = arr.shape[:-1] + (sx // factor, factor)
    arr = arr.reshape(new_shape).mean(axis=-1)
    return arr


def read_sino_row(
    projs_dir: Path,
    pattern: str,
    row: int,
    downsample: int,
) -> np.ndarray:
    """
    Read a single detector row across all projections into a sinogram.

    Returns array of shape (n_proj, 1, nx_ds).
    """
    files = sorted(projs_dir.glob(pattern), key=lambda p: p.name)
    if not files:
        raise SystemExit(f"No projections found in {projs_dir} pattern {pattern}")

    arrs = []
    for fp in files:
        img = tiff.imread(str(fp))
        if row < 0 or row >= img.shape[0]:
            raise SystemExit(
                f"Requested row {row} out of range for image {fp.name} "
                f"(height={img.shape[0]})"
            )
        line = img[row:row+1, :]  # shape (1, W)
        line = downsample_1d_x(line, downsample)  # still (1, W_ds)
        arrs.append(line.astype(np.float32, copy=False))

    # stack to (n_proj, 1, nx)
    sino = np.stack(arrs, axis=0)  # (n_proj, 1, nx_ds)
    return sino


def read_flat_dark_row(
    flats_dir: Path | None,
    darks_dir: Path | None,
    row: int,
    downsample: int,
) -> tuple[np.ndarray | None, np.ndarray | None]:
    """Average OB/DI frames at a given detector row into 1D arrays."""
    flat_row = dark_row = None

    if flats_dir is not None:
        flat_files = sorted(list(flats_dir.glob("ob_*.tif*")), key=lambda p: p.name)
        if flat_files:
            acc = None
            for fp in flat_files:
                img = tiff.imread(str(fp))
                if row < 0 or row >= img.shape[0]:
                    raise SystemExit(
                        f"Requested row {row} out of range for flat {fp.name} "
                        f"(height={img.shape[0]})"
                    )
                line = img[row, :]  # shape (W,)
                line = downsample_1d_x(line[None, :], downsample)[0]  # (W_ds,)
                if acc is None:
                    acc = line.astype(np.float64)
                else:
                    acc += line
            acc /= len(flat_files)
            flat_row = acc.astype(np.float32)

    if darks_dir is not None:
        dark_files = sorted(list(darks_dir.glob("di_*.tif*")), key=lambda p: p.name)
        if dark_files:
            acc = None
            for fp in dark_files:
                img = tiff.imread(str(fp))
                if row < 0 or row >= img.shape[0]:
                    raise SystemExit(
                        f"Requested row {row} out of range for dark {fp.name} "
                        f"(height={img.shape[0]})"
                    )
                line = img[row, :]
                line = downsample_1d_x(line[None, :], downsample)[0]
                if acc is None:
                    acc = line.astype(np.float64)
                else:
                    acc += line
            acc /= len(dark_files)
            dark_row = acc.astype(np.float32)

    return flat_row, dark_row


def preprocess_sino(
    sino: np.ndarray,
    flat_row: np.ndarray | None,
    dark_row: np.ndarray | None,
    median: int,
    stripe: str,
) -> np.ndarray:
    """
    Preprocess the sinogram: flat/dark normalize, minus-log, optional median/stripe.
    sino: (n_proj, 1, nx)
    """
    # normalize
    if flat_row is not None and dark_row is not None:
        # expand to (n_proj, 1, nx)
        flat_stack = np.broadcast_to(flat_row[None, None, :], sino.shape)
        dark_stack = np.broadcast_to(dark_row[None, None, :], sino.shape)
        sino = tomopy.normalize(sino, flat_stack, dark_stack)

    # minus-log
    sino = tomopy.minus_log(sino)

    # median filter (3D; works with n_slice=1)
    if median and median > 0:
        sino = tomopy.misc.corr.median_filter(sino, size=median)

    # stripe removal
    if stripe == "fw":
        sino = tomopy.remove_stripe_fw(sino, level=7, wname="db5", sigma=1, pad=True)
    elif stripe == "ti":
        sino = tomopy.remove_stripe_ti(sino, alpha=1.5)
    elif stripe == "none":
        pass

    return sino


def focus_score(img2d: np.ndarray) -> float:
    """
    Compute a simple sharpness score for a reconstructed slice.
    Higher is better.
    """
    img = img2d.astype(np.float32)
    # normalize to [0,1] for numerical stability
    vmin, vmax = np.min(img), np.max(img)
    if vmax > vmin:
        img = (img - vmin) / (vmax - vmin)
    else:
        img = img * 0.0

    # gradient-based focus: magnitude of gradients
    gy, gx = np.gradient(img)
    score = (gx**2 + gy**2).mean()
    return float(score)


def main():
    parser = argparse.ArgumentParser("Auto center-of-rotation detection (single-row)")

    parser.add_argument("--projs_dir", required=True, help="Directory of projection TIFFs")
    parser.add_argument("--pattern", default="*.tif*", help="Pattern for projections")
    parser.add_argument("--flats_dir", default=None, help="Directory with OB flats (ob_*.tif)")
    parser.add_argument("--darks_dir", default=None, help="Directory with DI darks (di_*.tif)")
    parser.add_argument("--row", type=int, required=True, help="Detector row index (0-based)")
    parser.add_argument("--downsample", type=int, default=2, help="Downsample factor along X")

    parser.add_argument("--theta_start", type=float, default=None)
    parser.add_argument("--theta_step", type=float, default=None)
    parser.add_argument("--theta_end", type=float, default=None)

    parser.add_argument("--center_start", type=float, required=True)
    parser.add_argument("--center_end", type=float, required=True)
    parser.add_argument("--center_step", type=float, required=True)

    parser.add_argument("--median", type=int, default=0)
    parser.add_argument("--stripe", choices=["none", "fw", "ti"], default="none")

    parser.add_argument("--out_dir", required=True, help="Directory for CSV / diagnostics")

    args = parser.parse_args()

    projs_dir = Path(args.projs_dir)
    flats_dir = Path(args.flats_dir) if args.flats_dir else None
    darks_dir = Path(args.darks_dir) if args.darks_dir else None
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # 1) read sinogram row
    print(f"[auto-center] Reading single-row sinogram from {projs_dir}...")
    sino = read_sino_row(projs_dir, args.pattern, args.row, args.downsample)
    print(f"[auto-center] sino shape: {sino.shape}")  # (n_proj, 1, nx)

    n_proj = sino.shape[0]

    # 2) read flat/dark rows (optional)
    flat_row = dark_row = None
    if flats_dir is not None:
        print(f"[auto-center] Reading flat row from {flats_dir}...")
        flat_row, _ = read_flat_dark_row(flats_dir, None, args.row, args.downsample)
    if darks_dir is not None:
        print(f"[auto-center] Reading dark row from {darks_dir}...")
        _, dark_row = read_flat_dark_row(None, darks_dir, args.row, args.downsample)

    # 3) build theta
    theta = build_theta(n_proj, args.theta_start, args.theta_step, args.theta_end)
    print(f"[auto-center] theta range: {theta[0]:.6f} .. {theta[-1]:.6f} (n={len(theta)})")

    # 4) preprocess sino once
    print("[auto-center] Preprocessing sinogram...")
    sino_pp = preprocess_sino(sino, flat_row, dark_row, args.median, args.stripe)

    centers = np.arange(args.center_start, args.center_end + 1e-8, args.center_step, dtype=float)
    print(f"[auto-center] Testing {len(centers)} centers: {centers[0]} .. {centers[-1]}")

    scores = []

    # 5) loop over candidate centers
    for c in centers:
        # TomoPy expects tomo shape (n_proj, n_slice, n_detector)
        # We have (n_proj, 1, nx_ds), so we reconstruct 1 slice.
        rec = tomopy.recon(
            sino_pp,
            theta,
            center=c,
            algorithm="gridrec",
            filter_name="parzen",
            ncore=1,  # 1 core is fine for single slice
        )
        # rec shape typically (1, ny, nx) or (1, 1, nx). We just squeeze to 2D.
        img2d = rec.squeeze()
        score = focus_score(img2d)
        scores.append((c, score))
        print(f"[auto-center] center={c:.3f}, score={score:.6g}")

    scores = sorted(scores, key=lambda x: x[1], reverse=True)
    best_center, best_score = scores[0]
    print("\n[auto-center] ===============================")
    print(f"[auto-center] Best center: {best_center:.4f} (score={best_score:.6g})")
    print("[auto-center] Top 10 candidates:")
    for c, s in scores[:10]:
        print(f"  center={c:.4f}, score={s:.6g}")

    # 6) save CSV
    csv_path = out_dir / "center_scores.csv"
    with open(csv_path, "w") as f:
        f.write("center,score\n")
        for c, s in scores:
            f.write(f"{c:.6f},{s:.10g}\n")
    print(f"[auto-center] Saved scores to {csv_path}")


if __name__ == "__main__":
    main()

