#!/usr/bin/env python
"""
Center-of-rotation sweep helper using TomoPy (+ optional ASTRA FBP_CUDA).

It:
  1. Loads a stack of projections (TIFFs) for parallel-beam CT.
  2. Preprocesses (flat/dark norm, minus-log, median, stripe removal).
  3. Extracts ONE detector row (a sinogram).
  4. For each center in [center_start, center_end] with given step:
     - Reconstructs a single slice using gridrec or ASTRA FBP_CUDA.
     - Saves an image per center: 'center_<value>_row<row>.tif'

Use it to visually pick the best center (sharpest, no double edges).

Typical usage (Windows CMD)
---------------------------
python center_sweep_tomopy_astra.py ^
  --projs_dir data\\scan --pattern "DINGO_*.tif*" ^
  --out_dir data\\center_sweep ^
  --center_start 3100 --center_end 3150 --center_step 1.0 ^
  --row 1600 --downsample 2 ^
  --median 3 --stripe fw --algorithm gridrec

# If ASTRA FBP_CUDA is set up and you want to use it:
python center_sweep_tomopy_astra.py ^
  --projs_dir data\\scan --pattern "DINGO_*.tif*" ^
  --out_dir data\\center_sweep ^
  --center_start 3100 --center_end 3150 --center_step 1.0 ^
  --row 1600 --downsample 2 ^
  --median 3 --stripe fw --algorithm astra_fbp

Then open the images (ImageJ/napari) and pick the center with the best focus.
"""

from __future__ import annotations
import argparse
import math
from pathlib import Path
from typing import List

import numpy as np
import tifffile as tiff

# TomoPy
try:
    import tomopy
except Exception as e:
    raise SystemExit("TomoPy is required: pip install tomopy\n" + str(e))

# ASTRA is optional (only if you use --algorithm astra_fbp)
try:
    import astra  # noqa: F401
    ASTRA_OK = True
except Exception:
    ASTRA_OK = False


def natural_key(s: str):
    """Simple natural sort key (numbers sorted numerically)."""
    out = []
    num = ""
    for ch in s:
        if ch.isdigit():
            num += ch
        else:
            if num:
                out.append(int(num))
                num = ""
            out.append(ch.lower())
    if num:
        out.append(int(num))
    return out


def read_stack(files: List[str], dtype=np.float32) -> np.ndarray:
    """Read TIFF stack to array (n_proj, ny, nx), float32."""
    arrs = []
    for fp in files:
        img = tiff.imread(fp)
        arrs.append(img)
    data = np.stack(arrs, axis=0)
    if data.dtype != np.float32:
        data = data.astype(dtype, copy=False)
    return data


def average_stack(files: List[str], dtype=np.float32) -> np.ndarray | None:
    """Average flat/dark TIFFs into a single frame (float32)."""
    if not files:
        return None
    acc = None
    for fp in files:
        img = tiff.imread(fp).astype(dtype, copy=False)
        if acc is None:
            acc = img.astype(np.float64)
        else:
            acc += img
    acc /= float(len(files))
    return acc.astype(dtype)


def build_theta(n_proj: int,
                start_deg: float | None,
                step_deg: float | None,
                end_deg: float | None) -> np.ndarray:
    """Build angle vector theta (radians) for TomoPy."""
    if start_deg is None and step_deg is None and end_deg is None:
        return np.linspace(0.0, math.pi, n_proj, endpoint=True).astype(np.float32)
    if start_deg is None:
        start_deg = 0.0
    if step_deg is not None and end_deg is None:
        end_deg = start_deg + step_deg * (n_proj - 1)
    if end_deg is None:
        end_deg = 180.0
    theta = np.linspace(math.radians(start_deg), math.radians(end_deg),
                        n_proj, endpoint=True).astype(np.float32)
    return theta


def maybe_downsample(proj: np.ndarray, factor: int) -> np.ndarray:
    """
    Simple 2x/4x binning along detector axes (ny, nx).
    proj: (n_proj, ny, nx)
    """
    if factor <= 1:
        return proj
    n, ny, nx = proj.shape
    sy = (ny // factor) * factor
    sx = (nx // factor) * factor
    proj = proj[:, :sy, :sx]
    proj = proj.reshape(n, sy // factor, factor, sx // factor, factor).mean(axis=(2, 4))
    return proj


def preprocess(proj: np.ndarray,
               flat: np.ndarray | None,
               dark: np.ndarray | None,
               median: int,
               stripe: str | None) -> np.ndarray:
    """
    Flat/dark normalization, minus-log, optional median & stripe removal.
    proj: (n_proj, ny, nx)
    """
    if flat is not None and dark is not None:
        flat_stack = np.repeat(flat[None, ...], proj.shape[0], axis=0)
        dark_stack = np.repeat(dark[None, ...], proj.shape[0], axis=0)
        proj = tomopy.normalize(proj, flat_stack, dark_stack)
    proj = tomopy.minus_log(proj)

    if median and median > 0:
        proj = tomopy.misc.corr.median_filter(proj, size=median)

    if stripe == "fw":
        proj = tomopy.remove_stripe_fw(proj, level=7, wname="db5", sigma=1, pad=True)
    elif stripe == "ti":
        proj = tomopy.remove_stripe_ti(proj, alpha=1.5)
    return proj


def recon_single_slice(sino: np.ndarray,
                       theta: np.ndarray,
                       center: float,
                       algorithm: str = "gridrec") -> np.ndarray:
    """
    Reconstruct a single slice from a sinogram.

    sino: (n_proj, nx)
    theta: (n_proj,)
    center: float
    algorithm: 'gridrec' (CPU) or 'astra_fbp' (GPU if ASTRA available)

    Returns rec: 2D array (ny, nx) or (N, N) depending on geometry.
    """
    # TomoPy expects shape (n_proj, nz, nx) for 3D batch;
    # use nz=1 for a single slice
    sino3d = sino[:, None, :]  # (n_proj, 1, nx)

    if algorithm == "gridrec":
        rec = tomopy.recon(sino3d, theta, center=center,
                           algorithm="gridrec", filter_name="parzen")
    elif algorithm == "astra_fbp":
        if not ASTRA_OK:
            raise RuntimeError("ASTRA not available; install astra-toolbox or use --algorithm gridrec")
        options = {"proj_type": "cuda", "method": "FBP_CUDA"}
        rec = tomopy.recon(sino3d, theta, center=center,
                           algorithm="astra", options=options)
    else:
        raise ValueError(f"Unknown algorithm: {algorithm}")

    # rec: (nz=1, ny, nx) -> pick the single slice
    return rec[0]


def main():
    ap = argparse.ArgumentParser(description="Center-of-rotation sweep (TomoPy + optional ASTRA FBP_CUDA)")

    ap.add_argument("--projs_dir", required=True, help="Folder with projection TIFFs")
    ap.add_argument("--pattern", default="*.tif*", help="Glob for projections (e.g., 'DINGO_*.tif*')")
    ap.add_argument("--flats_dir", default=None, help="Folder with flat-field TIFFs (optional)")
    ap.add_argument("--darks_dir", default=None, help="Folder with dark-field TIFFs (optional)")
    ap.add_argument("--out_dir", required=True, help="Output directory for sweep images")

    # angles
    ap.add_argument("--theta_start", type=float, default=None, help="Start angle (deg, default auto=0)")
    ap.add_argument("--theta_step", type=float, default=None, help="Step angle (deg, default auto from count)")
    ap.add_argument("--theta_end", type=float, default=None, help="End angle (deg, default auto=180)")

    # preprocessing
    ap.add_argument("--downsample", type=int, default=1, help="Binning factor 1/2/4 along detector axes")
    ap.add_argument("--median", type=int, default=0, help="Median filter size (0=off)")
    ap.add_argument("--stripe", choices=["fw", "ti"], default=None,
                    help="Stripe removal: fw=Fourier-wavelet, ti=Tikhonov")

    # which detector row to use
    ap.add_argument("--row", type=int, default=None,
                    help="Detector row index for sinogram (default: center row)")

    # center sweep
    ap.add_argument("--center_start", type=float, required=True, help="Start center value")
    ap.add_argument("--center_end", type=float, required=True, help="End center value")
    ap.add_argument("--center_step", type=float, default=1.0, help="Center step")

    # recon algorithm
    ap.add_argument("--algorithm", choices=["gridrec", "astra_fbp"], default="gridrec",
                    help="Reconstruction algorithm for sweep")

    args = ap.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    files = sorted([str(p) for p in Path(args.projs_dir).glob(args.pattern)], key=natural_key)
    if len(files) == 0:
        raise SystemExit(f"No projections found in {args.projs_dir} with pattern {args.pattern}")
    print(f"Found {len(files)} projections.")

    print("Reading projections...")
    proj = read_stack(files)  # (n_proj, ny, nx)
    n_proj, ny, nx = proj.shape
    print("proj shape:", proj.shape)

    # flats/darks
    flat = None
    dark = None
    if args.flats_dir:
        flat_files = sorted([str(p) for p in Path(args.flats_dir).glob(args.pattern)], key=natural_key)
        flat = average_stack(flat_files)
        print("Flat shape:", None if flat is None else flat.shape)
    if args.darks_dir:
        dark_files = sorted([str(p) for p in Path(args.darks_dir).glob(args.pattern)], key=natural_key)
        dark = average_stack(dark_files)
        print("Dark shape:", None if dark is None else dark.shape)

    theta = build_theta(n_proj, args.theta_start, args.theta_step, args.theta_end)
    print(f"Theta: {theta[0]:.6f} .. {theta[-1]:.6f} rad, n={len(theta)}")

    if args.downsample > 1:
        proj = maybe_downsample(proj, args.downsample)
        n_proj, ny, nx = proj.shape
        print("After downsample:", proj.shape)

    print("Preprocessing (norm / minus-log / median / stripe)...")
    proj = preprocess(proj, flat, dark, median=args.median, stripe=args.stripe)

    # choose detector row
    row = args.row if args.row is not None else ny // 2
    if row < 0 or row >= ny:
        raise SystemExit(f"Row index out of range: {row} (ny={ny})")
    print(f"Using detector row {row} for sinogram")

    sino = proj[:, row, :]  # (n_proj, nx)

    centers = []
    c = args.center_start
    while c <= args.center_end + 1e-6:
        centers.append(float(c))
        c += args.center_step

    print(f"Sweeping centers: {centers}")

    for cval in centers:
        print(f"Reconstructing slice for center={cval:.3f}...")
        rec_slice = recon_single_slice(sino, theta, center=cval, algorithm=args.algorithm)

        # normalize slice to 0-1 for visualization
        rs = rec_slice
        rs = rs - rs.min()
        if rs.max() > 0:
            rs = rs / rs.max()
        img = (rs * 65535).astype(np.uint16)  # 16-bit for fine gradation

        fname = out_dir / f"center_{cval:.2f}_row{row:04d}.tif"
        tiff.imwrite(str(fname), img)
        print("  saved", fname)

    print("[OK] Center sweep finished. Inspect images in", out_dir)


if __name__ == "__main__":
    main()

